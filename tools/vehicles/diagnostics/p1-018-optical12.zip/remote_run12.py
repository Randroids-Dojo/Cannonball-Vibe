"""Scoped hosted managed-only validation proposal. No Godot process or native renderer."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import struct
import subprocess
import sys


def row(path):
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execute-managed", action="store_true")
    args = parser.parse_args()
    package = args.package.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    manifest = json.loads((package / "manifest.json").read_text())
    files = manifest["files"]
    actual_roles = {path.relative_to(package).as_posix() for path in package.rglob("*") if path.is_file()}
    assert actual_roles == {entry["role"] for entry in files} | {"manifest.json"}, "Package file domain differs"
    assert len({entry["role"] for entry in files}) == len(files)
    for entry in files:
        role = Path(entry["role"])
        assert not role.is_absolute() and ".." not in role.parts and "\\" not in entry["role"] and ":" not in entry["role"]
        value = row(package / role)
        assert (value["bytes"], value["sha256"]) == (entry["bytes"], entry["sha256"]), entry["role"]
    record = {"task_id": "P1-018", "utc": datetime.now(timezone.utc).isoformat(),
        "actual_platform": platform.platform(), "python": sys.version, "machine": platform.machine(),
        "runner_os": os.environ.get("RUNNER_OS"), "runner_image": os.environ.get("ImageOS"),
        "dispatch_revision": os.environ.get("GITHUB_SHA"), "run_id": os.environ.get("GITHUB_RUN_ID"),
        "recipe": row(package / "manifest.json"), "sources": manifest["provenance"], "commands": [],
        "native_engine_executed": False, "local_windows_policy_resolved": False,
        "scope": "Actual hosted managed helper only; no source60 scene/import/render/performance/final-source acceptance."}
    if not args.execute_managed:
        record.update(status="validated-package-only", bound_files=len(files), managed_executed=False)
        write(output / "result.json", record)
        print(json.dumps({"status": record["status"], "files": len(files)}))
        return 0

    def command(label, argv, cwd):
        started = datetime.now(timezone.utc).isoformat()
        with (output / (label + ".stdout.log")).open("xb") as stdout, (output / (label + ".stderr.log")).open("xb") as stderr:
            completed = subprocess.run(argv, cwd=cwd, env=dict(os.environ, DOTNET_ROLL_FORWARD="Major"),
                stdout=stdout, stderr=stderr, timeout=300,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        record["commands"].append({"label": label, "argv": argv, "cwd": str(cwd), "started_utc": started,
            "finished_utc": datetime.now(timezone.utc).isoformat(), "exit_code": completed.returncode})
        (output / "progress.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
        assert completed.returncode == 0, label

    try:
        command("dotnet-info", ["dotnet", "--info"], package)
        command("build-game", ["dotnet", "build", "Cannonball.csproj", "--nologo", "-m:2",
            "-nodeReuse:false", "-p:UseSharedCompilation=false", "-p:RestoreLockedMode=true"], package / "project")
        command("build-helper", ["dotnet", "build", "ComponentHost.csproj", "--nologo", "-m:2",
            "-nodeReuse:false", "-p:UseSharedCompilation=false"], package / "helper")
        dll = package / "project/.godot/mono/temp/bin/Debug"
        built = [row(dll / name) for name in ("Cannonball.dll", "Cannonball.Core.dll", "GodotSharp.dll")]
        record["host_built_assemblies"] = built
        command("managed-helper", ["dotnet", str(package / "helper/bin/Debug/net8.0/ComponentHost.dll"),
            str(dll), str(package / "cases.json"), str(output / "actual-managed.json")], package)
        spec = importlib.util.spec_from_file_location("current12_reader", package / "reader.py")
        reader = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(reader)
        cases = json.loads((package / "cases.json").read_text())
        managed = {entry["name"]: entry for entry in json.loads((output / "actual-managed.json").read_text())}
        assert len(cases) == len(managed) == 66
        assert len(managed) == len(json.loads((output / "actual-managed.json").read_text()))
        bindings = [row(package / entry["role"]) for entry in files] + built
        scope = {"PACK": package, "OUT": output, "reader": reader, "cases": cases, "managed": managed,
            "copy": copy, "json": json, "Path": Path, "f32": f32, "write": write, "row": row, "bindings": bindings,
            "native_paths": [package / "witnesses/original07.png"]}
        exec(compile((package / "assertions12.py").read_text(), str(package / "assertions12.py"), "exec"), scope)
        record.update(status="passed-hosted-managed-only", managed_executed=True,
            helper_controls=json.loads((output / "result.json").read_text()), source_files_unchanged=True)
    except Exception as error:
        record.update(status="failed-hosted-managed-only", failure=f"{type(error).__name__}: {error}")
    finally:
        changes = [entry["role"] for entry in files if row(package / entry["role"])["sha256"] != entry["sha256"]]
        record["changed_inputs"] = changes
        if changes:
            record["status"] = "failed-hosted-managed-only"
        write(output / "hosted-result.json", record)
    print(json.dumps({"status": record["status"], "actual_platform": record["actual_platform"]}))
    return 0 if record["status"] == "passed-hosted-managed-only" else 1


if __name__ == "__main__":
    raise SystemExit(main())
