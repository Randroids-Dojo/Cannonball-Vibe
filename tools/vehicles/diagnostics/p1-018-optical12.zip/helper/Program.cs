using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

if (args.Length != 3) throw new ArgumentException("assembly directory, cases file, output file required");
var directory = Path.GetFullPath(args[0]);
AssemblyLoadContext.Default.Resolving += (_, name) =>
{
    var path = Path.Combine(directory, name.Name + ".dll");
    return File.Exists(path) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(path) : null;
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(directory, "Cannonball.dll"));
var type = assembly.GetType("Cannonball.Game.Automation.SedanFinalMirrorCapture", throwOnError: true)!;
var measure = type.GetMethod("MeasureMovingTargetComponents", BindingFlags.NonPublic | BindingFlags.Static)!;
var describe = type.GetMethod("DescribeMovingComponents", BindingFlags.NonPublic | BindingFlags.Static)!;
var identify = type.GetMethod("MeasureMovingFiducials", BindingFlags.NonPublic | BindingFlags.Static)!;
var describeIdentity = type.GetMethod("DescribeMovingFiducials", BindingFlags.NonPublic | BindingFlags.Static)!;
using var input = JsonDocument.Parse(File.ReadAllText(args[1]));
var results = new List<object>();
foreach (var item in input.RootElement.EnumerateArray())
{
    var name = item.GetProperty("name").GetString()!;
    try
    {
        var data = Convert.FromHexString(item.GetProperty("rgba_hex").GetString()!);
        var width = item.GetProperty("width").GetInt32();
        var height = item.GetProperty("height").GetInt32();
        var marker = item.GetProperty("marker").GetInt32();
        var raw = measure.Invoke(null, [data, width, height, marker]);
        var optical = identify.Invoke(null, [data, width, height, marker, raw]);
        results.Add(new { name, status = "returned", observation = describe.Invoke(null, [raw]),
            optical = describeIdentity.Invoke(null, [optical]) });
    }
    catch (TargetInvocationException error) when (error.InnerException is ArgumentException)
    {
        results.Add(new { name, status = "rejected-domain", error = error.InnerException.Message });
    }
}
File.WriteAllText(args[2], JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine($"ACTUAL_MANAGED_OPTICAL_MARKERS_OK cases={results.Count}");
