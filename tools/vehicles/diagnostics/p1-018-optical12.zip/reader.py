"""Record an actual native sedan movie with strict completion and decoded-size gates.

Run only while holding the shared GPU/runtime lane. The lead authorized the
temporary project override; an existing override is never changed or removed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import re
import shutil
import signal
import struct
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DRIVING = [
    "static-ride", "keyboard-acceleration", "keyboard-braking", "controller-acceleration",
    "controller-braking", "reverse", "steer-left", "steer-right", "suspension", "collision",
    "reset", "cameras", "natural-rebase", "forced-rebase", "save-resume", "starter-policy", "lod-driving",
]
PRESENTATION = [
    "contract", "view-front", "view-rear", "view-left", "view-right", "view-top", "view-underside",
    "view-front-three-quarter", "view-rear-three-quarter", "turntable", "cockpit", "view-footwell", "view-rear-cabin",
    "inspection-keyboard", "inspection-controller", "open-Door_FL", "close-Door_FL", "open-Door_FR", "close-Door_FR",
    "open-Door_RL", "close-Door_RL", "open-Door_RR", "close-Door_RR", "open-Hood_Hinge", "close-Hood_Hinge",
    "open-Trunk_Hinge", "close-Trunk_Hinge", "lights-off", "headlights", "brake-lights", "reverse-lights",
    "left-indicator", "right-indicator", "hazards", "wipers-sweep", "wipers-park", "steering-small-right",
    "controls-left", "controls-right", "instruments-forward", "instruments-reverse", "instruments-low-fuel",
    "instruments-damage", "instruments-cooling", "instruments-tires", "instruments-panel-open", "instruments-park-brake",
    "mirrors-configuration", "lod-near", "lod-middle", "lod-far", "lod-return", "mirrors-live", "mirrors-door-follow", "mirrors-disabled",
]
WARNING_STATES = {
    "instruments-low-fuel": "LOW FUEL", "instruments-damage": "DAMAGE", "instruments-cooling": "COOLING",
    "instruments-tires": "TIRES", "instruments-panel-open": "PANEL OPEN", "instruments-park-brake": "PARK BRAKE",
}
OVERRIDE = b"""; Temporary P1-018 capture settings. Removed by the owning capture runner.
[display]
window/size/viewport_width=2560
window/size/viewport_height=1440
window/size/window_width_override=2560
window/size/window_height_override=1440
window/stretch/mode="canvas_items"
"""
FATAL = re.compile(r"(?:^|\n)(?:ERROR|WARNING|SCRIPT ERROR):|Unhandled exception|Fatal error|AccessViolationException|SIGSEGV|Segmentation fault|Leaked unsafe reference|ObjectDB instances leaked|resources still in use", re.IGNORECASE)
IMPORT_WARNINGS = {
    "WARNING: Ignoring unsupported header information in HDR: GAMMA=1.",
    "WARNING: Ignoring unsupported header information in HDR: PRIMARIES=0 0 0 0 0 0 0 0.",
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_reconstruction_camera(summary, out):
    camera = summary.get("reconstruction_camera") or {}
    frames = camera.get("render_frames", [])
    process_frames = camera.get("process_frames", [])
    observations = camera.get("observations", [])
    captures = camera.get("captures", [])
    def consecutive(values):
        return len(values) == 3 and values == list(range(values[0], values[0] + 3))
    if (camera.get("native_display") is not True or not consecutive(frames) or not consecutive(process_frames)
            or [row.get("render_frame") for row in observations] != frames
            or [row.get("render_frame") for row in captures] != frames
            or [row.get("index") for row in captures] != [1, 2, 3]):
        raise ValueError("Missing first three consecutive actual reconstructed camera frames")
    for observation, capture in zip(observations, captures, strict=True):
        if (observation.get("valid") is not True or observation.get("observation_boundary") != "native-before-draw"
                or observation.get("vehicle_epoch") != 1 or observation.get("native_arm_child_error_m", 1) > 0.001
                or observation.get("hit_length_m", -1) < observation.get("spring_length_m", 0) - 0.01
                or capture.get("before_draw") != observation):
            raise ValueError("First reconstructed camera frame preceded native arm collision/placement")
        path = Path(capture["path"]).resolve()
        if not path.is_relative_to(out) or path.name != f"resume-frame-{capture['index']:02}.png":
            raise ValueError("First reconstructed camera PNG path is invalid")
        with path.open("rb") as image:
            header = image.read(24)
        size = list(struct.unpack(">II", header[16:24])) if header[:8] == b"\x89PNG\r\n\x1a\n" else []
        if size != [2560, 1440] or capture.get("size") != size or capture.get("sha256") != sha(path):
            raise ValueError("First reconstructed camera actual PNG hash/size mismatch")
    return {"status": "passed", "render_frames": frames, "captures": captures}


def validate_summary(out, mode, expected, record):
    summary = json.loads((out / ("summary.json" if mode == "driving" else "presentation-summary.json")).read_text(encoding="utf-8-sig"))
    captures = summary["rendered_captures" if mode == "driving" else "captures"]
    record["completed_stages"] = [stage["stage"] for stage in summary["completed_stages"]]
    if (summary["status"] != "passed" or summary["expected_stages"] != expected or record["completed_stages"] != expected
            or any(stage["status"] != "passed" for stage in summary["completed_stages"])):
        record["failures"].append("Summary inventory or stage status mismatch")
    if mode == "driving" and (summary["vehicle"] != "endurance-sedan"
            or summary["loaded_asset"] != "endurance-sedan"
            or summary["blockout_presentation_omitted"] is not record.get("blockout", False)):
        record["failures"].append("Wrong vehicle or unexpected blockout/production presentation scope")
    if mode == "presentation":
        if summary["rendered"] is not True or summary["diagnostic_probe"] != record.get("diagnostic_probe"):
            record["failures"].append("Summary rendering/diagnostic identity mismatch")
        if record.get("diagnostic_probe") == "mirrors" and summary["mirror_lighting"] != record["mirror_lighting"]:
            record["failures"].append("Mirror lighting identity mismatch")
        if sha(out / "mirror-samples.jsonl") != summary["mirror_samples_sha256"]:
            record["failures"].append("Mirror pixel/sample evidence hash mismatch")
        for stage, label in WARNING_STATES.items():
            if stage not in expected:
                continue
            warning = (summary.get("warning_visibilities") or {}).get(stage) or {}
            if (warning.get("passed") is not True or warning.get("source_glyph_pixels", 0) < 40
                    or warning.get("stage") != stage or warning.get("warning") != label
                    or warning.get("total_ratio", 0) < 0.90 or len(warning.get("half_ratios", [])) != 2
                    or any(value < 0.85 for value in warning.get("half_ratios", []))):
                record["failures"].append("Actual cockpit warning visibility was not verified: " + label)
    if [capture["stage"] for capture in captures] != expected:
        record["failures"].append("Actual PNG capture inventory mismatch")
    if mode == "driving":
        if record.get("diagnostic_probe") != "driving-final":
            record["reconstruction_camera"] = validate_reconstruction_camera(summary, out)
        contact = summary.get("contact_shading") or {}
        shading_required = not record.get("blockout", False) or contact.get("enabled_by_setup") is True
        if shading_required and (contact.get("enabled_by_setup") is not True or contact.get("supported_renderer") is not True
                                 or contact.get("render_samples", 0) < 3 or contact.get("visible_wheel_samples", 0) < 4
                                 or record.get("diagnostic_probe") != "driving-final" and contact.get("airborne_wheel_samples", 0) < 1
                                 or contact.get("maximum_alignment_error_m", 1) > 0.001 or contact.get("maximum_plane_error_m", 1) > 0.001):
            record["failures"].append("Native contact shading contact/alignment/airborne proof missing")
        if not shading_required and (contact.get("supported_renderer") is not False or contact.get("render_samples") != 0):
            record["failures"].append("Historical blockout contact-shading omission scope mismatch")
        record["contact_shading"] = contact
        budget_path = Path(record.get("project_root", ROOT)) / "tools/vehicles/vehicle_contract.json"
        budgets = json.loads(budget_path.read_text())["budgets"]
        record["runtime_budget_sha256"] = sha(budget_path)
        inventories = list((summary.get("runtime_resource_inventory") or {}).values())
        required_lods = {0} if record.get("blockout", False) else {0, 1, 2}
        if not required_lods.issubset({row["ActiveLod"] for row in inventories}) or any(
                row["DrawnTriangles"] + (48 if shading_required else 0) > budgets["triangles_lod0_max"]
                or row["ActiveMaterialResources"] > budgets["materials_max"]
                or row["ActiveTextureResources"] + int(shading_required) > budgets["textures_max"] for row in inventories):
            record["failures"].append("Actual runtime visible geometry/material/texture budget inventory missing or exceeded")
        record["runtime_resource_inventory"] = inventories
        record["contact_proxy_geometry_budget"] = {"triangles_per_viewport_upper_bound": 48 if shading_required else 0,
            "basis": "Four renderer-owned twelve-triangle cluster boxes per viewport; additional mirror-view submissions are measured separately."}
        previous_frame = previous_count = -1
        for stage in (("natural-rebase",) if record.get("diagnostic_probe") == "driving-final" else ("natural-rebase", "forced-rebase")):
            observation = (summary.get("rebase_observations") or {}).get(stage) or {}
            capture = next((row for row in captures if row["stage"] == stage), {})
            rendered = observation.get("rendered_frames", [])
            count = observation.get("captured_rebase_count", -1)
            frame = observation.get("captured_render_frame", -1)
            if (observation.get("native_display") is not True or len(set(rendered)) < 3
                    or len(set(observation.get("process_frames", []))) < 3
                    or count != observation.get("rebase_count") or count <= previous_count
                    or count <= observation.get("baseline_rebase_count", count)
                    or frame != capture.get("render_frame") or frame <= previous_frame or frame not in rendered
                    or any(capture.get(boundary, {}).get("local_origin", {}).get("RebaseCount") != count
                           for boundary in ("before_draw", "after_draw"))):
                record["failures"].append("Missing separately rendered rebase event: " + stage)
            previous_frame, previous_count = frame, count
    for capture in captures:
        path = Path(capture["path"]).resolve()
        if not path.is_relative_to(out):
            raise RuntimeError("Capture image escapes its evidence directory")
        with path.open("rb") as image:
            header = image.read(24)
        decoded_size = list(struct.unpack(">II", header[16:24])) if header[:8] == b"\x89PNG\r\n\x1a\n" else []
        if decoded_size != [2560, 1440] or capture["size"] != decoded_size or capture["sha256"] != sha(path):
            record["failures"].append("Actual PNG size/hash mismatch: " + capture["stage"])
        quality = capture.get("render_quality", {})
        if (capture.get("renderer") != "forward_plus" or quality.get("actual_msaa_3d") != "Msaa4X"
                or quality.get("applied_tier") != "high" or quality.get("applied_directional_shadow_size") != 8192):
            record["failures"].append("Actual native High rendering configuration mismatch: " + capture["stage"])
        expected_lighting = "night" if record.get("diagnostic_probe") == "driving-final" and record.get("mirror_lighting") == "night" else "day"
        if mode == "driving" and capture.get("lighting") != expected_lighting:
            record["failures"].append("Actual driving capture environment preset mismatch: " + capture["stage"])
        if mode == "presentation" and capture.get("actual_environment_preset") != str(capture.get("lighting", "")).lower():
            record["failures"].append("Actual presentation capture environment preset mismatch: " + capture["stage"])
        if mode == "driving":
            before, after = capture["before_draw"], capture["after_draw"]
            if (before["render_frame"] != capture["render_frame"] or after["render_frame"] != capture["render_frame"]
                    or before["active_lod"] != after["active_lod"] or before["stage"] != capture["stage"]):
                record["failures"].append("Capture LOD/render-frame identity mismatch: " + capture["stage"])
            selection = before["lod_selection"]
            if record.get("blockout", False):
                if selection is not None or before["active_lod"] != 0 or after["active_lod"] != 0:
                    record["failures"].append("Historical blockout did not retain its fixed LOD0/no-presenter scope: " + capture["stage"])
            elif selection is None or selection["render_frame"] != before["render_frame"] or abs(selection["distance_m"] - before["displayed_distance_m"]) > 0.01:
                record["failures"].append("Capture LOD selection used stale camera/body distance: " + capture["stage"])
    frame_file = out / ("frames.jsonl" if mode == "driving" else "presentation-frames.jsonl")
    expected_hash = summary["frames"]["sha256"] if mode == "driving" else summary["frames_sha256"]
    if sha(frame_file) != expected_hash:
        record["failures"].append("Per-frame evidence hash mismatch")
    validate_final_capture(summary, out, record)
    record["rendered_capture_count"] = len(captures)


# Appended to the existing capture runner before main; no native launch in these readers.
FINAL_DRIVING = [
    "static-ride", "keyboard-acceleration", "coast", "keyboard-braking", "reverse",
    "steer-left", "steer-right", "mirror-pan", "natural-rebase", "lod-inward",
]
FINAL_PRESENTATION = [
    "contract", "wall-headlights-off", "wall-headlights-on", "wall-brake-headlights-off", "wall-brake-headlights-on",
    "partial-Door_FL", "partial-Door_FR", "partial-Door_RL", "partial-Door_RR", "partial-Hood_Hinge", "partial-Trunk_Hinge",
    "wipers-three-cycles", "wipers-park",
]


def select_capture_cases(mode, probe, lighting=None, blockout=False, camera_source_y=None):
    if mode not in ("driving", "presentation") or probe not in (None, "mirrors", "driving-final", "presentation-final"):
        raise ValueError("Unknown mode or explicit probe")
    if blockout and (mode != "driving" or probe is not None):
        raise ValueError("Historical blockout remains driving-only and cannot select a supplement")
    if probe == "driving-final" and mode != "driving" or probe in ("mirrors", "presentation-final") and mode != "presentation":
        raise ValueError("Probe and scenario mode disagree")
    if lighting is not None and (probe not in ("mirrors", "driving-final") or lighting not in ("daylight", "night")):
        raise ValueError("Lighting applies only to mirrors or driving-final")
    if camera_source_y is not None and (probe != "mirrors" or not math.isfinite(camera_source_y) or not 0.4 <= camera_source_y <= 0.7):
        raise ValueError("Historical source-Y diagnostic remains mirror-only within0.4..0.7m")
    if probe == "driving-final":
        return FINAL_DRIVING
    if probe == "presentation-final":
        return FINAL_PRESENTATION
    if probe == "mirrors":
        return ["mirrors-configuration", "mirrors-live", "mirrors-door-follow", "mirrors-disabled"]
    return DRIVING[:-1] if blockout else DRIVING if mode == "driving" else PRESENTATION


def _require_final(condition, message):
    if not condition:
        raise ValueError("Final capture supplement: " + message)


def _native_distance2(left, right):
    def f32(value):
        return struct.unpack("<f", struct.pack("<f", value))[0]
    x, y = (f32(a - b) for a, b in zip(left, right, strict=True))
    return f32(math.sqrt(f32(f32(x * x) + f32(y * y))))


def _png_final(row, out, size=None):
    path = Path(row["path"]).resolve()
    _require_final(path.is_relative_to(out.resolve()), "PNG escapes output")
    with path.open("rb") as stream:
        header = stream.read(24)
    actual = list(struct.unpack(">II", header[16:24])) if header[:8] == b"\x89PNG\r\n\x1a\n" else []
    _require_final(actual == row["size"] and (size is None or actual == size) and row["sha256"] == sha(path), "PNG dimensions/hash mismatch")


FIDUCIAL_POLICY = {
    "schema": "moving-optical-code12.v1", "frame_fraction": 0.2, "columns": 2, "rows": 3,
    "codes": [[1, 0, 0, 1, 1, 0], [1, 1, 0, 0, 0, 1], [0, 1, 1, 0, 1, 0]],
    "corner_fractions": [0.1, 0.9], "corner_rounding": "nearest pixel center, positive tie; floor(fraction*extent)",
    "core_fraction": 0.5, "channel_contrast_min": 64, "channel_agreement": "exact-six-bit-code",
    "achromatic_core_required": False, "extreme_quarter": 0.25,
    "code_error_correction": False, "selection_uses_projection": False,
}


def validate_moving_fiducials(row, components, size):
    observation = row.get("optical_fiducials")
    _require_final(isinstance(observation, dict) and observation.get("policy") == FIDUCIAL_POLICY,
                   "optical fiducial observation/policy missing")
    policy = observation["policy"]
    _require_final(policy["code_error_correction"] is False and policy["selection_uses_projection"] is False
                   and policy["achromatic_core_required"] is False and type(policy["channel_contrast_min"]) is int
                   and all(type(bit) is int for code in policy["codes"] for bit in code), "invalid fiducial policy types")
    marker = {"Left": 1, "Right": 2, "Rear": 3}[row["mirror"]]
    _require_final(type(observation.get("expected_marker")) is int and observation["expected_marker"] == marker,
                   "wrong expected fiducial marker")
    candidates = observation.get("candidates")
    eligible = [index for index, component in enumerate(components) if component["count"] >= 8]
    _require_final(isinstance(candidates, list) and all(isinstance(value, dict) for value in candidates)
                   and [value.get("component_index") for value in candidates] == eligible
                   and all(type(value["component_index"]) is int for value in candidates),
                   "incomplete optical component candidate domain")
    identified = []

    def pixel(sample, point):
        _require_final(isinstance(sample, dict) and all(type(sample.get(key)) is int for key in ("x", "y"))
                       and [sample["x"], sample["y"]] == list(point), "fiducial sample coordinates disagree")
        rgb = sample.get("rgb")
        _require_final(isinstance(rgb, list) and len(rgb) == 3
                       and all(type(value) is int and 0 <= value <= 255 for value in rgb), "fiducial RGB byte domain")
        return rgb

    for candidate in candidates:
        component = components[candidate["component_index"]]
        x0, y0, x1, y1 = component["bounds"]
        width, height = x1 - x0 + 1, y1 - y0 + 1
        frame = candidate.get("frame_samples")
        _require_final(isinstance(frame, list) and len(frame) == 4, "fiducial frame domain missing")
        frame_points = [(x0 + cx * width // 10, y0 + cy * height // 10) for cy in (1, 9) for cx in (1, 9)]
        for sample, point in zip(frame, frame_points, strict=True):
            red, green, blue = pixel(sample, point)
            matches = ((red > 80 and blue > 80 and red - green > 40 and blue - green > 40) if marker == 1 else
                       (green > 80 and green - red > 40 and green - blue > 40) if marker == 2 else
                       (green > 80 and blue > 80 and green - red > 40 and blue - red > 40))
            _require_final(type(sample.get("member")) is bool and (not sample["member"] or matches),
                           "fiducial frame membership contradicts color")
        cells = candidate.get("cells")
        _require_final(isinstance(cells, list) and len(cells) == 6, "fiducial cell domain missing")
        channels = [[], [], []]
        for index, cell in enumerate(cells):
            cy, cx = divmod(index, 2)
            _require_final(isinstance(cell, dict) and type(cell.get("row")) is int and type(cell.get("column")) is int
                           and (cell["row"], cell["column"]) == (cy, cx), "fiducial cell membership/order")
            expected = [(x, y) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1)
                        if (11 + cx * 12) * width <= (2 * (x - x0) + 1) * 20 < (17 + cx * 12) * width
                        and (10 + cy * 8) * height <= (2 * (y - y0) + 1) * 20 < (14 + cy * 8) * height]
            samples = cell.get("pixels")
            _require_final(isinstance(samples, list) and type(cell.get("count")) is int
                           and len(samples) == cell["count"] == len(expected), "fiducial complete core pixel domain")
            sums = [0, 0, 0]
            for sample, point in zip(samples, expected, strict=True):
                sums = [a + b for a, b in zip(sums, pixel(sample, point), strict=True)]
            _require_final(isinstance(cell.get("sums_rgb"), list)
                           and all(type(value) is int for value in cell["sums_rgb"]) and cell["sums_rgb"] == sums,
                           "fiducial RGB sums disagree")
            for channel in range(3):
                channels[channel].append((sums[channel], len(expected)))
        rejection, decoded = None, None
        if x0 == 0 or y0 == 0 or x1 == size[0] - 1 or y1 == size[1] - 1:
            rejection = "clipped-frame"
        elif not all(sample["member"] for sample in frame):
            rejection = "incomplete-colored-frame"
        elif any(denominator == 0 for _, denominator in channels[0]):
            rejection = "empty-core"
        else:
            channel_bits = []
            for fractions in channels:
                low = high = fractions[0]
                for value in fractions[1:]:
                    if value[0] * low[1] < low[0] * value[1]:
                        low = value
                    if value[0] * high[1] > high[0] * value[1]:
                        high = value
                span = high[0] * low[1] - low[0] * high[1]
                if span < 64 * high[1] * low[1]:
                    rejection = "per-channel-low-contrast"
                    break
                bits = []
                for total, denominator in fractions:
                    if 4 * (total * low[1] - low[0] * denominator) * high[1] <= span * denominator:
                        bits.append(0)
                    elif 4 * (high[0] * denominator - total * high[1]) * low[1] <= span * denominator:
                        bits.append(1)
                    else:
                        rejection = "per-channel-intermediate-core"
                        break
                if rejection is not None:
                    break
                channel_bits.append(bits)
            if rejection is None:
                if any(bits != channel_bits[0] for bits in channel_bits[1:]):
                    rejection = "per-channel-code-disagreement"
                elif channel_bits[0] in FIDUCIAL_POLICY["codes"]:
                    decoded = FIDUCIAL_POLICY["codes"].index(channel_bits[0]) + 1
                else:
                    rejection = "unknown-code"
        _require_final("decoded_marker" in candidate and "rejection" in candidate
                       and (candidate.get("decoded_marker") is None or type(candidate["decoded_marker"]) is int)
                       and candidate.get("decoded_marker") == decoded and candidate.get("rejection") == rejection,
                       "fiducial decoded identity/rejection disagrees with actual samples")
        if decoded is not None:
            identified.append((candidate["component_index"], decoded))
    selected = identified[0][0] if len(identified) == 1 and identified[0][1] == marker else None
    _require_final(type(observation.get("identified_count")) is int and observation["identified_count"] == len(identified)
                   and "selected_component_index" in observation and observation["selected_component_index"] == selected
                   and (selected is None or type(observation["selected_component_index"]) is int),
                   "fiducial selected candidate count/domain disagrees")
    return selected


def validate_moving_components(row):
    observation = row.get("color_components")
    _require_final(isinstance(observation, dict) and observation.get("connectivity") == 8
                   and observation.get("minimum_pixels") == 8, "moving component observation missing")
    size = observation.get("image_size")
    _require_final(size == ([384, 128] if row["mirror"] == "Rear" else [256, 128]), "moving component image size")
    components = observation.get("components")
    _require_final(isinstance(components, list), "moving component domain missing")
    totals = [0, 0, 0]
    qualifying = []
    def f32(value):
        return struct.unpack("<f", struct.pack("<f", value))[0]
    for component in components:
        _require_final(isinstance(component, dict), "invalid moving component")
        count, sx, sy = (component.get(key) for key in ("count", "sum_x", "sum_y"))
        bounds, centroid = component.get("bounds"), component.get("centroid")
        _require_final(all(type(value) is int for value in (count, sx, sy)) and count > 0
                       and isinstance(bounds, list) and len(bounds) == 4 and all(type(value) is int for value in bounds),
                       "invalid moving component counts/bounds")
        x0, y0, x1, y1 = bounds
        _require_final(0 <= x0 <= x1 < size[0] and 0 <= y0 <= y1 < size[1]
                       and count <= (x1 - x0 + 1) * (y1 - y0 + 1)
                       and count * x0 <= sx <= count * x1 and count * y0 <= sy <= count * y1,
                       "moving component bounds/sums disagree")
        _require_final(isinstance(centroid, list) and len(centroid) == 2
                       and all(type(value) in (int, float) and math.isfinite(value) for value in centroid)
                       and [f32(value) for value in centroid] == [f32(sx / count), f32(sy / count)],
                       "moving component centroid disagrees with exact sums")
        totals = [a + b for a, b in zip(totals, (count, sx, sy), strict=True)]
        if count >= 8:
            qualifying.append(component)
    _require_final(all(type(observation.get(key)) is int for key in ("raw_count", "raw_sum_x", "raw_sum_y", "qualifying_count"))
                   and totals == [observation[key] for key in ("raw_count", "raw_sum_x", "raw_sum_y")]
                   and totals[0] <= size[0] * size[1] and len(qualifying) == observation["qualifying_count"],
                   "moving component complete totals/eligibility disagree")
    selected_index = validate_moving_fiducials(row, components, size)
    if row["hidden"]:
        _require_final(totals[0] < 8 and row["pixels"] == totals[0], "hidden-target background false positive")
        expected = [f32(totals[1] / totals[0]), f32(totals[2] / totals[0])] if totals[0] else [-1, -1]
    else:
        _require_final(selected_index is not None, "visible moving fiducial missing, ambiguous or wrong")
        selected = components[selected_index]
        _require_final(row["pixels"] == selected["count"], "selected moving component count disagrees")
        expected = selected["centroid"]
    _require_final(isinstance(row["centroid"], list) and len(row["centroid"]) == 2
                   and all(type(value) in (int, float) and math.isfinite(value) for value in row["centroid"])
                   and [f32(value) for value in row["centroid"]] == [f32(value) for value in expected],
                   "selected moving component centroid disagrees")


def validate_final_mirror_rows(rows, expected):
    channels = {"Left": 0, "Right": 1, "Rear": 2}
    fixtures = [row for row in rows if row.get("kind") == "fixture"]
    _require_final(len(fixtures) == 1 and fixtures[0].get("submission_method") == "RenderingServer.InstanceSetTransform"
                   and fixtures[0].get("scene_physics_interpolation") is True, "diagnostic instance submission declaration missing")
    _require_final(fixtures[0].get("optical_fiducial") == FIDUCIAL_POLICY, "fixture optical identity policy missing")
    members = fixtures[0].get("instance_membership", [])
    _require_final(len(members) == 3 and {value.get("marker") for value in members} == {1, 2, 3},
                   "diagnostic instance membership incomplete")
    instance_ids = [value.get(field) for value in members for field in ("target_instance_rid", "label_instance_rid")]
    _require_final(all(type(value) is int and value > 0 for value in instance_ids) and len(set(instance_ids)) == 6
                   and all(value.get("target_interpolated") is False and value.get("label_interpolated") is False for value in members),
                   "diagnostic instance membership invalid/aliased/interpolated")
    membership = {value["marker"]: value for value in members}
    hidden = set()
    grouped = {}
    frames = {}
    for row in rows:
        if row.get("kind") != "completed-mirror":
            continue
        stage, mirror = row["stage"], row["mirror"]
        _require_final(stage in expected and mirror in channels and row["marker"] == channels[mirror] + 1, "wrong target/stage/channel")
        before, after = row["before_draw"], row["after_draw"]
        for held in (before, after):
            _require_final(all(held.get(field) == membership[row["marker"]][field]
                               for field in ("target_instance_rid", "label_instance_rid")), "submitted instance not owned by marker")
            label = held.get("label")
            _require_final(isinstance(label, list) and len(label) == 4 and all(
                isinstance(vector, list) and len(vector) == 3 and all(type(value) in (int, float) and math.isfinite(value)
                    for value in vector) for vector in label), "submitted label matrix missing/invalid")
        for effective in ("effective_mirror", "effective_main", "assigned_mirror"):
            for held in (before, after):
                matrix = held.get(effective)
                _require_final(isinstance(matrix, list) and len(matrix) == 4 and all(
                    isinstance(vector, list) and len(vector) == 3 and all(
                        type(value) in (int, float) and math.isfinite(value) for value in vector)
                    for vector in matrix), "effective camera observation missing/invalid")
            _require_final(before[effective] == after[effective], "effective camera held pose changed")
        for held in (before, after):
            _require_final(held.get("mirror_interpolated") is False and held.get("mirror_interpolation_enabled") is False
                           and held["assigned_mirror"] == held["effective_mirror"],
                           "effective mirror does not match current explicitly assigned camera pose")
        _require_final(before == after and before["frame"] == row["frame"] == row["completed_frame"]
                       and row["requested_frame"] <= row["frame"], "held pose is not the completed draw")
        key = stage, mirror
        _require_final(row["frame"] > frames.get(key, -1), "duplicate or unordered completed draw")
        frames[key] = row["frame"]
        _require_final(row["selectors"] and set(row["selectors"]) == {channels[mirror]}
                       and row["material_rids"] and len(set(row["material_rids"])) == 1
                       and row["feed_rid"] > 0 and row["shader"] == "res://game/Vehicle/mirror_display.gdshader",
                       "actual material/texture/selector binding missing")
        origin = before["origin"]
        _require_final(row["target_world"] == before["target"][3] and row["target_absolute"] == [
            origin[name] + value for name, value in zip(("OriginWorldX", "OriginWorldY", "OriginWorldZ"), row["target_world"], strict=True)
        ], "target absolute identity is not bound to the actual stream origin")
        validate_moving_components(row)
        if row["hidden"]:
            _require_final(stage == "static-ride" and row["pixels"] < 8, "hidden-target background false positive")
            if row["update_count"] >= 3:
                hidden.add(mirror)
            continue
        p = row["main_projection"]
        behind, pixels = p["behind"], p["pixels"]
        _require_final(len(behind) == len(pixels) == len(p["corners"]) == 8
                       and all(type(value) is bool for value in behind)
                       and all((value is None) == flag for flag, value in zip(behind, pixels, strict=True)), "complete target projection domain missing")
        width, height = p["viewport_size"]
        outside = all(behind) or not any(behind) and (
            all(value[0] < 0 for value in pixels) or all(value[0] > width for value in pixels)
            or all(value[1] < 0 for value in pixels) or all(value[1] > height for value in pixels))
        _require_final(outside and row["main_outside"] is True and p["center_in_frustum"] is False,
                       "numbered target is not outside actual main projection")
        if row["pixels"] >= 8:
            error = _native_distance2(row["centroid"], row["target_projection"])
            _require_final(math.isfinite(error) and error <= 5 and row["projection_error_px"] <= 5,
                           "target pixels disagree with held native projection")
            grouped.setdefault(key, []).append(row["centroid"])
    _require_final(hidden == set(channels), "missing original three hidden-target controls")
    for stage in expected:
        if stage in ("static-ride", "lod-inward"):
            continue
        for mirror in channels:
            points = grouped.get((stage, mirror), [])
            _require_final(len(points) >= 10 and max(p[0] for p in points) - min(p[0] for p in points) >= 3,
                           f"missing moving target coverage in {stage}/{mirror}")


def validate_final_driving_rows(rows, frames, results):
    physics = [row for row in frames if row.get("kind") == "physics-frame"]
    continuous = ["keyboard-acceleration", "coast", "keyboard-braking", "reverse"]
    for stage in continuous:
        values = [row for row in physics if row["stage"] == stage]
        _require_final(len(values) >= 240 and all(row["frozen"] is False for row in values), "live interval missing or frozen: " + stage)
        _require_final(results[stage]["teleports"] == 0 and not any(row.get("kind") == "fixture-placement" and row["stage"] == stage for row in frames),
                       "continuous driving was replaced by body placement")
    coast = [row for row in physics if row["stage"] == "coast" and row["stage_frame"] > 1]
    _require_final(all(all(row["input"][key] == 0 for key in ("Throttle", "Brake", "Reverse", "Handbrake", "Steering")) for row in coast)
                   and all(not row["input"]["StationaryHold"] and not row["input"]["Reset"] for row in coast)
                   and coast[-1]["signed_travel_m"] > 0 and coast[-1]["signed_speed_mps"] > 0,
                   "neutral throttle-release/coast interval absent")
    _require_final(sum(row.get("kind") == "throttle-release" for row in frames) == 1, "throttle-release event omitted or repeated")
    for stage, key in (("keyboard-acceleration", "Throttle"), ("keyboard-braking", "Brake"), ("reverse", "Reverse")):
        _require_final(any(row["input"][key] > 0.1 for row in physics if row["stage"] == stage), "live input absent: " + stage)
    _require_final(results["reverse"]["signed_travel_m"] < -2 and results["reverse"]["final_signed_speed_mps"] < -5,
                   "reverse is a posed lamp state rather than actual travel")
    live = [row for row in rows if row.get("kind") == "live-draw"]
    _require_final(set(row["stage"] for row in live) == set(FINAL_DRIVING) and all(row["frozen"] is False for row in live),
                   "complete unfrozen live dashboard draw inventory missing")
    for stage in continuous:
        samples = [row for row in live if row["stage"] == stage]
        _require_final(len(samples) >= 10 and all(row["presentation"]["display"]["gear"] == row["presentation"]["gear"] for row in samples),
                       "actual live dashboard samples missing")
        _require_final(all(row["autopilot"] is False and row["automation_override"] is False for row in samples),
                       "continuous driving does not use actual unoverridden inputs")
    gears = {row["presentation"]["gear"] for row in live if row["stage"] in ("keyboard-acceleration", "coast")}
    _require_final(len(gears - {"R", "N", "P"}) >= 2, "no actual forward shift observed")
    _require_final(any(row["presentation"]["reverse"] and row["presentation"]["gear"] == "R" for row in live if row["stage"] == "reverse"),
                   "moving reverse dashboard/lamp conjunction missing")
    pan = [row for row in physics if row["stage"] == "mirror-pan"]
    _require_final(any(row["camera_look_actions"]["left"] > 0 for row in pan)
                   and any(row["camera_look_actions"]["right"] > 0 for row in pan)
                   and max(sum(a * b for a, b in zip(row["camera_forward"], row["basis"][0], strict=True)) for row in pan)
                   - min(sum(a * b for a, b in zip(row["camera_forward"], row["basis"][0], strict=True)) for row in pan) > 0.1,
                   "actual camera pan/input response missing")
    lod = [row for row in live if row["stage"] == "lod-inward"]
    order = []
    for row in lod:
        if not order or order[-1] != row["actual_lod"]:
            order.append(row["actual_lod"])
    _require_final(order == [2, 1, 0] and results["lod-inward"]["inward_lod_order"] == order
                   and all(row["camera"] == lod[0]["camera"] for row in lod)
                   and math.dist(lod[0]["body"][3], lod[-1]["body"][3]) > 65,
                   "inward LOD sequence is not actual live travel past a fixed observer")
    rebase = [row for row in live if row["stage"] == "natural-rebase"]
    counts = [row["local_origin"]["RebaseCount"] for row in rebase]
    _require_final(max(counts) > min(counts) and results["natural-rebase"]["rebases"] > 0
                   and all(row["autopilot"] is True for row in rebase), "natural runtime rebase not observed")
    for mirror in ("Left", "Right", "Rear"):
        samples = [row for row in rows if row.get("kind") == "completed-mirror" and row["stage"] == "natural-rebase" and row["mirror"] == mirror]
        _require_final({min(counts), max(counts)}.issubset({row["before_draw"]["origin"]["RebaseCount"] for row in samples}),
                       "mirror has no actual completed image on both sides of rebase")


def validate_final_presentation_rows(events, frames, results):
    for stage in (value for value in FINAL_PRESENTATION if value.startswith("partial-")):
        commands = [row for row in events if row["stage"] == stage and row["kind"] == "opening-command"]
        reversals = [row for row in events if row["stage"] == stage and row["kind"] == "partial-reversal"]
        _require_final(len(commands) == 2 and [row["open"] for row in commands] == [True, False]
                       and len(reversals) == 1 and 0.5 <= reversals[0]["fraction"] < 1
                       and commands[0]["frame"] < reversals[0]["frame"] == commands[1]["frame"], "actual partial UI reversal missing")
        name = stage.removeprefix("partial-")
        joint = results[stage]["state"]["joints"][name]
        _require_final(abs(joint["angle_deg"]) < 0.01 and joint["target"] == 0, "partial command did not close")
        values = [row for row in frames if row["stage"] == stage]
        _require_final(any(row["state"]["joints"][name]["target"] == 1 for row in values)
                       and any(row["state"]["joints"][name]["target"] == 0 for row in values), "no actual open/close target sequence")
    cycles = [row for row in events if row["kind"] == "wiper-cycle"]
    _require_final(len(cycles) >= 3 and [row["cycle"] for row in cycles] == list(range(1, len(cycles) + 1))
                   and all(row["enabled"] and abs(row["left_deg"]) < 1 and abs(row["right_deg"]) < 1 for row in cycles), "three actual full wiper cycles absent")
    sweep = [row for row in frames if row["stage"] == "wipers-three-cycles"]
    _require_final(sweep and all(row["state"]["wipers"] for row in sweep), "wipers were interrupted")
    previous_frame = -1
    for cycle in cycles:
        segment = [row for row in sweep if previous_frame < row["render_frame"] <= cycle["frame"]]
        _require_final(any(row["state"]["joints"]["Wiper_L"]["angle_deg"] < -77.5 and
                           row["state"]["joints"]["Wiper_R"]["angle_deg"] < -73.5 for row in segment), "cycle lacks complete two-blade sweep")
        previous_frame = cycle["frame"]
    park = results["wipers-park"]["state"]
    _require_final(not park["wipers"] and not park["wiper_parking"] and all(abs(park["joints"][name]["angle_deg"]) < 1 for name in ("Wiper_L", "Wiper_R")), "wipers did not park")
    for stage in (value for value in FINAL_PRESENTATION if value.startswith("wall-")):
        state = results[stage]["state"]
        _require_final(state["headlights"] is stage.endswith("-on") and state["brakes"] is ("brake" in stage), "wrong matched night lamp combination")


def validate_final_capture(summary, out, record):
    probe = record.get("diagnostic_probe")
    if probe not in ("driving-final", "presentation-final"):
        return
    required = {"game/Automation/EnduranceSedanPresentationScenario.cs", "game/Main.cs", "data/assets/vehicles/derived/endurance-sedan.glb",
                "assets/vehicles/endurance-sedan/endurance-sedan.generated.tscn", "docs/vehicles/endurance-sedan/specification.json"}
    if probe == "driving-final":
        required |= {"game/Automation/EnduranceSedanScenario.cs", "data/assets/vehicles/sources/endurance-sedan.blend"}
    _require_final(required.issubset(summary["input_hashes"]), "native source identity domain incomplete")
    for role, digest in summary["input_hashes"].items():
        _require_final(record["input_hashes"].get(role) == digest, "native source hash differs: " + role)
    _require_final(summary["physics_hz"] == 120 and summary["loaded_asset"] == "endurance-sedan", "wrong native vehicle/physics")
    results = {row["stage"]: row for row in summary["completed_stages"]}
    frame_path = out / ("frames.jsonl" if probe == "driving-final" else "presentation-frames.jsonl")
    frames = [json.loads(line) for line in frame_path.read_text(encoding="utf-8").splitlines()]
    if probe == "presentation-final":
        validate_final_presentation_rows(summary["final_events"], frames, results)
        captures = [row for row in summary["captures"] if row["stage"].startswith("wall-")]
        _require_final(len(captures) == 4 and all(row["lighting"] == "Night" and row["camera_position"] == captures[0]["camera_position"] for row in captures), "matched wall lighting/camera missing")
        return
    _require_final(summary["final_capture"] is True and summary["final_lighting"] == record["mirror_lighting"], "wrong final driving selection")
    proof = summary["final_mirrors"]
    log_path = out / "final-live.jsonl"
    _require_final(proof["completed"] is True and proof["failure"] is None and proof["sha256"] == sha(log_path), "native live proof incomplete/hash changed")
    rows = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
    validate_final_mirror_rows(rows, FINAL_DRIVING)
    validate_final_driving_rows(rows, frames, results)
    dashboards = summary["final_dashboard"]
    _require_final([row["stage"] for row in dashboards] == FINAL_DRIVING, "live dashboard image inventory missing")
    for row in dashboards:
        _png_final(row, out, [512, 192])
    for row in rows:
        if row.get("png"):
            _png_final(row["png"], out, [384, 128] if row["mirror"] == "Rear" else [256, 128])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["driving", "presentation"], required=True)
    parser.add_argument("--blockout", action="store_true", help="Driving-only historical blockout revalidation; omits production presentation and the final LOD-driving stage")
    parser.add_argument("--project-root", type=Path, default=ROOT)
    parser.add_argument("--upstream-evidence", type=Path)
    parser.add_argument("--probe", choices=["mirrors", "driving-final", "presentation-final"])
    parser.add_argument("--lighting", choices=["daylight", "night"], help="mirrors/driving-final diagnostic lighting; default daylight")
    parser.add_argument("--mirror-camera-source-y", type=float)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--godot", type=Path, default=os.environ.get("GODOT_BIN"), help="pinned official .NET executable, or GODOT_BIN")
    parser.add_argument("--route-package", type=Path, required=True)
    parser.add_argument("--ffmpeg-bin", type=Path, help="directory containing ffmpeg/ffprobe; defaults to the local cache or PATH")
    parser.add_argument("--timeout-seconds", type=int, default=900)
    args = parser.parse_args()
    if args.godot is None:
        parser.error("provide --godot or GODOT_BIN")
    try:
        expected = select_capture_cases(args.mode, args.probe, args.lighting, args.blockout, args.mirror_camera_source_y)
    except ValueError as error:
        parser.error(str(error))
    if args.blockout and args.mode != "driving":
        parser.error("--blockout requires --mode driving")
    if args.mirror_camera_source_y is not None and (not math.isfinite(args.mirror_camera_source_y) or not 0.4 <= args.mirror_camera_source_y <= 0.7):
        parser.error("--mirror-camera-source-y must be finite and within 0.4..0.7 meters")
    if not 30 <= args.timeout_seconds <= 3600:
        parser.error("--timeout-seconds must be within 30..3600")
    root = args.project_root.resolve()
    out = args.output.resolve()
    if out.exists():
        parser.error("existing evidence is preserved; choose a fresh --output")
    if not (root / "project.godot").is_file():
        parser.error("project.godot is absent from --project-root")
    out.mkdir(parents=True, exist_ok=False)
    (out / "capture-runner-input.py").write_bytes(Path(__file__).read_bytes())
    override = root / "override.cfg"
    prior_override = {"path": str(override), "existed": override.exists(), "sha256": sha(override) if override.exists() else None}
    record = dict(task_id="P1-018", mode=args.mode, status="failed", started_utc=utc(), platform=platform.platform(),
                  blockout=args.blockout,
                  milestone="M5", python=sys.version, project_root=str(root), git_revision=None,
                  commands=[], failures=[], override_before=prior_override, human_approval_reference=None,
                  limitations=["Movie Maker is fixed-timestep inspection, not real-time performance evidence.",
                               "Driving uses actual InputMap-conditioned physics; presentation uses explicitly posed fixtures.",
                               "Human visual, handling, physical-device and rights approvals remain open."])
    override_owned = False
    env = os.environ.copy()
    env.update(DOTNET_GCgen0size="800000")

    def run(label, argv, timeout=60):
        started = utc()
        with (out / (label + ".stdout.log")).open("wb") as stdout, (out / (label + ".stderr.log")).open("wb") as stderr:
            process = subprocess.Popen([str(x) for x in argv], cwd=root, env=env, stdout=stdout, stderr=stderr,
                                       creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                                       start_new_session=os.name != "nt")
            timed_out = False
            try:
                exit_code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], stdout=stderr, stderr=stderr, check=False)
                else:
                    os.killpg(process.pid, signal.SIGKILL)
                exit_code = process.wait(timeout=30)
        result = dict(label=label, argv=[str(x) for x in argv], pid=process.pid, started_utc=started,
                      finished_utc=utc(), exit_code=exit_code, timed_out=timed_out)
        record["commands"].append(result)
        return result

    def require_command(label, argv, timeout=60, importing=False):
        result = run(label, argv, timeout)
        log = "\n".join((out / (label + suffix)).read_text(encoding="utf-8-sig", errors="replace") for suffix in [".stdout.log", ".stderr.log"])
        checked = "\n".join(line for line in log.splitlines() if not importing or line not in IMPORT_WARNINGS)
        if result["exit_code"] != 0 or result["timed_out"] or FATAL.search(checked):
            raise RuntimeError(f"{label} failed exit, timeout or strict diagnostic checks")
        return log.strip()

    try:
        if args.blockout:
            record["scope"] = "later revalidation of historical blockout using the corrected runtime/capture fixture"
            record["lod_policy"] = "fixed LOD0; production presenter and distance selection omitted by --sedan-blockout"
            record["limitations"].append("Historical blockout only: production mechanisms, materials, interior controls, mirrors and final LOD-driving acceptance are omitted.")
        if args.probe:
            record["diagnostic_probe"] = args.probe
            record["mirror_lighting"] = args.lighting or "daylight"
            record["diagnostic_side_mirror_camera_source_y_m"] = args.mirror_camera_source_y
            record["limitations"].append("Explicit diagnostic/supplement; does not replace the original17/55-stage gates. Numbered targets and wall receivers are nonshipping capture fixtures.")
        if root != ROOT:
            if not args.upstream_evidence or "reports" not in root.parts:
                raise RuntimeError("An isolated candidate project requires its retained upstream evidence.")
            upstream = json.loads(args.upstream_evidence.read_text(encoding="utf-8-sig"))
            record["upstream_asset_diagnostic"] = {"path": str(args.upstream_evidence.resolve()), "sha256": sha(args.upstream_evidence), "status": upstream["status"]}
            record["limitations"].append("Isolated candidate capture only. Upstream asset-diagnostic failures remain open; this does not establish final asset acceptance.")
        if prior_override["existed"]:
            raise RuntimeError("Existing override.cfg preserved; use an isolated capture project or coordinate its settings before retrying.")
        cache = ROOT / ".tools/ffmpeg-9.0.1/ffmpeg-9.0.1-essentials_build/bin"
        directory = args.ffmpeg_bin or (cache if cache.is_dir() else None)
        suffix = ".exe" if os.name == "nt" else ""
        ffmpeg = directory / ("ffmpeg" + suffix) if directory else Path(shutil.which("ffmpeg") or "missing-ffmpeg")
        ffprobe = directory / ("ffprobe" + suffix) if directory else Path(shutil.which("ffprobe") or "missing-ffprobe")
        args.godot, args.route_package, ffmpeg, ffprobe = [path.resolve() for path in [args.godot, args.route_package, ffmpeg, ffprobe]]
        for executable in [args.godot, ffprobe, ffmpeg, args.route_package]:
            if not executable.is_file():
                raise FileNotFoundError(executable)
        record["expected_stages"] = expected
        record["git_revision"] = require_command("git-revision", ["git", "rev-parse", "HEAD"])
        env["CANNONBALL_GIT_REVISION"] = record["git_revision"]
        record["environment"] = {key: env[key] for key in ["DOTNET_GCgen0size", "CANNONBALL_GIT_REVISION"]}
        record["external_inputs"] = [{"path": str(p), "sha256": sha(p)} for p in [args.godot, args.route_package, ffprobe, ffmpeg, Path(__file__)]]
        record["tool_versions"] = {}
        for label, command in [("godot", [args.godot, "--version"]), ("dotnet", ["dotnet", "--version"]),
                               ("ffmpeg", [ffmpeg, "-version"]), ("ffprobe", [ffprobe, "-version"])]:
            record["tool_versions"][label] = require_command(label + "-version", command)
        if record["tool_versions"]["godot"] != json.loads((root / "tools/assets/toolchain.json").read_text())["godot"]["version"]:
            raise RuntimeError("Godot is not the pinned official .NET version")
        if record["tool_versions"]["dotnet"] != json.loads((root / "global.json").read_text())["sdk"]["version"]:
            raise RuntimeError("The executing .NET SDK does not match global.json")
        build = require_command("build", ["dotnet", "build", "Cannonball.csproj", "--nologo"], 300)
        if "0 Warning(s)" not in build or "0 Error(s)" not in build:
            raise RuntimeError("C# capture build was not warning-free")
        require_command("import", [args.godot, "--headless", "--path", root, "--editor", "--import"], 300, importing=True)
        record["input_hashes"] = {str(p.relative_to(root)).replace("\\", "/"): sha(p) for p in [
            *sorted((root / "game").rglob("*.cs")), *sorted((root / "game/Vehicle").rglob("*.tres")),
            *sorted((root / "game").rglob("*.cs.uid")),
            *sorted((root / "game/Vehicle").rglob("*.gdshader")),
            *sorted(p for p in (root / "assets").rglob("*") if p.is_file()),
            *sorted(p for p in (root / "src/Cannonball.Core").rglob("*.cs") if not set(p.parts) & {"bin", "obj"}),
            root / "game/Vehicle/mirror_display.gdshader.uid",
            root / "game/Vehicle/Visuals/EnduranceSedan.tscn", root / "project.godot",
            root / "Cannonball.csproj", root / "global.json", root / "tools/vehicles/vehicle_contract.json",
            root / "scripts/verify-endurance-sedan.sh",
            root / ".godot/mono/temp/bin/Debug/Cannonball.dll", root / ".godot/mono/temp/bin/Debug/Cannonball.Core.dll",
            root / "data/assets/vehicles/sources/endurance-sedan.blend",
            root / "data/assets/vehicles/derived/endurance-sedan.glb",
            root / "assets/vehicles/endurance-sedan/endurance-sedan.generated.tscn",
            root / "assets/vehicles/endurance-sedan/endurance-sedan.generated.textures.json",
            root / "docs/vehicles/endurance-sedan/specification.json", root / "tools/assets/toolchain.json",
        ]}
        with override.open("xb") as stream:
            stream.write(OVERRIDE)
        override_owned = True
        (out / "capture-override.cfg").write_bytes(OVERRIDE)
        record["override_capture_sha256"] = sha(override)
        movie = out / (args.mode + ".ogv")
        command = [args.godot, "--path", root, "--rendering-method", "forward_plus", "--resolution", "2560x1440", "--fullscreen",
                   "--fixed-fps", "30", "--write-movie", movie, "--log-file", out / "engine.log", "--",
                   "--route-package=" + str(args.route_package.resolve()), "--vehicle=endurance-sedan", "--environment-quality=high",
                   "--endurance-sedan-profile" if args.mode == "driving" else "--sedan-presentation-profile",
                   "--run-save-path=" + str(out / "run-save.json"),
                   "--sedan-captures", "--sedan-evidence-dir=" + str(out), "--telemetry-path=" + str(out / "telemetry.jsonl")]
        if args.probe == "driving-final":
            command += ["--sedan-driving-probe=driving-final", "--sedan-final-lighting=" + record["mirror_lighting"]]
        elif args.probe:
            command.append("--sedan-presentation-probe=" + args.probe)
            if args.probe == "mirrors":
                command.append("--sedan-mirror-lighting=" + record["mirror_lighting"])
        if args.blockout:
            command.append("--sedan-blockout")
        if args.mirror_camera_source_y is not None:
            command.append("--sedan-mirror-camera-source-y=" + str(args.mirror_camera_source_y))
        process = run("godot", command, args.timeout_seconds)
        if process["exit_code"] != 0 or process["timed_out"]:
            record["failures"].append(f"Godot capture did not exit cleanly: {process}")
        logs = "\n".join((out / name).read_text(encoding="utf-8-sig", errors="replace") for name in ["godot.stdout.log", "godot.stderr.log", "engine.log"] if (out / name).exists())
        save_path_line = next((line for line in logs.splitlines() if line.startswith("CANNONBALL_AUTOMATION_SAVE_PATH ")), None)
        record["run_save_path"] = str(out / "run-save.json")
        try:
            if not save_path_line or Path(json.loads(save_path_line.removeprefix("CANNONBALL_AUTOMATION_SAVE_PATH "))["path"]).resolve() != out / "run-save.json":
                record["failures"].append("Run save was not isolated to its evidence directory")
        except (ValueError, KeyError, TypeError):
            record["failures"].append("Run save isolation record invalid")
        record["failure_markers"] = [match.group(0) for match in FATAL.finditer(logs)]
        if record["failure_markers"]:
            record["failures"].append("Engine error, warning, fatal or resource-leak diagnostic")
        if "CANNONBALL_SHUTDOWN_OK drains=2 producers_stopped=true" not in logs:
            record["failures"].append("Controlled shutdown did not complete")
        marker = f"CANNONBALL_ENDURANCE_SEDAN_OK vehicle=endurance-sedan stages={len(expected)} " if args.mode == "driving" else f"CANNONBALL_SEDAN_PRESENTATION_OK stages={len(expected)} posed=true rendered=true"
        if marker not in logs:
            record["failures"].append("Capture suite completion marker absent")
        for stage in expected:
            stage_marker = (f"CANNONBALL_ENDURANCE_SEDAN_STAGE_OK vehicle=endurance-sedan stage={stage} " if args.mode == "driving"
                            else f"CANNONBALL_SEDAN_PRESENTATION_STAGE_OK stage={stage} posed=true")
            if stage_marker not in logs:
                record["failures"].append("Stage completion marker absent: " + stage)
        try:
            validate_summary(out, args.mode, expected, record)
        except (OSError, ValueError, KeyError, TypeError, RuntimeError) as exception:
            record["failures"].append("Invalid summary/capture evidence: " + str(exception))
        # Decode partial failed-scenario movies too. Actual decoded frame count
        # comes from FFprobe; duration times frame rate is only a timeline.
        probe = run("movie-probe", [ffprobe, "-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries", "stream=codec_name,width,height,r_frame_rate,avg_frame_rate,nb_read_frames,duration:format=duration", "-of", "json", movie], 180)
        if probe["exit_code"] != 0 or probe["timed_out"]:
            raise RuntimeError("Movie stream probe failed")
        movie_info = json.loads((out / "movie-probe.stdout.log").read_text(encoding="utf-8"))
        record["decoded_movie"] = movie_info
        stream = movie_info["streams"][0]
        if stream["width"] != 2560 or stream["height"] != 1440 or int(stream["nb_read_frames"]) < 30:
            record["failures"].append("Decoded movie is not 2560x1440 with a nonempty sequence")
        decode = run("movie-full-decode", [ffmpeg, "-hide_banner", "-v", "error", "-xerror", "-i", movie, "-map", "0:v:0", "-f", "null", "-"], 180)
        if decode["exit_code"] != 0 or decode["timed_out"]:
            record["failures"].append("Complete movie stream decode failed")
    except Exception as exception:
        record["failures"].append(f"{type(exception).__name__}: {exception}")
    finally:
        if "input_hashes" in record:
            record["input_hashes_after"] = {relative: sha(root / relative) if (root / relative).is_file() else None for relative in record["input_hashes"]}
            if record["input_hashes"] != record["input_hashes_after"]:
                record["failures"].append("Captured source/runtime/asset inputs changed during the native run")
        if override_owned:
            if override.exists() and override.read_bytes() == OVERRIDE:
                override.unlink()
                record["override_owned_file_removed"] = True
            else:
                record["failures"].append("Owned override changed or disappeared during capture; unexpected file left untouched")
        record["override_after"] = {"exists": override.exists(), "sha256": sha(override) if override.exists() else None}
        record["finished_utc"] = utc()
        record["status"] = "failed" if record["failures"] else "passed"
        record["output_hashes"] = {str(p.relative_to(out)).replace("\\", "/"): sha(p) for p in sorted(out.rglob("*")) if p.is_file() and p.name != "process.json"}
        (out / "process.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: record.get(key) for key in ["status", "mode", "rendered_capture_count", "failures", "override_after"]}), flush=True)
    return 0 if record["status"] == "passed" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as exception:
        print(f"Capture configuration failed: {exception}", file=sys.stderr)
        raise SystemExit(1) from None
