using Cannonball.Core.Content;
using Cannonball.Core.Routes;
using Cannonball.Core.Runs;
using Cannonball.Game.Vehicle;
using Cannonball.Game.World.Environments;
using Cannonball.Game.World.RoadVisuals;
using Godot;

namespace Cannonball.Game.World;

public sealed partial class WorldStreamer : Node3D
{
    public const double VisualLookAheadMeters = 10_000;
    public const double ActivePhysicsAheadMeters = 2_000;
    public const double ActivePhysicsBehindMeters = 50;
    public const double RetainBehindMeters = 500;
    public const double PrefetchHorizonSeconds = 112;
    public const float RebaseThresholdMeters = 1_000;

    /// <summary>How far the vehicle must travel before the desired chunk set is recomputed.</summary>
    private const double DesiredRefreshIntervalMeters = 1.0;
    public const double ChunkBuildBudgetMilliseconds = 40;
    public const double InitialChunkBuildBudgetMilliseconds = 50;
    public const double CollisionBuildBudgetMilliseconds = 40;
    public const double InitialCollisionBuildBudgetMilliseconds = 50;
    public const int MaximumConcurrentChunkReads = 2;
    public const double ShortCorridorLoopResetLeadMeters = 25;
    public const double EnvironmentNearVisibilityMeters = 1_000;
    public const double EnvironmentMidVisibilityMeters = 4_000;
    public const double EnvironmentDistantVisibilityMeters = 12_000;
    public const int EnvironmentCollisionBudget = 0;

    private readonly Dictionary<string, RoadChunk> _loaded = new(StringComparer.Ordinal);
    private readonly Dictionary<string, RouteContextPlan?> _routeContextPlans =
        new(StringComparer.Ordinal);
    private readonly Dictionary<string, JunctionSeam> _junctionSeams = new(StringComparer.Ordinal);
    private readonly Dictionary<string, RouteChunkContent> _content = new(StringComparer.Ordinal);
    private readonly Dictionary<string, RegionalEnvironmentChunk> _environmentChunks =
        new(StringComparer.Ordinal);
    private readonly Dictionary<string, PendingRead> _pending = new(StringComparer.Ordinal);
    private readonly Queue<string> _loadQueue = [];
    private readonly HashSet<string> _queued = new(StringComparer.Ordinal);
    private readonly HashSet<string> _failed = new(StringComparer.Ordinal);
    private HashSet<string> _desiredVisual = new(StringComparer.Ordinal);
    private HashSet<string> _desiredCollision = new(StringComparer.Ordinal);
    /// <summary>True while a loaded chunk still needs collision that the one-per-refresh budget deferred.</summary>
    private bool _collisionBacklog;
    private RouteContentPackage _package = null!;
    private IRouteChunkContentSource _source = null!;
    private LinearRoutePlan _routePlan = null!;
    private HashSet<string> _routePlanEdgeIds = new(StringComparer.Ordinal);
    private IReadOnlyDictionary<(string FromEdgeId, string ToEdgeId), JunctionConnector>
        _routePlanConnectors =
            new Dictionary<(string FromEdgeId, string ToEdgeId), JunctionConnector>();
    private IReadOnlyList<RouteManifestSpan> _manifests = [];
    private RouteFrame _frame = null!;
    private RoadVisualKit _roadVisualKit = null!;
    private EnvironmentVisualKit _environmentVisualKit = null!;
    private RoadStructureSet _roadStructures = null!;
    private MeshInstance3D _terrainBackdrop = null!;
    private ShaderMaterial? _backdropMaterial;
    private double _terrainBackdropElevation = double.PositiveInfinity;
    private CannonballVehicle? _vehicle;
    private RouteWorldPoint _localOriginWorld;
    private string _currentEdgeId = string.Empty;
    private double _routeDistanceMeters;
    private double _lateralOffsetMeters;
    // Negative infinity so the first frame's travel distance always triggers a
    // refresh, without a separate primed flag.
    private double _lastDesiredRefreshDistanceMeters = double.NegativeInfinity;
    private RouteWorldPoint _initialRoadWorldPoint;
    private double? _reviewTargetDistanceMeters;
    private bool _reviewTargetReady;
    private readonly HashSet<string> _reviewReadyChunksSeen = new(StringComparer.Ordinal);
    private readonly HashSet<string> _reviewEdgesVisited = new(StringComparer.Ordinal);
    private readonly HashSet<string> _topologyObservedChunks = new(StringComparer.Ordinal);
    private readonly HashSet<string> _topologyCollisionChunks = new(StringComparer.Ordinal);
    private readonly HashSet<JunctionMovement> _observedConnectorMovements = [];
    private readonly HashSet<string> _observedConnectorIds = new(StringComparer.Ordinal);
    private readonly HashSet<string> _desiredBranchPrewarm = new(StringComparer.Ordinal);
    private readonly HashSet<string> _branchPrewarmSeen = new(StringComparer.Ordinal);
    private readonly HashSet<string> _branchPrewarmEvicted = new(StringComparer.Ordinal);
    private readonly HashSet<string> _junctionSeamsBuilt = new(StringComparer.Ordinal);
    private readonly HashSet<string> _junctionTransitionSeamsBuilt = new(StringComparer.Ordinal);
    private readonly HashSet<string> _loadedRouteContextAutomationIds = new(StringComparer.Ordinal);
    private readonly HashSet<string> _routeContextAutomationIdsSeen = new(StringComparer.Ordinal);
    private readonly HashSet<string> _roadVisualObservedChunks = new(StringComparer.Ordinal);
    private readonly HashSet<string> _opposingCarriagewayChunksSeen = new(StringComparer.Ordinal);
    private readonly HashSet<string> _environmentObservedChunks = new(StringComparer.Ordinal);
    private readonly HashSet<EnvironmentRegion> _environmentRegionsSeen = [];
    private readonly List<double> _chunkBuildSamplesMilliseconds = [];
    private readonly List<double> _collisionBuildSamplesMilliseconds = [];
    private bool _roadVisualContractsResolved = true;
    private bool _roadVisualSignageContractsResolved = true;
    private int _roadVisualReflectorsSeen;
    private int _roadVisualBarrierSegmentsSeen;
    private int _roadVisualGuardrailSegmentsSeen;
    private int _roadVisualGuideSignsSeen;
    private int _roadVisualRouteShieldsSeen;
    private int _roadVisualStandardRouteShieldsSeen;
    private int _roadVisualGeometricLaneArrowsSeen;
    private int _roadVisualTypographyFallbacksSeen;
    private int _roadVisualServiceIconsSeen;
    private int _roadVisualGoreChunksSeen;
    private bool _preserveResumeStateThroughReady;

    public double RouteDistanceMeters => _routeDistanceMeters;
    public double LocalOriginMeters { get; private set; }
    public double CurrentLookAheadMeters { get; private set; } = ActivePhysicsAheadMeters;
    public int LoadedChunkCount => _loaded.Count;
    public int ExpectedChunkCount => _manifests.Count;
    public int ReviewReadyChunkCount => _loaded.Values.Count(chunk => chunk.HasReviewGeometry());
    public int RebaseCount { get; private set; }
    public int ChunkFailureCount { get; private set; }
    public double MaximumBuildMilliseconds { get; private set; }
    public double MaximumCollisionBuildMilliseconds { get; private set; }
    public int CollisionBuildCount { get; private set; }
    public int CollisionRemovalCount { get; private set; }
    public int MinimumObservedLaneCount { get; private set; } = int.MaxValue;
    public int MaximumObservedLaneCount { get; private set; }
    public int TopologyTransitionCount { get; private set; }
    public int TopologyCollisionTransitionChunkCount => _topologyCollisionChunks.Count;
    public bool ObservedGoreGeometry { get; private set; }
    public double MaximumPavedWidthMeters { get; private set; }
    public IReadOnlyCollection<JunctionMovement> ObservedConnectorMovements =>
        _observedConnectorMovements;
    public IReadOnlyCollection<string> ObservedConnectorIds => _observedConnectorIds;
    public IReadOnlyCollection<string> PrewarmedBranchChunkIds => _branchPrewarmSeen;
    public IReadOnlyCollection<string> DesiredBranchPrewarmChunkIds => _desiredBranchPrewarm;
    public IReadOnlyCollection<string> EvictedBranchChunkIds => _branchPrewarmEvicted;
    public int BranchPrewarmCount => _branchPrewarmSeen.Count;
    public int BranchPrewarmEvictionCount => _branchPrewarmEvicted.Count;
    public int MaximumVisualChunkCount { get; private set; }
    public int MaximumCollisionChunkCount { get; private set; }
    public int ObservedVisualOnlyChunkCount { get; private set; }
    public string CurrentEdgeId => _currentEdgeId;
    public double CurrentEdgeDistanceMeters =>
        _routeDistanceMeters - _routePlan.GetEdge(_currentEdgeId).StartMeters;
    public double CurrentLateralOffsetMeters => _lateralOffsetMeters;
    public int CurrentLaneIndex { get; private set; }
    public string CurrentStableLaneId { get; private set; } = string.Empty;
    public string ActiveConnectorId { get; private set; } = string.Empty;
    public string ContentVersion => _package.Graph.ContentVersion;
    public double TotalRouteLengthMeters => RouteLengthMeters;
    public IReadOnlyList<string> RoutePlan => _routePlan.EdgeIds;
    public int OpposingCarriagewayChunksSeen => _opposingCarriagewayChunksSeen.Count;
    public int LoadedEnvironmentChunkCount => _environmentChunks.Count;
    public double MaximumEnvironmentBuildMilliseconds { get; private set; }
    public Vector3 InitialRoadPoint { get; private set; }
    public Vector3 InitialRoadForward { get; private set; }
    public Vector3 InitialVehiclePoint { get; private set; }
    public string InitialVehicleLaneId { get; private set; } = string.Empty;
    public bool ShortCorridorLoopEnabled { get; set; }
    public int CompletedShortCorridorLoops { get; private set; }
    public int CrossedReviewDistanceThresholdCount { get; private set; }
    public double MaximumLocalCoordinateMeters { get; private set; }
    public double MaximumJunctionGapMeters { get; private set; }
    public int JunctionSeamBuildCount => _junctionSeamsBuilt.Count;
    public int JunctionTerrainSeamCount =>
        _junctionSeams.Values.Count(seam => seam.HasTerrainSurface);
    public bool JunctionTerrainSurfacesComplete =>
        _junctionSeams.Count > 0 && _junctionSeams.Values.All(seam => seam.HasTerrainSurface);
    public bool HasTerrainBackdrop =>
        _terrainBackdrop is { Mesh: not null, Visible: true };
    public IReadOnlyCollection<string> JunctionSeamIdsBuilt => _junctionSeamsBuilt;
    public IReadOnlyCollection<RoadChunk> LoadedRoadChunks => _loaded.Values;
    public IReadOnlyCollection<JunctionSeam> LoadedJunctionSeams => _junctionSeams.Values;
    public IReadOnlyCollection<string> JunctionTransitionSeamIdsBuilt =>
        _junctionTransitionSeamsBuilt;
    public IReadOnlyCollection<string> RouteContextAutomationIds =>
        _loadedRouteContextAutomationIds;
    public IReadOnlyCollection<string> RouteContextAutomationIdsSeen =>
        _routeContextAutomationIdsSeen;
    public int MileMarkerCount { get; private set; }
    public int ExitSignCount { get; private set; }
    public int HighwayTransferSignCount { get; private set; }
    public int MileMarkersSeen => _routeContextAutomationIdsSeen.Count(id =>
        id.StartsWith("route-context.marker.", StringComparison.Ordinal));
    public int ExitSignsSeen => _routeContextAutomationIdsSeen.Count(id =>
        id.StartsWith("route-context.exit.", StringComparison.Ordinal));
    public int HighwayTransferSignsSeen => _routeContextAutomationIdsSeen.Count(id =>
        id.StartsWith("route-context.transfer.", StringComparison.Ordinal));
    public IReadOnlyCollection<string> ReviewReadyChunkIdsSeen => _reviewReadyChunksSeen;
    public IReadOnlyCollection<string> ReviewEdgeIdsVisited => _reviewEdgesVisited;
    public IReadOnlyList<double> ChunkBuildSamplesMilliseconds => _chunkBuildSamplesMilliseconds;
    public IReadOnlyList<double> CollisionBuildSamplesMilliseconds =>
        _collisionBuildSamplesMilliseconds;

    public IReadOnlyList<RouteContextLabelDiagnostic> GetRouteContextLabelDiagnostics(
        Camera3D camera) => _loaded.Values
        .SelectMany(chunk => chunk.GetRouteContextLabelDiagnostics(camera))
        .OrderBy(item => item.AutomationId, StringComparer.Ordinal)
        .ToArray();

    public bool ConfigureRoadStructureReviewCamera(Camera3D camera) =>
        _roadStructures.ConfigureReviewCamera(camera);

    public bool SetRoadStructureReviewTarget()
    {
        var placement = _roadStructures.ReviewPlacement;
        if (placement is null || !_routePlanEdgeIds.Contains(placement.UpperEdgeId))
        {
            return false;
        }
        SetReviewDistance(GetRouteDistance(
            placement.UpperEdgeId,
            placement.UpperEdgeDistanceMeters));
        return true;
    }

    public RoadVisualSnapshot CaptureRoadVisualSnapshot()
    {
        var structures = _roadStructures.CaptureSnapshot();
        return new RoadVisualSnapshot(
            _roadVisualKit.ProfileId,
            _roadVisualObservedChunks.Count,
            _roadVisualObservedChunks.Count > 0 && _roadVisualContractsResolved,
            _roadVisualReflectorsSeen,
            _roadVisualBarrierSegmentsSeen,
            _roadVisualGuardrailSegmentsSeen,
            _roadVisualSignageContractsResolved,
            _roadVisualGuideSignsSeen,
            _roadVisualRouteShieldsSeen,
            _roadVisualStandardRouteShieldsSeen,
            _roadVisualGeometricLaneArrowsSeen,
            _roadVisualTypographyFallbacksSeen,
            _roadVisualServiceIconsSeen,
            _roadVisualGoreChunksSeen,
            _roadVisualKit.SharedMaterialCount,
            _roadVisualKit.SharedMeshCount,
            _roadVisualKit.RetroreflectiveMaterialCount,
            _roadVisualKit.SurfaceSource,
            _roadVisualKit.TerrainSource,
            structures.BridgeDeckCount,
            structures.OverpassOpeningCount,
            structures.StructureCount,
            structures.SemanticNodeCount,
            structures.ContractResolved);
    }

    public EnvironmentStreamSnapshot CaptureEnvironmentSnapshot()
    {
        var chunks = _environmentChunks.Values
            .Select(chunk => chunk.CaptureSnapshot())
            .OrderBy(chunk => chunk.ChunkId, StringComparer.Ordinal)
            .ToArray();
        var seam = CalculateTerrainSeam();
        return new EnvironmentStreamSnapshot(
            _environmentVisualKit.ProfileId,
            chunks,
            _environmentObservedChunks.Count,
            _environmentRegionsSeen.OrderBy(region => region).ToArray(),
            chunks.Sum(chunk => chunk.NearInstanceCount),
            chunks.Sum(chunk => chunk.MidInstanceCount),
            chunks.Sum(chunk => chunk.DistantInstanceCount),
            chunks.Sum(chunk => chunk.SemanticNodeCount),
            chunks.Count(chunk => chunk.TerrainTriangleCount > 0),
            chunks.Sum(chunk => chunk.TerrainVertexCount),
            chunks.Sum(chunk => chunk.TerrainTriangleCount),
            seam.Meters,
            seam.Ratio,
            seam.MagnitudeMeters,
            _environmentVisualKit.SharedMaterialCount,
            _environmentVisualKit.SharedMeshCount,
            _environmentVisualKit.TextureSource,
            _environmentVisualKit.ConiferSource,
            chunks.All(chunk => chunk.CollisionFree),
            EnvironmentCollisionBudget,
            MaximumEnvironmentBuildMilliseconds,
            EnvironmentNearVisibilityMeters,
            EnvironmentMidVisibilityMeters,
            EnvironmentDistantVisibilityMeters,
            RetainBehindMeters);
    }

    public EnvironmentRegion GetEnvironmentRegion(double routeDistanceMeters)
    {
        var normalized = RouteLengthMeters <= 0
            ? 0
            : Math.Clamp(routeDistanceMeters / RouteLengthMeters, 0, 0.999999);
        return normalized switch
        {
            < 0.25 => EnvironmentRegion.Mountain,
            < 0.50 => EnvironmentRegion.Foothill,
            < 0.75 => EnvironmentRegion.Plains,
            _ => EnvironmentRegion.UrbanEdge,
        };
    }

    public WorldStreamSnapshot CaptureStreamSnapshot() => new(
        _localOriginWorld.X,
        _localOriginWorld.Y,
        _localOriginWorld.Z,
        LocalOriginMeters,
        RebaseCount,
        _loaded.Keys.OrderBy(id => id, StringComparer.Ordinal).ToArray(),
        _loaded.Where(entry => entry.Value.HasCollision)
            .Select(entry => entry.Key)
            .OrderBy(id => id, StringComparer.Ordinal)
            .ToArray());
    public bool ReviewTargetReady => _reviewTargetReady;
    public int ReviewReadyChunkCountSeen => _reviewReadyChunksSeen.Count;
    public int ReviewEdgeCountVisited => _reviewEdgesVisited.Count;
    public int CollisionChunkCount => _loaded.Values.Count(chunk => chunk.HasCollision);
    public int VisualOnlyChunkCount => _loaded.Count - CollisionChunkCount;
    public int DesiredVisualChunkCount => _desiredVisual.Count;
    public int DesiredCollisionChunkCount => _desiredCollision.Count;
    public bool IsStreamingSettled =>
        _desiredVisual.SetEquals(_loaded.Keys) &&
        !_pending.Keys.Any(_desiredVisual.Contains) &&
        _desiredCollision.SetEquals(_loaded
            .Where(entry => entry.Value.HasCollision)
            .Select(entry => entry.Key));
    public bool IsEnvironmentStreamingSettled =>
        _loaded.Keys
            .Where(id => _content.TryGetValue(id, out var content) &&
                _routePlanEdgeIds.Contains(content.EdgeId))
            .ToHashSet(StringComparer.Ordinal)
            .SetEquals(_environmentChunks.Keys);
    public double LoadedVisualAheadMeters => _loaded.Count == 0
        ? 0
        : Math.Max(
            0,
            _manifests
                .Where(span => _loaded.ContainsKey(span.Manifest.Id))
                .Select(span => span.EndMeters)
                .DefaultIfEmpty(_routeDistanceMeters)
                .Max() - _routeDistanceMeters);

    public static ChunkManifest FindInitialManifest(
        RouteContentPackage package,
        IReadOnlyList<string>? routePlanEdgeIds = null)
    {
        ArgumentNullException.ThrowIfNull(package);
        var plan = LinearRoutePlan.Build(
            package.Graph,
            routePlanEdgeIds ?? package.Chunks.Values.Select(manifest => manifest.EdgeId));
        var firstEdgeId = plan.Edges[0].EdgeId;
        return package.Chunks.Values
            .Where(manifest => string.Equals(manifest.EdgeId, firstEdgeId, StringComparison.Ordinal))
            .OrderBy(manifest => manifest.StartMeters)
            .ThenBy(manifest => manifest.Id, StringComparer.Ordinal)
            .FirstOrDefault()
            ?? throw new InvalidDataException($"Route edge '{firstEdgeId}' has no chunk manifests.");
    }

    public static ChunkManifest FindManifest(
        RouteContentPackage package,
        string edgeId,
        double edgeDistanceMeters)
    {
        ArgumentNullException.ThrowIfNull(package);
        ArgumentException.ThrowIfNullOrWhiteSpace(edgeId);
        var edge = package.Graph.GetEdge(edgeId);
        if (!double.IsFinite(edgeDistanceMeters) || edgeDistanceMeters < 0 ||
            edgeDistanceMeters > edge.LengthMeters)
        {
            throw new ArgumentOutOfRangeException(nameof(edgeDistanceMeters));
        }
        return package.Chunks.Values
            .Where(manifest =>
                string.Equals(manifest.EdgeId, edgeId, StringComparison.Ordinal) &&
                manifest.StartMeters <= edgeDistanceMeters &&
                manifest.EndMeters >= edgeDistanceMeters)
            .OrderBy(manifest => edgeDistanceMeters == manifest.EndMeters ? 1 : 0)
            .ThenBy(manifest => manifest.StartMeters)
            .ThenBy(manifest => manifest.Id, StringComparer.Ordinal)
            .FirstOrDefault()
            ?? throw new InvalidDataException(
                $"Route edge '{edgeId}' has no chunk at {edgeDistanceMeters:F3} meters.");
    }

    public void Configure(
        RouteContentPackage package,
        IRouteChunkContentSource source,
        RouteChunkContent initialChunk,
        IReadOnlyList<string>? routePlanEdgeIds = null,
        IReadOnlyList<string>? routePlanConnectorIds = null,
        RoutePosition? resumePosition = null,
        WorldStreamSnapshot? resumeStream = null,
        IReadOnlyList<RouteChunkContent>? resumeChunks = null,
        RouteNavigationState? resumeNavigation = null,
        IReadOnlyList<RoadStructurePlacement>? roadStructures = null)
    {
        if (IsInsideTree())
        {
            throw new InvalidOperationException("WorldStreamer must be configured before entering the scene tree.");
        }
        _package = package;
        _roadVisualKit = RoadVisualKit.FromCommandLine();
        _environmentVisualKit = EnvironmentVisualKit.FromCommandLine();
        _routeContextPlans.Clear();
        _source = source;
        _routePlan = LinearRoutePlan.Build(
            package.Graph,
            routePlanEdgeIds ?? package.Chunks.Values.Select(manifest => manifest.EdgeId));
        _routePlanEdgeIds = _routePlan.EdgeIds.ToHashSet(StringComparer.Ordinal);
        _routePlanConnectors = BuildRoutePlanConnectors(routePlanConnectorIds);
        if (!string.Equals(initialChunk.EdgeId, _routePlan.Edges[0].EdgeId, StringComparison.Ordinal) ||
            initialChunk.StartMeters != 0)
        {
            throw new InvalidDataException("The initial route chunk is not the first chunk in the corridor plan.");
        }
        if (resumePosition is { } position)
        {
            _preserveResumeStateThroughReady = true;
            var edge = package.Graph.GetEdge(position.EdgeId);
            position.Validate(edge);
            if (!_routePlanEdgeIds.Contains(position.EdgeId))
            {
                throw new InvalidDataException(
                    $"Resume edge '{position.EdgeId}' is outside the selected route plan.");
            }
            _currentEdgeId = position.EdgeId;
            _routeDistanceMeters = _routePlan.GetEdge(position.EdgeId).StartMeters +
                position.DistanceMeters;
            _lateralOffsetMeters = position.LateralOffsetMeters;
            CurrentLaneIndex = position.LaneIndex;
            CurrentStableLaneId = position.StableLaneId
                ?? edge.GetLaneSection(position.DistanceMeters).Lanes.Single(lane =>
                    lane.Index == position.LaneIndex).Id;
            if (resumeStream is { } stream)
            {
                _localOriginWorld = new RouteWorldPoint(
                    stream.OriginWorldX,
                    stream.OriginWorldY,
                    stream.OriginWorldZ);
                LocalOriginMeters = stream.LocalOriginRouteMeters;
                RebaseCount = stream.RebaseCount;
            }
            UpdateCurrentLane();
            ActiveConnectorId = resumeNavigation?.ActiveConnectorId ?? string.Empty;
        }
        else
        {
            _currentEdgeId = initialChunk.EdgeId;
            UpdateCurrentLane();
        }
        _manifests = package.Chunks.Values
            .Where(manifest => _routePlanEdgeIds.Contains(manifest.EdgeId))
            .Select(manifest =>
            {
                var edge = _routePlan.GetEdge(manifest.EdgeId);
                return new RouteManifestSpan(
                    manifest,
                    edge.StartMeters + manifest.StartMeters,
                    edge.StartMeters + manifest.EndMeters);
            })
            .OrderBy(span => span.StartMeters)
            .ThenBy(span => span.Manifest.Id, StringComparer.Ordinal)
            .ToArray();
        if (_manifests.Count == 0)
        {
            throw new InvalidDataException($"Route edge '{_currentEdgeId}' has no chunk manifests.");
        }
        _frame = new RouteFrame(initialChunk.Samples);
        _roadStructures = RoadStructureSet.Create(
            roadStructures ?? [],
            _roadVisualKit,
            _frame,
            _localOriginWorld);
        AddChild(_roadStructures);
        // The backdrop plane has 0..1 UVs across 30 km and white vertex colour,
        // so it gets its own ground-shader instance with metre scaling and fixed
        // plains weights; the kit material is the fallback.
        _backdropMaterial = _roadVisualKit.Terrain is ShaderMaterial groundShader
            ? (ShaderMaterial)groundShader.Duplicate()
            : null;
        _backdropMaterial?.SetShaderParameter("uv_scale_meters", new Vector2(30_000, 30_000));
        _backdropMaterial?.SetShaderParameter("weight_override", new Vector4(0.55f, 0.25f, 0.0f, 1.0f));
        _terrainBackdrop = new MeshInstance3D
        {
            Name = "TerrainBackdrop",
            Mesh = new PlaneMesh
            {
                Size = new Vector2(30_000, 30_000),
            },
            MaterialOverride = (Material?)_backdropMaterial ?? _roadVisualKit.Terrain,
            CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
        };
        RoadVisualKit.MarkSemantic(_terrainBackdrop, "road.visual.terrain.backdrop");
        AddChild(_terrainBackdrop);
        _initialRoadWorldPoint = _frame.ToWorld(initialChunk.Samples[0]);
        InitialRoadPoint = _initialRoadWorldPoint.RelativeTo(_localOriginWorld);
        InitialRoadForward = _frame.InitialForward;
        var initialEdge = _package.Graph.GetEdge(_routePlan.Edges[0].EdgeId);
        var initialLane = LaneGeometryProfile.Evaluate(initialEdge, 0).Lanes
            .Where(lane => lane.WidthMeters > 0.5)
            .MinBy(lane => Math.Abs(lane.CenterMeters))
            ?? throw new InvalidDataException(
                $"Route edge '{initialEdge.Id}' has no active starting lane.");
        InitialVehicleLaneId = initialLane.Id;
        InitialVehiclePoint = _initialRoadWorldPoint
            .Add(InitialRoadForward.Cross(Vector3.Up).Normalized() *
                (float)initialLane.CenterMeters)
            .RelativeTo(_localOriginWorld);
        if (resumePosition is null)
        {
            AttachChunk(initialChunk);
        }
        else
        {
            if (resumeChunks is null || resumeChunks.Count == 0)
            {
                throw new InvalidDataException(
                    "Resume state does not contain any loaded route chunks.");
            }
            foreach (var content in resumeChunks.OrderBy(content => content.Id, StringComparer.Ordinal))
            {
                AttachChunk(content);
            }
            if (!_content.Values.Any(content =>
                    string.Equals(content.EdgeId, _currentEdgeId, StringComparison.Ordinal) &&
                    CurrentEdgeDistanceMeters >= content.StartMeters &&
                    CurrentEdgeDistanceMeters <= content.EndMeters))
            {
                throw new InvalidDataException(
                    "Resume stream state does not contain the saved route position.");
            }
        }
        var resumedCollisionIds = resumeStream?.CollisionChunkIds.ToHashSet(StringComparer.Ordinal);
        foreach (var chunk in _loaded.Values)
        {
            UpdateCollisionState(
                chunk,
                active: resumedCollisionIds?.Contains(chunk.ChunkId) ??
                    string.Equals(chunk.EdgeId, _currentEdgeId, StringComparison.Ordinal));
        }
        var routeStartApronMeters = _loaded.TryGetValue(initialChunk.Id, out var routeStartChunk)
            ? routeStartChunk.StartApronMeters
            : RoadChunk.RouteStartApronMeters;
        var routeStartBarrier = routeStartChunk?.HasRouteStartBarrier ?? false;
        var routeStartBarrierCollision = routeStartChunk?.HasRouteStartBarrierCollision ?? false;
        SetMeta("automation_id", "world.streamer");
        SetMeta(
            "automation_state",
            new Godot.Collections.Dictionary
            {
                ["initial_route_distance_m"] = resumePosition is null ? 0 : _routeDistanceMeters,
                ["initial_vehicle_lane_id"] = InitialVehicleLaneId,
                ["initial_vehicle_lateral_m"] = initialLane.CenterMeters,
                ["route_start_apron_m"] = routeStartApronMeters,
                ["route_start_barrier"] = routeStartBarrier,
                ["route_start_barrier_collision"] = routeStartBarrierCollision,
            });
        GD.Print(
            $"CANNONBALL_ROUTE_START_OK apron_m={routeStartApronMeters:0.0} " +
            $"barrier={routeStartBarrier && routeStartBarrierCollision} " +
            $"lane={InitialVehicleLaneId} lateral_m={initialLane.CenterMeters:0.00}");
    }

    public override void _Ready()
    {
        if (_manifests.Count == 0)
        {
            throw new InvalidOperationException("WorldStreamer was not configured with a route package.");
        }
        if (!_preserveResumeStateThroughReady)
        {
            RefreshDesiredChunks();
        }
    }

    public override void _Process(double delta)
    {
        _ = delta;
        // Chunk completion and streaming decisions are the road subsystem's
        // per-frame cost; environment chunks charge themselves separately as they
        // build, so this region is not their parent.
        using var region = Cannonball.Core.Performance.SubsystemProfiler.Measure(
            Cannonball.Core.Performance.SubsystemProfiler.Subsystem.Road);
        _preserveResumeStateThroughReady = false;
        var completedALoad = CompletePendingLoads();
        // RefreshDesiredChunks allocates a HashSet and several LINQ enumerators, and
        // it ran on every rendered frame - over 800 a second in a reference capture.
        // At 50 m/s the car advances 6 cm per frame against 2 km chunks, so the answer
        // was identical thousands of times in a row. That churn was the dominant
        // source of the 11.7 KB per frame that filled gen0 every two seconds and cost
        // a 30-40 ms collection pause each time.
        //
        // Refreshing per metre of travel keeps roughly 50 refreshes a second at
        // motorway speed, far more often than a 2 km chunk boundary can arrive, while
        // removing the per-frame allocation.
        //
        // Travel alone is not a sufficient trigger. RefreshDesiredChunks is what
        // *starts* loads, so gating it purely on movement deadlocks a vehicle that
        // cannot move until its chunks arrive: no movement, no refresh, no loads, no
        // movement. That hung the 500-mile traversal outright. Refreshing whenever a
        // load completes keeps the queue draining while stationary, and costs nothing
        // during steady cruise where completions are rare.
        //
        // Collision is a third trigger. RefreshDesiredChunks builds at most one
        // collision body per call to bound the frame cost, so a stationary
        // position that needs two - a review target or a resume point beside a
        // chunk boundary - was left with the second one unbuilt: no travel, no
        // completion, no refresh, and IsStreamingSettled stayed false until the
        // scenario's frame budget ran out. The environment-streaming review had
        // failed that way on its urban-edge stage since the per-metre gate landed.
        var travelled = Math.Abs(_routeDistanceMeters - _lastDesiredRefreshDistanceMeters);
        if (completedALoad || _collisionBacklog || travelled >= DesiredRefreshIntervalMeters)
        {
            _lastDesiredRefreshDistanceMeters = _routeDistanceMeters;
            RefreshDesiredChunks();
        }
    }

    public override void _PhysicsProcess(double delta)
    {
        _ = delta;
        if (_vehicle is null)
        {
            return;
        }

        // Projecting the vehicle onto the route and resolving edge, lane and
        // route context is what ADR-0023 calls road and route context work.
        using var region = Cannonball.Core.Performance.SubsystemProfiler.Measure(
            Cannonball.Core.Performance.SubsystemProfiler.Subsystem.RouteContext);

        if (_reviewTargetDistanceMeters is { } reviewDistance)
        {
            _routeDistanceMeters = reviewDistance;
            UpdateCurrentEdge();
            TryPlaceVehicleForReview();
            return;
        }

        var previousEdgeId = _currentEdgeId;
        var previousLaneId = CurrentStableLaneId;
        UpdateRouteProjection();
        UpdateCurrentEdge();
        if (!string.Equals(previousEdgeId, _currentEdgeId, StringComparison.Ordinal))
        {
            UpdateLaneAcrossRouteEdges(previousEdgeId, previousLaneId);
        }
        else
        {
            UpdateCurrentLane();
        }
        var crossedSeams = _routeDistanceMeters >= 300 ? 3
            : _routeDistanceMeters >= 200 ? 2
            : _routeDistanceMeters >= 100 ? 1
            : 0;
        CrossedReviewDistanceThresholdCount = Math.Max(
            CrossedReviewDistanceThresholdCount,
            crossedSeams);
        if (ShortCorridorLoopEnabled &&
            _routeDistanceMeters >= Math.Max(0, RouteLengthMeters - ShortCorridorLoopResetLeadMeters))
        {
            _routeDistanceMeters = 0;
            UpdateCurrentEdge();
            _lateralOffsetMeters = 0;
            UpdateCurrentLane();
            var resetPoint = _initialRoadWorldPoint.RelativeTo(_localOriginWorld);
            _vehicle.RouteDistanceMeters = 0;
            _vehicle.TargetRoadPoint = resetPoint;
            _vehicle.TargetRoadForward = InitialRoadForward;
            _vehicle.RequestResetToRoad(resetPoint, InitialRoadForward);
            CompletedShortCorridorLoops++;
            GD.Print($"CANNONBALL_SHORT_CORRIDOR_LOOP count={CompletedShortCorridorLoops}");
            return;
        }
        var targetDistance = Math.Min(RouteLengthMeters, _routeDistanceMeters + 20);
        var target = GetRoadPose(targetDistance);
        var targetPoint = OffsetForActiveLane(target.Point, target.Forward, targetDistance);
        _vehicle.RouteDistanceMeters = _routeDistanceMeters;
        _vehicle.TargetRoadPoint = targetPoint.RelativeTo(_localOriginWorld);
        _vehicle.TargetRoadForward = target.Forward;

        var horizontal = new Vector3(_vehicle.Position.X, 0, _vehicle.Position.Z);
        if (horizontal.Length() < RebaseThresholdMeters)
        {
            return;
        }

        Rebase(horizontal);
    }

    /// <summary>
    /// The road at a route distance in local coordinates, with the paved
    /// edges from the authoritative lane profile, for scenarios that place
    /// the vehicle relative to the carriageway rather than the lane centre.
    /// </summary>
    public RoadProbe ProbeRoad(double routeDistanceMeters)
    {
        var distance = Math.Clamp(routeDistanceMeters, 0, RouteLengthMeters);
        var pose = GetRoadPose(distance);
        var planEdge = _routePlan.GetEdgeAtDistance(distance);
        var edge = _package.Graph.GetEdge(planEdge.EdgeId);
        var layout = LaneGeometryProfile.Evaluate(
            edge,
            Math.Clamp(distance - planEdge.StartMeters, 0, edge.LengthMeters));
        return new RoadProbe(
            pose.Point.RelativeTo(_localOriginWorld),
            pose.Forward,
            layout.PavedLeftMeters,
            layout.PavedRightMeters);
    }

    public void Track(CannonballVehicle vehicle)
    {
        _vehicle = vehicle;
        vehicle.RouteDistanceMeters = _routeDistanceMeters;
        var pose = GetRoadPose(_routeDistanceMeters);
        vehicle.TargetRoadPoint = OffsetForActiveLane(
            pose.Point,
            pose.Forward,
            _routeDistanceMeters).RelativeTo(_localOriginWorld);
        vehicle.TargetRoadForward = pose.Forward;
    }

    public void SetReviewDistance(double distanceMeters)
    {
        _reviewTargetDistanceMeters = Math.Clamp(distanceMeters, 0, RouteLengthMeters);
        _routeDistanceMeters = _reviewTargetDistanceMeters.Value;
        _reviewTargetReady = false;
        ActiveConnectorId = string.Empty;
        UpdateCurrentEdge();
        UpdateCurrentLane();
        RefreshDesiredChunks();
    }

    public void SetReviewPosition(double distanceMeters, string stableLaneId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(stableLaneId);
        _reviewTargetDistanceMeters = Math.Clamp(distanceMeters, 0, RouteLengthMeters);
        _routeDistanceMeters = _reviewTargetDistanceMeters.Value;
        _reviewTargetReady = false;
        ActiveConnectorId = string.Empty;
        UpdateCurrentEdge();
        var edge = _package.Graph.GetEdge(_currentEdgeId);
        var layout = LaneGeometryProfile.Evaluate(edge, CurrentEdgeDistanceMeters);
        var lane = layout.Lanes.SingleOrDefault(candidate =>
                string.Equals(candidate.Id, stableLaneId, StringComparison.Ordinal) &&
                candidate.WidthMeters > 0.5)
            ?? throw new InvalidDataException(
                $"Route edge '{edge.Id}' has no active lane '{stableLaneId}' at " +
                $"{CurrentEdgeDistanceMeters:F3} meters.");
        _lateralOffsetMeters = lane.CenterMeters;
        CurrentLaneIndex = lane.Index;
        CurrentStableLaneId = lane.Id;
        UpdateCurrentLane();
        RefreshDesiredChunks();
    }

    public double GetRouteDistance(string edgeId, double edgeDistanceMeters)
    {
        var planEdge = _routePlan.GetEdge(edgeId);
        var edge = _package.Graph.GetEdge(edgeId);
        if (!double.IsFinite(edgeDistanceMeters) || edgeDistanceMeters < 0 ||
            edgeDistanceMeters > edge.LengthMeters)
        {
            throw new ArgumentOutOfRangeException(nameof(edgeDistanceMeters));
        }
        return planEdge.StartMeters + edgeDistanceMeters;
    }

    public void BeginReviewTraversal()
    {
        if (_reviewTargetDistanceMeters is null || !_reviewTargetReady || _vehicle is null)
        {
            throw new InvalidOperationException(
                "Review traversal requires a settled review target and tracked vehicle.");
        }
        var pose = GetRoadPose(_routeDistanceMeters);
        var roadPoint = OffsetForActiveLane(pose.Point, pose.Forward, _routeDistanceMeters);
        var localPoint = roadPoint.RelativeTo(_localOriginWorld);
        _vehicle.TargetRoadPoint = localPoint;
        _vehicle.TargetRoadForward = pose.Forward;
        _vehicle.RequestResetToRoad(localPoint, pose.Forward);
        _reviewTargetDistanceMeters = null;
        _reviewTargetReady = false;
    }

    public bool HasObservedConnectorMovement(JunctionMovement movement) =>
        _observedConnectorMovements.Contains(movement);

    private double RouteLengthMeters => _routePlan.TotalLengthMeters;

    private void RefreshDesiredChunks()
    {
        var speed = _vehicle?.SpeedMetersPerSecond ?? 0;
        CurrentLookAheadMeters = _reviewTargetDistanceMeters.HasValue
            ? VisualLookAheadMeters
            : Math.Clamp(
                speed * PrefetchHorizonSeconds,
                ActivePhysicsAheadMeters,
                VisualLookAheadMeters);
        var first = Math.Max(0, _routeDistanceMeters - RetainBehindMeters);
        var last = Math.Min(RouteLengthMeters, _routeDistanceMeters + CurrentLookAheadMeters);

        var directVisual = _manifests
            .Where(span => span.EndMeters >= first && span.StartMeters <= last)
            .Select(span => span.Manifest.Id)
            .ToHashSet(StringComparer.Ordinal);
        var opposingVisual = GetOpposingVisualChunkIds(directVisual);
        _desiredBranchPrewarm.Clear();
        foreach (var branchId in directVisual
                     .Select(id => _package.Chunks[id])
                     .SelectMany(manifest => manifest.ProbableBranchChunkIds))
        {
            if (!directVisual.Contains(branchId))
            {
                _desiredBranchPrewarm.Add(branchId);
            }
        }
        _desiredVisual = directVisual
            .Concat(_desiredBranchPrewarm)
            .Concat(opposingVisual)
            .ToHashSet(StringComparer.Ordinal);
        _desiredCollision = _manifests
            .Where(span =>
                span.EndMeters >= _routeDistanceMeters - ActivePhysicsBehindMeters &&
                span.StartMeters <= _routeDistanceMeters + ActivePhysicsAheadMeters)
            .Select(span => span.Manifest.Id)
            .ToHashSet(StringComparer.Ordinal);
        foreach (var (id, pending) in _pending.ToArray())
        {
            if (!_desiredVisual.Contains(id))
            {
                pending.Cancellation.Cancel();
            }
        }
        foreach (var manifest in _desiredVisual.Select(id => _package.Chunks[id]))
        {
            if (!_loaded.ContainsKey(manifest.Id) &&
                !_pending.ContainsKey(manifest.Id) &&
                !_queued.Contains(manifest.Id) &&
                !_failed.Contains(manifest.Id))
            {
                _queued.Add(manifest.Id);
                _loadQueue.Enqueue(manifest.Id);
            }
        }
        StartPendingReads(_desiredVisual);

        var collisionBuiltThisRefresh = false;
        var collisionBacklog = false;
        foreach (var (id, chunk) in _loaded.ToArray())
        {
            var needsCollision = _desiredCollision.Contains(id);
            if (!needsCollision || !collisionBuiltThisRefresh || chunk.HasCollision)
            {
                var changed = UpdateCollisionState(
                    chunk,
                    needsCollision);
                collisionBuiltThisRefresh |= changed && needsCollision;
            }
            else
            {
                collisionBacklog = true;
            }
            if (!_desiredVisual.Contains(id))
            {
                if (_branchPrewarmSeen.Contains(id))
                {
                    _branchPrewarmEvicted.Add(id);
                }
                UpdateCollisionState(
                    chunk,
                    active: false);
                foreach (var automationId in chunk.RouteContextAutomationIds)
                {
                    _loadedRouteContextAutomationIds.Remove(automationId);
                }
                MileMarkerCount -= chunk.MileMarkerCount;
                ExitSignCount -= chunk.ExitSignCount;
                HighwayTransferSignCount -= chunk.HighwayTransferSignCount;
                _loaded.Remove(id);
                if (_environmentChunks.Remove(id, out var environmentChunk))
                {
                    environmentChunk.QueueFree();
                }
                _content.Remove(id);
                RemoveJunctionSeamsForChunk(id);
                chunk.QueueFree();
            }
        }
        _collisionBacklog = collisionBacklog;
        RefreshJunctionSeamCollisions();
        MaximumVisualChunkCount = Math.Max(MaximumVisualChunkCount, _loaded.Count);
        MaximumCollisionChunkCount = Math.Max(MaximumCollisionChunkCount, CollisionChunkCount);
        ObservedVisualOnlyChunkCount = Math.Max(ObservedVisualOnlyChunkCount, VisualOnlyChunkCount);
    }

    private HashSet<string> GetOpposingVisualChunkIds(IEnumerable<string> directChunkIds)
    {
        var result = new HashSet<string>(StringComparer.Ordinal);
        foreach (var chunkId in directChunkIds)
        {
            var manifest = _package.Chunks[chunkId];
            var edge = _package.Graph.GetEdge(manifest.EdgeId);
            var opposing = _package.Graph.GetOpposingEdge(edge.Id);
            if (opposing is null)
            {
                continue;
            }
            var opposingStart = opposing.LengthMeters *
                (1 - manifest.EndMeters / edge.LengthMeters);
            var opposingEnd = opposing.LengthMeters *
                (1 - manifest.StartMeters / edge.LengthMeters);
            foreach (var candidate in _package.Chunks.Values.Where(candidate =>
                         string.Equals(
                             candidate.EdgeId,
                             opposing.Id,
                             StringComparison.Ordinal) &&
                         candidate.EndMeters >= opposingStart &&
                         candidate.StartMeters <= opposingEnd))
            {
                result.Add(candidate.Id);
            }
        }
        return result;
    }

    /// <summary>Completes one finished chunk read, if any. True when one completed.</summary>
    private bool CompletePendingLoads()
    {
        // Searched with a plain loop: this runs on every rendered frame, and the
        // LINQ form allocated a delegate and boxed the dictionary's enumerator.
        string? id = null;
        PendingRead? pending = null;
        foreach (var entry in _pending)
        {
            if (entry.Value.Task.IsCompleted)
            {
                id = entry.Key;
                pending = entry.Value;
                break;
            }
        }
        if (id is null || pending is null)
        {
            return false;
        }
        _pending.Remove(id);
        pending.Cancellation.Dispose();
        var task = pending.Task;
        if (task.IsCanceled)
        {
            return true;
        }
        if (!task.IsCompletedSuccessfully)
        {
            RecordChunkFailure(id, task.Exception?.GetBaseException());
            return true;
        }
        try
        {
            AttachChunk(task.Result);
        }
        catch (Exception exception)
        {
            RecordChunkFailure(id, exception);
        }
        return true;
    }

    private void StartPendingReads(IReadOnlySet<string> desired)
    {
        while (_pending.Count < MaximumConcurrentChunkReads && _loadQueue.TryDequeue(out var id))
        {
            _queued.Remove(id);
            if (!desired.Contains(id) || _loaded.ContainsKey(id) || _failed.Contains(id))
            {
                continue;
            }
            var cancellation = new CancellationTokenSource();
            _pending.Add(
                id,
                new PendingRead(_source.LoadChunkAsync(id, cancellation.Token).AsTask(), cancellation));
        }
    }

    private void AttachChunk(RouteChunkContent content)
    {
        if (_loaded.ContainsKey(content.Id))
        {
            return;
        }
        var edge = _package.Graph.GetEdge(content.EdgeId);
        var routeContextPlan = GetRouteContextPlan(edge);
        var planSpan = _routePlanEdgeIds.Contains(content.EdgeId)
            ? _manifests.SingleOrDefault(span =>
                string.Equals(span.Manifest.Id, content.Id, StringComparison.Ordinal))
            : null;
        var chunk = RoadChunk.Create(
            content,
            edge,
            routeContextPlan,
            _frame,
            _localOriginWorld,
            _roadVisualKit,
            extendBehindRouteStart:
                string.Equals(content.EdgeId, _routePlan.Edges[0].EdgeId, StringComparison.Ordinal) &&
                Math.Abs(content.StartMeters) <= 1e-9,
            routeStartMeters: planSpan?.StartMeters ?? double.NaN,
            routeLengthMeters: planSpan is null ? double.NaN : RouteLengthMeters);
        // Budget profiles validate collected timing samples. Normal play keeps valid content
        // loaded instead of turning host scheduling or first-frame JIT into a chunk failure.
        _content.Add(content.Id, content);
        _loaded.Add(content.Id, chunk);
        if (_routePlanEdgeIds.Contains(content.EdgeId))
        {
            var manifest = _manifests.Single(span =>
                string.Equals(span.Manifest.Id, content.Id, StringComparison.Ordinal));
            var routeMidpoint = (manifest.StartMeters + manifest.EndMeters) * 0.5;
            var environmentChunk = RegionalEnvironmentChunk.Create(
                content,
                _frame,
                _localOriginWorld,
                _environmentVisualKit,
                GetEnvironmentRegion(routeMidpoint),
                $"{_package.Graph.ContentVersion}|colorado-proof-corridor",
                manifest.StartMeters,
                RouteLengthMeters);
            _environmentChunks.Add(content.Id, environmentChunk);
            _environmentObservedChunks.Add(content.Id);
            _environmentRegionsSeen.Add(environmentChunk.Region);
            MaximumEnvironmentBuildMilliseconds = Math.Max(
                MaximumEnvironmentBuildMilliseconds,
                environmentChunk.BuildMilliseconds);
            AddChild(environmentChunk);
        }
        var minimumLocalElevation = content.Samples
            .Select(sample => _frame.ToWorld(sample).Y - _localOriginWorld.Y)
            .Min();
        if (minimumLocalElevation < _terrainBackdropElevation)
        {
            _terrainBackdropElevation = minimumLocalElevation;
            _terrainBackdrop.Position = new Vector3(
                0,
                (float)(_terrainBackdropElevation - 5),
                0);
        }
        if (_roadVisualObservedChunks.Add(content.Id))
        {
            var roadVisual = chunk.CaptureRoadVisualSnapshot();
            _roadVisualContractsResolved &= roadVisual.ContractResolved;
            _roadVisualSignageContractsResolved &= roadVisual.SignageContractResolved;
            _roadVisualReflectorsSeen += roadVisual.ReflectorCount;
            _roadVisualBarrierSegmentsSeen += roadVisual.BarrierSegmentCount;
            _roadVisualGuardrailSegmentsSeen += roadVisual.GuardrailSegmentCount;
            _roadVisualGuideSignsSeen += roadVisual.GuideSignCount;
            _roadVisualRouteShieldsSeen += roadVisual.RouteShieldCount;
            _roadVisualStandardRouteShieldsSeen += roadVisual.StandardRouteShieldCount;
            _roadVisualGeometricLaneArrowsSeen += roadVisual.GeometricLaneArrowCount;
            _roadVisualTypographyFallbacksSeen += roadVisual.TypographyFallbackCount;
            _roadVisualServiceIconsSeen += roadVisual.ServiceIconCount;
            _roadVisualGoreChunksSeen += roadVisual.HasGoreGeometry ? 1 : 0;
        }
        if (!_routePlanEdgeIds.Contains(content.EdgeId) &&
            edge.RoadwayKind == RoadwayKind.DividedCarriageway)
        {
            _opposingCarriagewayChunksSeen.Add(content.Id);
        }
        if (_desiredBranchPrewarm.Contains(content.Id))
        {
            _branchPrewarmSeen.Add(content.Id);
        }
        if (_topologyObservedChunks.Add(content.Id))
        {
            MinimumObservedLaneCount = Math.Min(
                MinimumObservedLaneCount,
                chunk.MinimumLaneCount);
            MaximumObservedLaneCount = Math.Max(
                MaximumObservedLaneCount,
                chunk.MaximumLaneCount);
            TopologyTransitionCount += chunk.TransitionCount;
            ObservedGoreGeometry |= chunk.HasGoreGeometry;
            MaximumPavedWidthMeters = Math.Max(
                MaximumPavedWidthMeters,
                chunk.MaximumPavedWidthMeters);
        }
        foreach (var automationId in chunk.RouteContextAutomationIds)
        {
            _loadedRouteContextAutomationIds.Add(automationId);
            _routeContextAutomationIdsSeen.Add(automationId);
        }
        MileMarkerCount += chunk.MileMarkerCount;
        ExitSignCount += chunk.ExitSignCount;
        HighwayTransferSignCount += chunk.HighwayTransferSignCount;
        if (chunk.HasReviewGeometry())
        {
            _reviewReadyChunksSeen.Add(content.Id);
        }
        MaximumBuildMilliseconds = Math.Max(MaximumBuildMilliseconds, chunk.BuildMilliseconds);
        _chunkBuildSamplesMilliseconds.Add(chunk.BuildMilliseconds);
        AddChild(chunk);
        TryBuildJunctionSeams();
    }

    private RouteContextPlan? GetRouteContextPlan(RouteEdge edge)
    {
        if (_routeContextPlans.TryGetValue(edge.Id, out var cached))
        {
            return cached;
        }
        var semantics = _package.Semantics;
        var plan = semantics is not null &&
            !semantics.IsLegacySynthesis &&
            HasRenderableRouteContext(edge, semantics)
                ? RouteContextPlanner.BuildForEdge(_package.Graph, semantics, edge.Id)
                : null;
        _routeContextPlans.Add(edge.Id, plan);
        return plan;
    }

    /// <summary>Stops new reads and settles every outstanding read before teardown.</summary>
    public async Task StopPendingReadsAsync()
    {
        ProcessMode = ProcessModeEnum.Disabled;
        _loadQueue.Clear();
        _queued.Clear();
        var pending = _pending.Values.ToArray();
        _pending.Clear();
        foreach (var read in pending)
        {
            read.Cancellation.Cancel();
        }
        try
        {
            var completion = Task.WhenAll(pending.Select(read => read.Task));
            try
            {
                await completion;
            }
            catch (OperationCanceledException) when (completion.IsCanceled)
            {
                // WhenAll settles every read even if another read fails or is
                // cancelled. Only cancellation is expected during shutdown.
            }
        }
        finally
        {
            foreach (var read in pending)
            {
                read.Cancellation.Dispose();
            }
        }
    }

    // The visual kits are plain C# objects holding Godot resources, so nothing
    // frees them when the tree tears down and their wrappers survive to
    // finalisation after the engine has gone. Chunks already release their own
    // meshes this way; the kits are owned here.
    //
    // Predelete fires only on actual destruction, unlike _ExitTree which also
    // fires on reparenting, so releasing here cannot strand a live streamer.
    public override void _Notification(int what)
    {
        if (what != NotificationPredelete)
        {
            return;
        }
        _roadVisualKit?.Dispose();
        _environmentVisualKit?.Dispose();
        _backdropMaterial?.Dispose();
        _backdropMaterial = null;
        _roadVisualKit = null!;
        _environmentVisualKit = null!;
    }

    /// <summary>
    /// Float32 roundings that separate one chunk's boundary vertex from the
    /// mathematically identical vertex its neighbour computes.
    /// </summary>
    /// <remarks>
    /// Adjacent chunks derive the same boundary vertex twice, through their own
    /// anchors, and every step below rounds to the nearest representable float32:
    /// <list type="number">
    /// <item>RouteWorldPoint.RelativeTo casts the double world point into the
    /// chunk-local frame.</item>
    /// <item>RegionalTerrainRibbon.BuildRow scales the right vector by the lane
    /// offset.</item>
    /// <item>BuildRow adds that offset to the local route point.</item>
    /// <item>BuildRow adds the surface height along Up.</item>
    /// <item>GetTerrain*OuterEdge adds the chunk Position back on.</item>
    /// </list>
    /// This is counted from the code path rather than fitted to an observation:
    /// changing the construction changes the count, and the gate should be updated
    /// with it.
    /// </remarks>
    private const int TerrainSeamRoundingSteps = 5;

    /// <summary>
    /// How far a terrain seam may open before it stops being explicable as float32
    /// rounding and starts being a discontinuity someone authored.
    /// </summary>
    /// <remarks>
    /// Each of the roundings above contributes at most half a unit in the last
    /// place, and both chunks pay all of them independently, so the two vertices
    /// can differ by up to TerrainSeamRoundingSteps units per component, or
    /// sqrt(3) times that as a Euclidean distance.
    ///
    /// The ceiling is derived from the representation rather than picked, so it
    /// tightens to nanometres near the origin on its own and widens far out by
    /// exactly what float32 requires. Asserting an exact zero seam instead is
    /// unreachable in principle beyond roughly two kilometres from the origin. See
    /// docs/audits/2026-08-14-terrain-seam-gate.md.
    /// </remarks>
    private static double TerrainSeamCeilingMeters(Vector3 first, Vector3 second)
    {
        var magnitude = MathF.Max(
            MathF.Max(MathF.Abs(first.X), MathF.Abs(second.X)),
            MathF.Max(
                MathF.Max(MathF.Abs(first.Y), MathF.Abs(second.Y)),
                MathF.Max(MathF.Abs(first.Z), MathF.Abs(second.Z))));
        var spacing = MathF.BitIncrement(magnitude) - magnitude;
        return TerrainSeamRoundingSteps * Math.Sqrt(3.0) * spacing;
    }

    private (double Meters, double Ratio, double MagnitudeMeters) CalculateTerrainSeam()
    {
        var maximumMeters = 0.0;
        var maximumRatio = 0.0;
        var ratioMagnitude = 0.0;
        var loaded = _manifests
            .Where(span => _environmentChunks.ContainsKey(span.Manifest.Id))
            .OrderBy(span => span.StartMeters)
            .ToArray();
        for (var index = 0; index < loaded.Length - 1; index++)
        {
            var first = loaded[index];
            var second = loaded[index + 1];
            if (!string.Equals(
                    first.Manifest.EdgeId,
                    second.Manifest.EdgeId,
                    StringComparison.Ordinal) ||
                Math.Abs(first.EndMeters - second.StartMeters) > 0.001)
            {
                continue;
            }
            var firstEdge = _environmentChunks[first.Manifest.Id].GetTerrainEndOuterEdge();
            var secondEdge = _environmentChunks[second.Manifest.Id].GetTerrainStartOuterEdge();
            if (firstEdge.Count != secondEdge.Count)
            {
                return (double.PositiveInfinity, double.PositiveInfinity, 0.0);
            }
            for (var side = 0; side < firstEdge.Count; side++)
            {
                var seam = firstEdge[side].DistanceTo(secondEdge[side]);
                maximumMeters = Math.Max(maximumMeters, seam);
                var ceiling = TerrainSeamCeilingMeters(firstEdge[side], secondEdge[side]);
                // A zero ceiling means both vertices are exactly zero, where any
                // separation at all is a real discontinuity rather than rounding.
                var ratio = ceiling > 0.0
                    ? seam / ceiling
                    : seam > 0.0 ? double.PositiveInfinity : 0.0;
                if (ratio > maximumRatio)
                {
                    maximumRatio = ratio;
                    // The magnitude the worst ratio was measured at, so the marker
                    // shows whether a seam tracks distance from the origin, which
                    // is what separates rounding from real geometry.
                    ratioMagnitude = Math.Max(
                        firstEdge[side].Length(),
                        secondEdge[side].Length());
                }
            }
        }
        return (maximumMeters, maximumRatio, ratioMagnitude);
    }

    private static bool HasRenderableRouteContext(
        RouteEdge edge,
        RouteSemanticContent semantics) =>
        semantics.RoadsideMarkers.Any(marker =>
            string.Equals(marker.Kind, "mile", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(marker.EdgeId, edge.Id, StringComparison.Ordinal)) ||
        semantics.Exits.Any(routeExit =>
            string.Equals(routeExit.JunctionNodeId, edge.ToNodeId, StringComparison.Ordinal) &&
            edge.RouteIdentityIds.Contains(routeExit.RouteIdentityId, StringComparer.Ordinal));

    private void TryBuildJunctionSeams()
    {
        foreach (var edgeChunks in _content.Values
                     .GroupBy(content => content.EdgeId, StringComparer.Ordinal))
        {
            var edge = _package.Graph.GetEdge(edgeChunks.Key);
            var ordered = edgeChunks.OrderBy(content => content.StartMeters).ToArray();
            for (var index = 0; index < ordered.Length - 1; index++)
            {
                if (Math.Abs(ordered[index].EndMeters - ordered[index + 1].StartMeters) > 0.001)
                {
                    continue;
                }
                TryBuildJunctionSeam(ordered[index], edge, ordered[index + 1], edge);
            }
        }

        var planPairs = Enumerable.Range(0, Math.Max(0, _routePlan.Edges.Count - 1))
            .Select(index => (
                FromEdgeId: _routePlan.Edges[index].EdgeId,
                ToEdgeId: _routePlan.Edges[index + 1].EdgeId));
        var connectorPairs = _package.Semantics?.JunctionConnectors
            .Select(connector => (
                FromEdgeId: connector.FromEdgeId,
                ToEdgeId: connector.ToEdgeId)) ?? [];
        foreach (var pair in planPairs.Concat(connectorPairs).Distinct())
        {
            var fromEdge = _package.Graph.GetEdge(pair.FromEdgeId);
            var toEdge = _package.Graph.GetEdge(pair.ToEdgeId);
            var fromContent = _content.Values.SingleOrDefault(content =>
                content.EdgeId == fromEdge.Id && content.EndMeters == fromEdge.LengthMeters);
            var toContent = _content.Values.SingleOrDefault(content =>
                content.EdgeId == toEdge.Id && content.StartMeters == 0);
            if (fromContent is null || toContent is null)
            {
                continue;
            }
            TryBuildJunctionSeam(fromContent, fromEdge, toContent, toEdge);
        }
        RefreshJunctionSeamCollisions();
    }

    private void TryBuildJunctionSeam(
        RouteChunkContent fromContent,
        RouteEdge fromEdge,
        RouteChunkContent toContent,
        RouteEdge toEdge)
    {
        var key = $"{fromContent.Id}->{toContent.Id}";
        if (_junctionSeams.ContainsKey(key))
        {
            return;
        }
        var fromSpan = _manifests.SingleOrDefault(span =>
            string.Equals(span.Manifest.Id, fromContent.Id, StringComparison.Ordinal));
        var toSpan = _manifests.SingleOrDefault(span =>
            string.Equals(span.Manifest.Id, toContent.Id, StringComparison.Ordinal));
        var seam = JunctionSeam.Create(
            fromContent,
            fromEdge,
            toContent,
            toEdge,
            _frame,
            _localOriginWorld,
            _roadVisualKit,
            fromSpan?.EndMeters ?? double.NaN,
            toSpan?.StartMeters ?? double.NaN,
            fromSpan is null || toSpan is null ? double.NaN : RouteLengthMeters);
        _junctionSeams.Add(key, seam);
        _junctionSeamsBuilt.Add(key);
        if (!string.Equals(fromEdge.Id, toEdge.Id, StringComparison.Ordinal))
        {
            _junctionTransitionSeamsBuilt.Add(key);
        }
        MaximumJunctionGapMeters = Math.Max(
            MaximumJunctionGapMeters,
            seam.ConnectionGapMeters);
        AddChild(seam);
    }

    private void RemoveJunctionSeamsForChunk(string chunkId)
    {
        foreach (var (key, seam) in _junctionSeams.Where(entry =>
                     entry.Value.FromChunkId == chunkId ||
                     entry.Value.ToChunkId == chunkId).ToArray())
        {
            _junctionSeams.Remove(key);
            seam.SetCollisionActive(false);
            seam.QueueFree();
        }
    }

    private void RefreshJunctionSeamCollisions()
    {
        foreach (var seam in _junctionSeams.Values)
        {
            seam.SetCollisionActive(
                _loaded.TryGetValue(seam.FromChunkId, out var from) && from.HasCollision &&
                _loaded.TryGetValue(seam.ToChunkId, out var to) && to.HasCollision);
        }
    }

    public void ValidateCurrentStreamingWindows()
    {
        if (!IsStreamingSettled)
        {
            throw new InvalidOperationException("Streaming windows are not settled.");
        }
        var collisionIds = _loaded
            .Where(entry => entry.Value.HasCollision)
            .Select(entry => entry.Key)
            .ToHashSet(StringComparer.Ordinal);
        if (!collisionIds.SetEquals(_desiredCollision))
        {
            throw new InvalidOperationException(
                "Loaded collision chunks do not match the declared near-player window.");
        }
        var expectedAhead = Math.Min(CurrentLookAheadMeters, RouteLengthMeters - _routeDistanceMeters);
        if (LoadedVisualAheadMeters + 1e-6 < expectedAhead)
        {
            throw new InvalidOperationException(
                $"Visual lookahead is {LoadedVisualAheadMeters:F3} m; expected " +
                $"{expectedAhead:F3} m.");
        }
    }

    private bool UpdateCollisionState(RoadChunk chunk, bool active)
    {
        var hadCollision = chunk.HasCollision;
        var elapsed = chunk.SetCollisionActive(active);
        if (hadCollision == chunk.HasCollision)
        {
            return false;
        }
        if (!active)
        {
            CollisionRemovalCount++;
            return true;
        }
        CollisionBuildCount++;
        if (chunk.TransitionCount > 0)
        {
            _topologyCollisionChunks.Add(chunk.ChunkId);
        }
        MaximumCollisionBuildMilliseconds = Math.Max(
            MaximumCollisionBuildMilliseconds,
            elapsed);
        _collisionBuildSamplesMilliseconds.Add(elapsed);
        return true;
    }

    private void RecordChunkFailure(string id, Exception? exception)
    {
        _failed.Add(id);
        ChunkFailureCount++;
        GD.PushError($"Route chunk '{id}' failed verification or construction: {exception}");
    }

    private void UpdateRouteProjection()
    {
        if (_vehicle is null || _content.Count == 0)
        {
            return;
        }
        var boundedProjection = _routePlanConnectors.Count > 0;
        string? nextProjectionEdgeId = null;
        if (boundedProjection)
        {
            var currentIndex = FindRoutePlanEdgeIndex(_currentEdgeId);
            var currentPlanEdge = _routePlan.Edges[currentIndex];
            if (currentIndex + 1 < _routePlan.Edges.Count &&
                currentPlanEdge.EndMeters - _routeDistanceMeters <= 30)
            {
                nextProjectionEdgeId = _routePlan.Edges[currentIndex + 1].EdgeId;
            }
        }
        var vehicleX = _localOriginWorld.X + _vehicle.Position.X;
        var vehicleZ = _localOriginWorld.Z + _vehicle.Position.Z;
        var bestDistanceSquared = double.PositiveInfinity;
        var bestRouteDistance = _routeDistanceMeters;
        var bestLateral = _lateralOffsetMeters;
        foreach (var chunk in _content.Values)
        {
            if (boundedProjection
                    ? chunk.EdgeId != _currentEdgeId && chunk.EdgeId != nextProjectionEdgeId
                    : !_routePlanEdgeIds.Contains(chunk.EdgeId))
            {
                continue;
            }
            for (var index = 0; index < chunk.Samples.Count - 1; index++)
            {
                var first = _frame.ToWorld(chunk.Samples[index]);
                var second = _frame.ToWorld(chunk.Samples[index + 1]);
                var segmentX = second.X - first.X;
                var segmentZ = second.Z - first.Z;
                var relativeX = vehicleX - first.X;
                var relativeZ = vehicleZ - first.Z;
                var lengthSquared = segmentX * segmentX + segmentZ * segmentZ;
                if (lengthSquared <= 0.0001)
                {
                    continue;
                }
                var factor = Math.Clamp(
                    (relativeX * segmentX + relativeZ * segmentZ) / lengthSquared,
                    0,
                    1);
                var closestX = first.X + segmentX * factor;
                var closestZ = first.Z + segmentZ * factor;
                var errorX = vehicleX - closestX;
                var errorZ = vehicleZ - closestZ;
                var distanceSquared = errorX * errorX + errorZ * errorZ;
                if (distanceSquared >= bestDistanceSquared)
                {
                    continue;
                }
                bestDistanceSquared = distanceSquared;
                var edgeOffset = _routePlan.GetEdge(chunk.EdgeId).StartMeters;
                bestRouteDistance = edgeOffset + chunk.Samples[index].DistanceMeters +
                    (chunk.Samples[index + 1].DistanceMeters - chunk.Samples[index].DistanceMeters) * factor;
                var segmentLength = Math.Sqrt(lengthSquared);
                var rightX = -segmentZ / segmentLength;
                var rightZ = segmentX / segmentLength;
                bestLateral = errorX * rightX + errorZ * rightZ;
            }
        }
        if (_routePlanConnectors.Count > 0 && bestDistanceSquared > 25 * 25)
        {
            return;
        }
        _routeDistanceMeters = Math.Clamp(bestRouteDistance, 0, RouteLengthMeters);
        _lateralOffsetMeters = bestLateral;
    }

    private void UpdateCurrentLane()
    {
        var edge = _package.Graph.GetEdge(_currentEdgeId);
        var activeLanes = LaneGeometryProfile.Evaluate(edge, CurrentEdgeDistanceMeters).Lanes;
        var geometryLane = SelectActiveLane(
                activeLanes,
                _routePlanConnectors.Count > 0 ? CurrentStableLaneId : null)
            ?? throw new InvalidDataException(
                $"Route edge '{edge.Id}' has no active lane at " +
                $"{CurrentEdgeDistanceMeters:F3} meters.");
        var lanes = edge.GetLaneSection(CurrentEdgeDistanceMeters).Lanes;
        for (var index = 0; index < lanes.Count; index++)
        {
            var lane = lanes[index];
            if (lane.Id == geometryLane.Id)
            {
                CurrentLaneIndex = lane.Index;
                CurrentStableLaneId = lane.Id;
                return;
            }
        }
        throw new InvalidDataException($"Lane '{geometryLane.Id}' is absent from its active section.");
    }

    private (RouteWorldPoint Point, Vector3 Forward) GetRoadPose(double distanceMeters)
    {
        if (TryGetRoadPose(distanceMeters, out var pose))
        {
            return pose;
        }

        var fallback = _content.Values
            .Where(value => _routePlanEdgeIds.Contains(value.EdgeId))
            .OrderBy(value => Math.Abs(
                _routePlan.GetEdge(value.EdgeId).StartMeters + value.EndMeters - distanceMeters))
            .First();
        var last = fallback.Samples[^1];
        var point = _frame.ToWorld(last);
        return (point, _frame.DirectionToWorld(last.ProjectedTangentX, last.ProjectedTangentY));
    }

    private bool TryGetRoadPose(
        double distanceMeters,
        out (RouteWorldPoint Point, Vector3 Forward) pose)
    {
        // Preserve the earliest containing chunk at a seam without sorting the
        // loaded content and allocating an iterator on every road-pose query.
        var bestStartMeters = double.PositiveInfinity;
        var found = false;
        pose = default;
        foreach (var chunk in _content.Values)
        {
            if (!_routePlanEdgeIds.Contains(chunk.EdgeId))
            {
                continue;
            }
            var edgeOffset = _routePlan.GetEdge(chunk.EdgeId).StartMeters;
            var startMeters = edgeOffset + chunk.StartMeters;
            var localDistance = distanceMeters - edgeOffset;
            if (startMeters >= bestStartMeters ||
                localDistance < chunk.StartMeters || localDistance > chunk.EndMeters)
            {
                continue;
            }
            for (var index = 0; index < chunk.Samples.Count - 1; index++)
            {
                var firstSample = chunk.Samples[index];
                var secondSample = chunk.Samples[index + 1];
                if (localDistance < firstSample.DistanceMeters ||
                    localDistance > secondSample.DistanceMeters)
                {
                    continue;
                }
                var span = secondSample.DistanceMeters - firstSample.DistanceMeters;
                var factor = span <= 0 ? 0 : (localDistance - firstSample.DistanceMeters) / span;
                var first = _frame.ToWorld(firstSample);
                var second = _frame.ToWorld(secondSample);
                var tangentX = firstSample.ProjectedTangentX +
                    (secondSample.ProjectedTangentX - firstSample.ProjectedTangentX) * factor;
                var tangentY = firstSample.ProjectedTangentY +
                    (secondSample.ProjectedTangentY - firstSample.ProjectedTangentY) * factor;
                pose = (first.Lerp(second, factor), _frame.DirectionToWorld(tangentX, tangentY));
                bestStartMeters = startMeters;
                found = true;
                break;
            }
        }

        return found;
    }

    private void TryPlaceVehicleForReview()
    {
        if (_reviewTargetReady || _vehicle is null ||
            !TryGetRoadPose(_routeDistanceMeters, out var pose))
        {
            return;
        }
        var roadPoint = OffsetForActiveLane(pose.Point, pose.Forward, _routeDistanceMeters);
        var localPoint = roadPoint.RelativeTo(_localOriginWorld);
        var horizontal = new Vector3(localPoint.X, 0, localPoint.Z);
        if (horizontal.Length() >= RebaseThresholdMeters)
        {
            Rebase(horizontal);
            localPoint = roadPoint.RelativeTo(_localOriginWorld);
        }
        MaximumLocalCoordinateMeters = Math.Max(
            MaximumLocalCoordinateMeters,
            Math.Sqrt(localPoint.X * localPoint.X + localPoint.Z * localPoint.Z));
        _vehicle.PlaceForReview(localPoint, pose.Forward);
        _vehicle.RouteDistanceMeters = _routeDistanceMeters;
        _vehicle.TargetRoadPoint = localPoint;
        _vehicle.TargetRoadForward = pose.Forward;
        _reviewEdgesVisited.Add(_currentEdgeId);
        _reviewTargetReady = true;
    }

    private void Rebase(Vector3 horizontal)
    {
        _localOriginWorld = _localOriginWorld.Add(horizontal);
        LocalOriginMeters = _routeDistanceMeters;
        RebaseCount++;
        if (_vehicle is not null)
        {
            _vehicle.ShiftForOriginRebase(horizontal);
            _vehicle.TargetRoadPoint -= horizontal;
            // The chase rig is TopLevel and smooths in world space, so it has to move
            // with the rebase too. Left behind it exceeds its teleport-snap threshold
            // and snaps, which is a visible single-frame jump.
            _vehicle.ChaseCameraRig?.ShiftForOriginRebase(horizontal);
        }
        foreach (var chunk in _loaded.Values)
        {
            chunk.ShiftForOriginRebase(horizontal);
        }
        foreach (var seam in _junctionSeams.Values)
        {
            seam.ShiftForOriginRebase(horizontal);
        }
        foreach (var environmentChunk in _environmentChunks.Values)
        {
            environmentChunk.ShiftForOriginRebase(horizontal);
        }
        _roadStructures.ShiftForOriginRebase(horizontal);
    }

    private RouteWorldPoint OffsetForActiveLane(
        RouteWorldPoint point,
        Vector3 forward,
        double routeDistanceMeters)
    {
        var planEdge = _routePlan.GetEdgeAtDistance(routeDistanceMeters);
        var edge = _package.Graph.GetEdge(planEdge.EdgeId);
        var edgeDistance = Math.Clamp(
            routeDistanceMeters - planEdge.StartMeters,
            0,
            edge.LengthMeters);
        var layout = LaneGeometryProfile.Evaluate(edge, edgeDistance);
        var lane = SelectActiveLane(layout.Lanes, CurrentStableLaneId)
            ?? throw new InvalidDataException(
                $"Route edge '{edge.Id}' has no active lane at {edgeDistance:F3} meters.");
        var right = forward.Cross(Vector3.Up).Normalized();
        return point.Add(right * (float)lane.CenterMeters);
    }

    private LaneGeometryLane? SelectActiveLane(
        IReadOnlyList<LaneGeometryLane> lanes,
        string? preferredLaneId)
    {
        LaneGeometryLane? closest = null;
        var closestDistance = double.PositiveInfinity;
        for (var index = 0; index < lanes.Count; index++)
        {
            var lane = lanes[index];
            if (lane.WidthMeters <= 0.5)
            {
                continue;
            }
            if (lane.Id == preferredLaneId)
            {
                return lane;
            }
            var distance = Math.Abs(lane.CenterMeters - _lateralOffsetMeters);
            if (distance < closestDistance)
            {
                closest = lane;
                closestDistance = distance;
            }
        }
        return closest;
    }

    private void UpdateCurrentEdge()
    {
        _currentEdgeId = _routePlan.GetEdgeAtDistance(_routeDistanceMeters).EdgeId;
    }

    private IReadOnlyDictionary<(string FromEdgeId, string ToEdgeId), JunctionConnector>
        BuildRoutePlanConnectors(IReadOnlyList<string>? connectorIds)
    {
        if (connectorIds is null)
        {
            return new Dictionary<(string FromEdgeId, string ToEdgeId), JunctionConnector>();
        }
        if (connectorIds.Count != _routePlan.Edges.Count - 1)
        {
            throw new InvalidDataException(
                "Explicit route plan needs exactly one connector per edge transition.");
        }
        var semantics = _package.Semantics
            ?? throw new InvalidDataException("Explicit route plan requires route semantics.");
        var connectorsById = semantics.JunctionConnectors.ToDictionary(
            connector => connector.Id,
            StringComparer.Ordinal);
        var result = new Dictionary<(string FromEdgeId, string ToEdgeId), JunctionConnector>();
        for (var index = 0; index < connectorIds.Count; index++)
        {
            if (!connectorsById.TryGetValue(connectorIds[index], out var connector))
            {
                throw new InvalidDataException(
                    $"Explicit route plan references unknown connector '{connectorIds[index]}'.");
            }
            var fromEdgeId = _routePlan.Edges[index].EdgeId;
            var toEdgeId = _routePlan.Edges[index + 1].EdgeId;
            if (connector.FromEdgeId != fromEdgeId || connector.ToEdgeId != toEdgeId)
            {
                throw new InvalidDataException(
                    $"Connector '{connector.Id}' does not match route transition " +
                    $"'{fromEdgeId}' to '{toEdgeId}'.");
            }
            result.Add((fromEdgeId, toEdgeId), connector);
        }
        return result;
    }

    private void UpdateLaneAcrossRouteEdges(string previousEdgeId, string previousLaneId)
    {
        var previousIndex = FindRoutePlanEdgeIndex(previousEdgeId);
        var currentIndex = FindRoutePlanEdgeIndex(_currentEdgeId);
        if (currentIndex <= previousIndex)
        {
            UpdateCurrentLane();
            return;
        }
        var laneId = previousLaneId;
        for (var index = previousIndex; index < currentIndex; index++)
        {
            var fromEdgeId = _routePlan.Edges[index].EdgeId;
            var toEdgeId = _routePlan.Edges[index + 1].EdgeId;
            JunctionConnector? connector = null;
            if (_routePlanConnectors.TryGetValue((fromEdgeId, toEdgeId), out var planned))
            {
                connector = planned;
            }
            else
            {
                var candidates = _package.Semantics?.JunctionConnectors.Where(candidate =>
                    candidate.FromEdgeId == fromEdgeId &&
                    candidate.FromLaneId == laneId &&
                    candidate.ToEdgeId == toEdgeId).ToArray() ?? [];
                connector = candidates.Length == 0 ? null : candidates[0];
            }
            if (connector is null)
            {
                UpdateCurrentLane();
                return;
            }
            if (!string.Equals(connector.FromLaneId, laneId, StringComparison.Ordinal))
            {
                throw new InvalidDataException(
                    $"Route connector '{connector.Id}' expected lane '{connector.FromLaneId}' " +
                    $"but traversal reached it on '{laneId}'.");
            }
            laneId = connector.ToLaneId;
            ActiveConnectorId = connector.Id;
            _observedConnectorIds.Add(connector.Id);
            _observedConnectorMovements.Add(connector.Movement);
            GD.Print(
                $"CANNONBALL_CONNECTOR_OK movement={connector.Movement} " +
                $"from_edge={fromEdgeId} to_edge={toEdgeId} " +
                $"from_lane={connector.FromLaneId} to_lane={connector.ToLaneId}");
        }
        var edge = _package.Graph.GetEdge(_currentEdgeId);
        var lane = edge.GetLaneSection(CurrentEdgeDistanceMeters).Lanes.Single(candidate =>
            candidate.Id == laneId);
        CurrentLaneIndex = lane.Index;
        CurrentStableLaneId = lane.Id;
    }

    private int FindRoutePlanEdgeIndex(string edgeId)
    {
        for (var index = 0; index < _routePlan.Edges.Count; index++)
        {
            if (string.Equals(_routePlan.Edges[index].EdgeId, edgeId, StringComparison.Ordinal))
            {
                return index;
            }
        }
        throw new InvalidDataException($"Route plan does not contain edge '{edgeId}'.");
    }

    private sealed record RouteManifestSpan(
        ChunkManifest Manifest,
        double StartMeters,
        double EndMeters);

    private sealed record PendingRead(
        Task<RouteChunkContent> Task,
        CancellationTokenSource Cancellation);
}

public sealed record RoadVisualSnapshot(
    string ProfileId,
    int ChunkCount,
    bool AllContractsResolved,
    int ReflectorCount,
    int BarrierSegmentCount,
    int GuardrailSegmentCount,
    bool SignageContractResolved,
    int GuideSignCount,
    int RouteShieldCount,
    int StandardRouteShieldCount,
    int GeometricLaneArrowCount,
    int TypographyFallbackCount,
    int ServiceIconCount,
    int GoreChunkCount,
    int SharedMaterialCount,
    int SharedMeshCount,
    int RetroreflectiveMaterialCount,
    string SurfaceSource,
    string TerrainSource,
    int BridgeDeckCount,
    int OverpassOpeningCount,
    int StructureCount,
    int StructureSemanticNodeCount,
    bool StructureContractResolved);

public sealed record EnvironmentStreamSnapshot(
    string ProfileId,
    IReadOnlyList<EnvironmentChunkSnapshot> LoadedChunks,
    int ObservedChunkCount,
    IReadOnlyList<EnvironmentRegion> RegionsSeen,
    int NearInstanceCount,
    int MidInstanceCount,
    int DistantInstanceCount,
    int SemanticNodeCount,
    int TerrainRibbonCount,
    int TerrainVertexCount,
    int TerrainTriangleCount,
    double MaximumTerrainSeamMeters,
    double MaximumTerrainSeamFloat32Ratio,
    double MaximumTerrainSeamMagnitudeMeters,
    int SharedMaterialCount,
    int SharedMeshCount,
    string TextureSource,
    string ConiferSource,
    bool CollisionFree,
    int CollisionBudget,
    double MaximumBuildMilliseconds,
    double NearVisibilityMeters,
    double MidVisibilityMeters,
    double DistantVisibilityMeters,
    double RetainBehindMeters);

/// <summary>A road cross-section in local coordinates: centreline point,
/// forward direction and the paved edges as signed lateral offsets.</summary>
public sealed record RoadProbe(
    Vector3 Point,
    Vector3 Forward,
    double PavedLeftMeters,
    double PavedRightMeters);
