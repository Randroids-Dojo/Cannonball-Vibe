using System.Diagnostics;
using Cannonball.Core.Content;
using Cannonball.Core.Routes;
using Cannonball.Game.World.RoadVisuals;
using Godot;

namespace Cannonball.Game.World;

public sealed partial class RoadChunk : Node3D
{
    public const double RouteStartApronMeters = 20;

    private const float RouteContextLabelRangeMeters = 250;
    private StaticBody3D? _collisionBody;
    private ArrayMesh _collisionMesh = null!;
    private ArrayMesh _terrainCollisionMesh = null!;
    private double _routeStartMeters = double.NaN;
    private double _routeLengthMeters = double.NaN;
    private double _contentStartMeters;
    private List<string>? _routeContextAutomationIds;
    private List<Node3D>? _routeContextRoots;
    private List<Label3D>? _routeContextLabels;
    private MeshInstance3D? _routeStartBarrier;
    private RoadVisualKit _visualKit = null!;

    public string ChunkId { get; private set; } = string.Empty;
    public string EdgeId { get; private set; } = string.Empty;
    public double StartMeters { get; private set; }
    public double EndMeters { get; private set; }
    public double BuildMilliseconds { get; private set; }
    public double StartApronMeters { get; private set; }
    public bool HasCollision => _collisionBody is not null;
    public bool HasTerrainCollision =>
        _collisionBody?.GetNodeOrNull<CollisionShape3D>("TerrainCollision") is not null;
    public bool HasRouteStartBarrier => _routeStartBarrier is { Mesh: not null, Visible: true };
    public bool HasRouteStartBarrierCollision =>
        _collisionBody?.GetNodeOrNull<CollisionShape3D>("RouteStartBarrierCollision") is not null;
    public int MinimumLaneCount { get; private set; }
    public int MaximumLaneCount { get; private set; }
    public int TransitionCount { get; private set; }
    public double MaximumPavedWidthMeters { get; private set; }
    public bool HasGoreGeometry { get; private set; }
    public int MileMarkerCount { get; private set; }
    public int ExitSignCount { get; private set; }
    public int HighwayTransferSignCount { get; private set; }
    public int GuideSignCount { get; private set; }
    public int RouteShieldCount { get; private set; }
    public int StandardRouteShieldCount { get; private set; }
    public int GeometricLaneArrowCount { get; private set; }
    public int TypographyFallbackCount { get; private set; }
    public int ServiceIconCount { get; private set; }
    public int ReflectorCount { get; private set; }
    public int BarrierSegmentCount { get; private set; }
    public int GuardrailSegmentCount { get; private set; }
    public string RoadVisualProfileId => _visualKit.ProfileId;
    public IReadOnlyList<string> RouteContextAutomationIds =>
        _routeContextAutomationIds ?? [];

    public RoadChunkVisualSnapshot CaptureRoadVisualSnapshot()
    {
        var requiredNodes = new[]
        {
            "TerrainShoulders", "PavedShoulders", "RoadSurface", "LaneMarkings",
            "MedianEdgeMarking",
            "MedianReflectors", "LaneReflectors", "RoadBarriers", "Guardrails",
            "GuardrailPosts", "RoadsidePosts", "TerrainScenery",
        };
        var resolved = requiredNodes
            .Select(name => GetNodeOrNull<Node>(name))
            .Where(node => node is not null)
            .Cast<Node>()
            .ToArray();
        var automationIds = resolved
            .Where(node => node.HasMeta("automation_id"))
            .Select(node => node.GetMeta("automation_id").AsString())
            .ToArray();
        var expectedPrefix = $"road.visual.chunk.{ChunkId}.";
        var semanticMetadataComplete = resolved.All(node =>
            node.HasMeta("automation_id") &&
            node.HasMeta("road_visual_kit") &&
            node.GetMeta("road_visual_kit").AsString() == RoadVisualKit.Version) &&
            automationIds.Length == resolved.Length &&
            automationIds.Distinct(StringComparer.Ordinal).Count() == resolved.Length &&
            automationIds.All(id => id.StartsWith(expectedPrefix, StringComparison.Ordinal));
        var whiteMarkings = GetNodeOrNull<MeshInstance3D>("LaneMarkings");
        var medianMarking = GetNodeOrNull<MeshInstance3D>("MedianEdgeMarking");
        var markingSemanticsResolved =
            ReferenceEquals(whiteMarkings?.MaterialOverride, _visualKit.MarkingWhite) &&
            ReferenceEquals(medianMarking?.MaterialOverride, _visualKit.MarkingYellow) &&
            _visualKit.Gore.AlbedoColor == _visualKit.MarkingWhite.AlbedoColor &&
            _visualKit.MarkingYellow.AlbedoColor != _visualKit.MarkingWhite.AlbedoColor;
        var guideRoots = (_routeContextRoots ?? [])
            .Where(root =>
            {
                var id = root.GetMeta("automation_id").AsString();
                return id.StartsWith("route-context.exit.", StringComparison.Ordinal) ||
                    id.StartsWith("route-context.transfer.", StringComparison.Ordinal);
            })
            .ToArray();
        var shieldNodes = guideRoots
            .SelectMany(root => root.GetChildren()
                .OfType<Node3D>()
                .Where(child => child.Name.ToString().StartsWith(
                    "RouteShield",
                    StringComparison.Ordinal)))
            .ToArray();
        var arrowNodes = guideRoots
            .Select(root => root.GetNodeOrNull<MeshInstance3D>("LaneArrow"))
            .Where(node => node is not null)
            .Cast<MeshInstance3D>()
            .ToArray();
        var signageMetadataComplete = guideRoots.All(root =>
                root.HasMeta("sign_standard_reference") &&
                root.GetMeta("sign_standard_reference").AsString() ==
                    HighwaySignGeometry.StandardReference &&
                root.HasMeta("sign_standard_source") &&
                root.GetMeta("sign_standard_source").AsString() ==
                    HighwaySignGeometry.StandardSource &&
                root.HasMeta("sign_typography_status") &&
                root.GetMeta("sign_typography_status").AsString() ==
                    HighwaySignGeometry.TypographyStatus) &&
            shieldNodes.All(shield =>
                shield.HasMeta("shield_design") &&
                shield.GetMeta("shield_design").AsString() is "M1-1" or "M1-4" &&
                shield.HasMeta("shape_source") &&
                shield.GetMeta("shape_source").AsString() ==
                    "procedural-standard-proportions") &&
            arrowNodes.All(arrow =>
                arrow.HasMeta("arrow_direction") &&
                arrow.HasMeta("sign_standard_reference"));
        var signageContractResolved =
            GuideSignCount == GeometricLaneArrowCount &&
            GuideSignCount == TypographyFallbackCount &&
            RouteShieldCount == StandardRouteShieldCount &&
            guideRoots.Length == GuideSignCount &&
            shieldNodes.Length == StandardRouteShieldCount &&
            arrowNodes.Length == GeometricLaneArrowCount &&
            signageMetadataComplete;
        return new RoadChunkVisualSnapshot(
            ChunkId,
            _visualKit.ProfileId,
            resolved.Length == requiredNodes.Length && semanticMetadataComplete &&
                markingSemanticsResolved && signageContractResolved,
            markingSemanticsResolved,
            signageContractResolved,
            resolved.Length,
            _visualKit.SharedMaterialCount,
            _visualKit.SharedMeshCount,
            _visualKit.RetroreflectiveMaterialCount,
            ReflectorCount,
            BarrierSegmentCount,
            GuardrailSegmentCount,
            GuideSignCount,
            RouteShieldCount,
            StandardRouteShieldCount,
            GeometricLaneArrowCount,
            TypographyFallbackCount,
            ServiceIconCount,
            HasGoreGeometry);
    }

    public bool HasReviewGeometry()
    {
        var road = GetNodeOrNull<MeshInstance3D>("RoadSurface");
        var terrain = GetNodeOrNull<MeshInstance3D>("TerrainShoulders");
        var scenery = GetNodeOrNull<MultiMeshInstance3D>("TerrainScenery");
        var barriers = GetNodeOrNull<MultiMeshInstance3D>("RoadBarriers");
        return road is { Visible: true, Mesh: not null } &&
            road.Mesh.GetAabb().Size.LengthSquared() > 0 &&
            terrain is { Visible: true, Mesh: not null } &&
            terrain.Mesh.GetAabb().Size.LengthSquared() > 0 &&
            scenery is { Visible: true, Multimesh: not null } &&
            scenery.Multimesh.InstanceCount > 0 &&
            scenery.CastShadow == GeometryInstance3D.ShadowCastingSetting.Off &&
            barriers is { Visible: true, Multimesh: not null } &&
            barriers.Multimesh.InstanceCount > 0;
    }

    public static RoadChunk Create(
        RouteChunkContent content,
        RouteEdge edge,
        RouteContextPlan? routeContextPlan,
        RouteFrame frame,
        RouteWorldPoint localOriginWorld,
        RoadVisualKit visualKit,
        bool extendBehindRouteStart,
        double routeStartMeters = double.NaN,
        double routeLengthMeters = double.NaN)
    {
        ArgumentNullException.ThrowIfNull(visualKit);
        var chunk = new RoadChunk();
        chunk._visualKit = visualKit;
        chunk._routeStartMeters = routeStartMeters;
        chunk._routeLengthMeters = routeLengthMeters;
        chunk._contentStartMeters = content.StartMeters;
        var started = Stopwatch.GetTimestamp();
        var anchor = frame.ToWorld(content.Samples[0]);
        var renderSamples = AddLaneTransitionSamples(content.Samples, edge);
        if (extendBehindRouteStart)
        {
            renderSamples = AddRouteStartApron(renderSamples);
            chunk.StartApronMeters = RouteStartApronMeters;
        }
        var points = renderSamples
            .Select(sample => frame.ToWorld(sample).RelativeTo(anchor))
            .ToArray();
        var tangents = renderSamples
            .Select(sample => frame.DirectionToWorld(
                sample.ProjectedTangentX,
                sample.ProjectedTangentY))
            .ToArray();
        var layouts = renderSamples
            .Select(sample => LaneGeometryProfile.Evaluate(
                edge,
                Math.Clamp(sample.DistanceMeters, 0, edge.LengthMeters)))
            .ToArray();
        chunk.Name = $"RoadChunk-{content.Id}";
        RoadVisualKit.MarkSemantic(chunk, $"road.visual.chunk.{content.Id}");
        chunk.SetMeta("road_visual_profile", visualKit.ProfileId);
        chunk.ChunkId = content.Id;
        chunk.EdgeId = content.EdgeId;
        chunk.StartMeters = content.StartMeters;
        chunk.EndMeters = content.EndMeters;
        chunk.Position = anchor.RelativeTo(localOriginWorld);
        chunk.MinimumLaneCount = layouts.Min(layout =>
            layout.Lanes.Count(lane => lane.WidthMeters > 0.05));
        chunk.MaximumLaneCount = layouts.Max(layout =>
            layout.Lanes.Count(lane => lane.WidthMeters > 0.05));
        chunk.TransitionCount = edge.GetEffectiveLaneSections().Count(section =>
            section.StartMeters > content.StartMeters &&
            section.StartMeters <= content.EndMeters);
        chunk.MaximumPavedWidthMeters = layouts.Max(layout => layout.PavedWidthMeters);
        chunk.BuildTerrain(points, tangents, renderSamples, layouts);
        chunk.BuildRoad(points, tangents, renderSamples, layouts);
        chunk.BuildLaneMarkings(points, tangents, renderSamples, layouts);
        chunk.BuildReflectors(points, tangents, layouts);
        chunk.BuildGoreAreas(points, tangents, layouts);
        chunk.BuildBarriers(points, tangents, renderSamples, layouts);
        if (extendBehindRouteStart)
        {
            chunk.BuildRouteStartBarrier(points[0], tangents[0], layouts[0]);
        }
        chunk.BuildScenery(points, tangents, layouts);
        if (routeContextPlan is { Placements.Count: > 0 })
        {
            chunk.BuildRouteContext(
                content,
                edge,
                routeContextPlan,
                renderSamples,
                points,
                tangents,
                layouts);
        }
        chunk.BuildMilliseconds = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
        return chunk;
    }

    private static IReadOnlyList<RouteChunkSample> AddRouteStartApron(
        IReadOnlyList<RouteChunkSample> samples)
    {
        var first = samples[0];
        var apron = new RouteChunkSample(
            first.DistanceMeters - RouteStartApronMeters,
            first.LateralMeters,
            first.ElevationMeters - first.Grade * (float)RouteStartApronMeters,
            first.Curvature,
            first.Grade,
            first.ProjectedXMeters - first.ProjectedTangentX * RouteStartApronMeters,
            first.ProjectedYMeters - first.ProjectedTangentY * RouteStartApronMeters,
            first.ProjectedTangentX,
            first.ProjectedTangentY);
        return [apron, .. samples];
    }

    private static IReadOnlyList<RouteChunkSample> AddLaneTransitionSamples(
        IReadOnlyList<RouteChunkSample> samples,
        RouteEdge edge)
    {
        var result = samples.ToList();
        var minimum = samples[0].DistanceMeters;
        var maximum = samples[^1].DistanceMeters;
        var criticalDistances = LaneGeometryProfile.GetTransitions(edge)
            .SelectMany(transition => new[]
            {
                transition.StartMeters,
                transition.BoundaryMeters,
                transition.EndMeters,
            })
            .Where(distance => distance > minimum + 1e-9 && distance < maximum - 1e-9)
            .Where(distance => result.All(sample =>
                Math.Abs(sample.DistanceMeters - distance) > 1e-9))
            .Distinct()
            .OrderBy(distance => distance)
            .ToArray();
        foreach (var distance in criticalDistances)
        {
            var afterIndex = result.FindIndex(sample => sample.DistanceMeters > distance);
            var before = result[afterIndex - 1];
            var after = result[afterIndex];
            var factor = (distance - before.DistanceMeters) /
                (after.DistanceMeters - before.DistanceMeters);
            var tangentX = Lerp(before.ProjectedTangentX, after.ProjectedTangentX, factor);
            var tangentY = Lerp(before.ProjectedTangentY, after.ProjectedTangentY, factor);
            var tangentLength = Math.Sqrt(tangentX * tangentX + tangentY * tangentY);
            result.Insert(afterIndex, new RouteChunkSample(
                distance,
                (float)Lerp(before.LateralMeters, after.LateralMeters, factor),
                (float)Lerp(before.ElevationMeters, after.ElevationMeters, factor),
                (float)Lerp(before.Curvature, after.Curvature, factor),
                (float)Lerp(before.Grade, after.Grade, factor),
                Lerp(before.ProjectedXMeters, after.ProjectedXMeters, factor),
                Lerp(before.ProjectedYMeters, after.ProjectedYMeters, factor),
                tangentX / tangentLength,
                tangentY / tangentLength));
        }
        return result;
    }

    private static double Lerp(double from, double to, double factor) =>
        from + (to - from) * factor;

    public IReadOnlyList<RouteContextLabelDiagnostic> GetRouteContextLabelDiagnostics(
        Camera3D camera)
    {
        ArgumentNullException.ThrowIfNull(camera);
        if (_routeContextLabels is null)
        {
            return [];
        }
        var cameraForward = -camera.GlobalBasis.Z;
        return _routeContextLabels.Select(label =>
        {
            var cameraToLabel = label.GlobalPosition - camera.GlobalPosition;
            var cameraDistance = cameraToLabel.Length();
            return new RouteContextLabelDiagnostic(
                label.GetParent().GetMeta("automation_id").AsString(),
                label.Visible && label.IsVisibleInTree(),
                camera.IsPositionInFrustum(label.GlobalPosition),
                cameraDistance,
                cameraToLabel.Dot(cameraForward),
                cameraDistance <= label.VisibilityRangeEnd + 1e-3f);
        }).ToArray();
    }

    private void BuildRouteContext(
        RouteChunkContent content,
        RouteEdge edge,
        RouteContextPlan plan,
        IReadOnlyList<RouteChunkSample> renderSamples,
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        var placements = plan.ForChunk(
            content.StartMeters,
            content.EndMeters,
            includeEnd: Math.Abs(content.EndMeters - edge.LengthMeters) <= 1e-6);
        foreach (var placement in placements)
        {
            var (point, tangent, layout) = SamplePlacement(
                content.Id,
                placement.DistanceMeters,
                renderSamples,
                points,
                tangents,
                layouts);
            var right = tangent.Cross(Vector3.Up).Normalized();
            var lateral = placement.Mount switch
            {
                RouteContextMount.LeftRoadside => (float)layout.PavedLeftMeters - 2.2f,
                RouteContextMount.RightRoadside => (float)layout.PavedRightMeters + 2.2f,
                RouteContextMount.Overhead => 0,
                _ => throw new ArgumentOutOfRangeException(nameof(placement.Mount)),
            };
            var root = new Node3D
            {
                Name = $"RouteContext-{placement.Id}",
                Position = point + right * lateral,
                Basis = Basis.LookingAt(-tangent, Vector3.Up),
            };
            var automationId = placement.Kind switch
            {
                RouteContextPlacementKind.MileMarker => $"route-context.marker.{placement.Id}",
                RouteContextPlacementKind.ExitSign => $"route-context.exit.{placement.Id}",
                RouteContextPlacementKind.HighwayTransferSign =>
                    $"route-context.transfer.{placement.Id}",
                _ => throw new ArgumentOutOfRangeException(nameof(placement.Kind)),
            };
            RoadVisualKit.MarkSemantic(root, automationId);
            root.SetMeta("edge_id", placement.EdgeId);
            root.SetMeta("edge_distance_meters", placement.DistanceMeters);
            root.SetMeta("route_identity_id", placement.RouteIdentityId);
            root.SetMeta("signed_direction", placement.SignedDirection);
            root.SetMeta("jurisdiction", placement.Jurisdiction);
            root.SetMeta("exact_route_reference", placement.ExactRouteReference);
            root.SetMeta("route_shields", string.Join(',', placement.RouteShields));
            root.SetMeta("lane_guidance", placement.LaneGuidance);
            root.SetMeta("lane_ids", string.Join(',', placement.LaneIds));
            root.SetMeta("services", string.Join(',', placement.Services));
            root.SetMeta("provenance_kind", placement.Provenance.Kind.ToString());
            root.SetMeta("provenance_source_id", placement.Provenance.SourceId);
            (_routeContextAutomationIds ??= []).Add(automationId);
            AddChild(root);
            (_routeContextRoots ??= []).Add(root);

            if (placement.Kind == RouteContextPlacementKind.MileMarker)
            {
                BuildMileMarker(root, placement);
                MileMarkerCount++;
            }
            else
            {
                BuildGuideSign(root, placement, layout);
                if (placement.Kind == RouteContextPlacementKind.HighwayTransferSign)
                {
                    HighwayTransferSignCount++;
                }
                else
                {
                    ExitSignCount++;
                }
            }
        }
    }

    private void BuildMileMarker(Node3D root, RouteContextPlacement placement)
    {
        var board = new MeshInstance3D
        {
            Name = "MarkerBoard",
            Position = new Vector3(0, 1.65f, 0),
            Mesh = Owned(new BoxMesh { Size = new Vector3(1.05f, 1.65f, 0.1f) }),
            MaterialOverride = _visualKit.SignWhite,
        };
        RoadVisualKit.MarkSemantic(
            board,
            $"{root.GetMeta("automation_id")}.board");
        root.AddChild(board);
        var post = new MeshInstance3D
        {
            Name = "MarkerPost",
            Position = new Vector3(0, 0.72f, 0),
            Mesh = Owned(new CylinderMesh
            {
                TopRadius = 0.045f,
                BottomRadius = 0.045f,
                Height = 1.44f,
            }),
            MaterialOverride = _visualKit.GalvanizedSteel,
        };
        RoadVisualKit.MarkSemantic(
            post,
            $"{root.GetMeta("automation_id")}.post");
        root.AddChild(post);
        var direction = placement.SignedDirection.ToUpperInvariant();
        var routeText = placement.PrimaryText.EndsWith(
                $" {direction}",
                StringComparison.Ordinal)
            ? placement.PrimaryText[..^(direction.Length + 1)]
            : placement.PrimaryText;
        AddRouteContextLabel(
            root,
            "MarkerText",
            $"{routeText}\n{direction}\n{placement.SecondaryText}",
            new Vector3(0, 1.65f, -0.07f),
            40,
            0.0055f,
            new Color("101820"));
    }

    private void BuildGuideSign(
        Node3D root,
        RouteContextPlacement placement,
        LaneGeometrySample layout)
    {
        var boardWidth = Math.Clamp((float)layout.PavedWidthMeters + 8, 18, 24);
        const float boardHeight = 9.2f;
        const float boardY = 10.8f;
        var rootId = root.GetMeta("automation_id").AsString();
        root.SetMeta("sign_standard_reference", HighwaySignGeometry.StandardReference);
        root.SetMeta("sign_standard_source", HighwaySignGeometry.StandardSource);
        root.SetMeta("sign_layout_profile", "colorado-freeway-guide-v1");
        root.SetMeta("sign_typography_status", HighwaySignGeometry.TypographyStatus);
        var border = new MeshInstance3D
        {
            Name = "GuideBorder",
            Position = new Vector3(0, boardY, 0),
            Mesh = Owned(BuildPlanarFaceMesh(HighwaySignGeometry.RoundedRectangle(
                boardWidth,
                boardHeight,
                Math.Min(boardWidth, boardHeight) / 16))),
            MaterialOverride = _visualKit.SignWhite,
        };
        RoadVisualKit.MarkSemantic(border, $"{rootId}.border");
        root.AddChild(border);
        var board = new MeshInstance3D
        {
            Name = "GuideBoard",
            Position = new Vector3(0, boardY, -0.03f),
            Mesh = Owned(BuildPlanarFaceMesh(HighwaySignGeometry.RoundedRectangle(
                boardWidth - 0.3f,
                boardHeight - 0.3f,
                Math.Min(boardWidth, boardHeight) / 16 - 0.15f))),
            MaterialOverride = _visualKit.GuideGreen,
        };
        RoadVisualKit.MarkSemantic(board, $"{rootId}.board");
        root.AddChild(board);
        var postIndex = 0;
        foreach (var x in new[] { -boardWidth / 2 + 0.7f, boardWidth / 2 - 0.7f })
        {
            var post = new MeshInstance3D
            {
                Name = postIndex == 0 ? "GuidePostLeft" : "GuidePostRight",
                Position = new Vector3(x, boardY / 2, 0),
                Mesh = Owned(new CylinderMesh
                {
                    TopRadius = 0.12f,
                    BottomRadius = 0.16f,
                    Height = boardY,
                }),
                MaterialOverride = _visualKit.GalvanizedSteel,
            };
            RoadVisualKit.MarkSemantic(post, $"{rootId}.post.{postIndex}");
            root.AddChild(post);
            postIndex++;
        }

        AddSemanticLabel(
            root,
            "ExitNumber",
            placement.PrimaryText.Replace(" // ", "   ", StringComparison.Ordinal),
            new Vector3(0, boardY + 3.45f, -0.13f),
            52,
            0.014f,
            Colors.White,
            "exit-number",
            trackDiagnostic: false);
        var shieldSpacing = 4.4f;
        var shieldStart = -(placement.RouteShields.Count - 1) * shieldSpacing / 2;
        for (var index = 0; index < placement.RouteShields.Count; index++)
        {
            BuildRouteShield(
                root,
                placement.RouteShields[index],
                index,
                shieldStart + index * shieldSpacing,
                boardY + 1.55f);
        }

        var destinationLines = placement.SecondaryText
            .Split(" / ", StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(line => !IsRouteIdentityLine(line))
            .ToArray();
        var destinationText = string.Join(
            '\n',
            destinationLines.Length > 0
                ? destinationLines
                : [placement.SecondaryText]);
        AddRouteContextLabel(
            root,
            "GuideText",
            destinationText,
            new Vector3(0, boardY - 0.45f, -0.13f),
            64,
            0.016f,
            Colors.White);

        var exitOnly = layout.Lanes.Any(lane =>
            placement.LaneIds.Contains(lane.Id, StringComparer.Ordinal) &&
            lane.Role == LaneRole.ExitOnly);
        var arrowDirection = placement.LaneGuidance.StartsWith(
                "RIGHT",
                StringComparison.Ordinal)
            ? GuideArrowDirection.UpRight
            : placement.LaneGuidance.StartsWith("LEFT", StringComparison.Ordinal)
                ? GuideArrowDirection.UpLeft
                : GuideArrowDirection.Down;
        var laneY = exitOnly ? boardY - 3.45f : boardY - 2.75f;
        var laneColor = exitOnly ? new Color("111418") : Colors.White;
        if (exitOnly)
        {
            var panel = new MeshInstance3D
            {
                Name = "ExitOnlyPanel",
                Position = new Vector3(0, boardY - 3.45f, -0.13f),
                Mesh = Owned(new BoxMesh
                {
                    Size = new Vector3(Math.Min(boardWidth - 0.8f, 10), 1.45f, 0.08f),
                }),
                MaterialOverride = _visualKit.ExitOnlyYellow,
            };
            RoadVisualKit.MarkSemantic(panel, $"{rootId}.exit-only-panel");
            root.AddChild(panel);
            AddSemanticLabel(
                root,
                "LaneGuidance",
                $"EXIT ONLY   {placement.LaneGuidance}",
                new Vector3(0.10f, laneY, -0.19f),
                48,
                0.012f,
                laneColor,
                "lane-guidance",
                trackDiagnostic: false);
        }
        else
        {
            AddSemanticLabel(
                root,
                "LaneGuidance",
                placement.LaneGuidance,
                new Vector3(0.10f, laneY, -0.13f),
                48,
                0.012f,
                laneColor,
                "lane-guidance",
                trackDiagnostic: false);
        }
        var arrow = new MeshInstance3D
        {
            Name = "LaneArrow",
            Position = new Vector3(
                (arrowDirection == GuideArrowDirection.UpLeft ? 1 : -1) *
                    Math.Min(boardWidth / 2 - 0.65f, 4.35f),
                laneY,
                exitOnly ? -0.20f : -0.14f),
            RotationDegrees = new Vector3(0, 180, 0),
            Scale = new Vector3(0.72f, 0.72f, 1),
            Mesh = Owned(BuildPlanarFaceMesh(HighwaySignGeometry.LaneArrow(arrowDirection))),
            MaterialOverride = exitOnly ? _visualKit.SignBlack : _visualKit.SignWhite,
        };
        RoadVisualKit.MarkSemantic(arrow, $"{rootId}.lane-arrow");
        arrow.SetMeta("arrow_direction", arrowDirection.ToString());
        arrow.SetMeta("sign_standard_reference", HighwaySignGeometry.StandardReference);
        root.AddChild(arrow);
        GeometricLaneArrowCount++;
        GuideSignCount++;
        TypographyFallbackCount++;
        BuildServiceIcons(root, placement.Services, boardWidth, boardY);
    }

    private static bool IsRouteIdentityLine(string value)
    {
        var normalized = value.Trim().ToUpperInvariant();
        return normalized.StartsWith("INTERSTATE ", StringComparison.Ordinal) ||
            normalized.StartsWith("US ", StringComparison.Ordinal) ||
            normalized.StartsWith("U.S. ", StringComparison.Ordinal) ||
            normalized.StartsWith("I-", StringComparison.Ordinal) ||
            normalized.StartsWith("STATE HIGHWAY ", StringComparison.Ordinal);
    }

    private void BuildRouteShield(
        Node3D guideRoot,
        string shieldText,
        int index,
        float x,
        float y)
    {
        var normalized = shieldText.StartsWith("TO ", StringComparison.Ordinal)
            ? shieldText[3..]
            : shieldText;
        var parts = normalized.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var interstate = parts.Length > 0 &&
            (string.Equals(parts[0], "I", StringComparison.Ordinal) ||
                parts[0].StartsWith("I-", StringComparison.Ordinal));
        var number = parts.Length == 0
            ? normalized
            : parts[0].StartsWith("I-", StringComparison.Ordinal)
                ? parts[0][2..]
                : parts.Length > 1
                    ? parts[1]
                    : parts[0];
        var direction = parts.LastOrDefault(value => value is
            "NORTH" or "SOUTH" or "EAST" or "WEST") ?? string.Empty;
        var guideId = guideRoot.GetMeta("automation_id").AsString();
        var shield = new Node3D
        {
            Name = $"RouteShield{index}",
            Position = new Vector3(x, y, -0.14f),
            Scale = new Vector3(number.Length >= 3 ? 1.15f : 1, 1, 1),
        };
        RoadVisualKit.MarkSemantic(shield, $"{guideId}.shield.{index}");
        shield.SetMeta("shield_design", interstate ? "M1-1" : "M1-4");
        shield.SetMeta("sign_standard_reference", HighwaySignGeometry.StandardReference);
        shield.SetMeta("sign_standard_source", HighwaySignGeometry.StandardSource);
        shield.SetMeta("shape_source", "procedural-standard-proportions");
        shield.SetMeta("sign_typography_status", HighwaySignGeometry.TypographyStatus);
        guideRoot.AddChild(shield);
        var backing = new MeshInstance3D
        {
            Name = "ShieldSilhouette",
            Mesh = Owned(BuildPlanarFaceMesh(interstate
                ? HighwaySignGeometry.InterstateShield()
                : HighwaySignGeometry.UnitedStatesRouteShield())),
            MaterialOverride = _visualKit.SignWhite,
        };
        RoadVisualKit.MarkSemantic(backing, $"{guideId}.shield.{index}.silhouette");
        shield.AddChild(backing);
        if (interstate)
        {
            var face = new MeshInstance3D
            {
                Name = "InterstateFace",
                Position = new Vector3(0, 0, -0.025f),
                Scale = new Vector3(0.91f, 0.91f, 1),
                Mesh = Owned(BuildPlanarFaceMesh(HighwaySignGeometry.InterstateShield())),
                MaterialOverride = _visualKit.InterstateBlue,
            };
            RoadVisualKit.MarkSemantic(face, $"{guideId}.shield.{index}.face");
            shield.AddChild(face);
            var header = new MeshInstance3D
            {
                Name = "InterstateHeader",
                Position = new Vector3(0, 0, -0.04f),
                Scale = new Vector3(0.91f, 0.91f, 1),
                Mesh = Owned(BuildPlanarFaceMesh(HighwaySignGeometry.InterstateHeader())),
                MaterialOverride = _visualKit.InterstateRed,
            };
            RoadVisualKit.MarkSemantic(header, $"{guideId}.shield.{index}.header");
            shield.AddChild(header);
            var divider = new MeshInstance3D
            {
                Name = "InterstateDivider",
                Position = new Vector3(0, 0.40f, -0.05f),
                Mesh = Owned(BuildPlanarFaceMesh(HighwaySignGeometry.RoundedRectangle(
                    2.30f,
                    0.10f,
                    0.03f,
                    2))),
                MaterialOverride = _visualKit.SignWhite,
            };
            RoadVisualKit.MarkSemantic(divider, $"{guideId}.shield.{index}.divider");
            shield.AddChild(divider);
            AddSemanticLabel(
                shield,
                "ShieldSystem",
                "INTERSTATE",
                new Vector3(0, 0.86f, -0.06f),
                24,
                0.007f,
                Colors.White,
                "system",
                trackDiagnostic: false);
        }
        AddSemanticLabel(
            shield,
            "ShieldNumber",
            number,
            new Vector3(0, -0.02f, -0.045f),
            64,
            0.013f,
            interstate ? Colors.White : new Color("111418"),
            "number",
            trackDiagnostic: false);
        if (!string.IsNullOrEmpty(direction))
        {
            AddSemanticLabel(
                shield,
                "ShieldDirection",
                direction,
                new Vector3(0, 1.72f, -0.045f),
                34,
                0.009f,
                Colors.White,
                "direction",
                trackDiagnostic: false);
        }
        RouteShieldCount++;
        StandardRouteShieldCount++;
    }

    private static ArrayMesh BuildPlanarFaceMesh(IReadOnlyList<Vector2> points)
    {
        if (points.Count < 3)
        {
            throw new ArgumentException(
                "A planar sign face requires at least three points.",
                nameof(points));
        }
        using var surface = new SurfaceTool();
        surface.Begin(Mesh.PrimitiveType.Triangles);
        for (var index = 1; index < points.Count - 1; index++)
        {
            AddTriangle(
                surface,
                new Vector3(points[0].X, points[0].Y, 0),
                new Vector3(points[index].X, points[index].Y, 0),
                new Vector3(points[index + 1].X, points[index + 1].Y, 0),
                Vector2.Zero,
                Vector2.Right,
                Vector2.One);
        }
        surface.GenerateNormals();
        return surface.Commit();
    }

    private void BuildServiceIcons(
        Node3D root,
        IReadOnlyList<string> services,
        float boardWidth,
        float boardY)
    {
        var shown = services.Take(4).ToArray();
        var spacing = Math.Min(2.8f, (boardWidth - 1) / Math.Max(shown.Length, 1));
        var start = -(shown.Length - 1) * spacing / 2;
        var rootId = root.GetMeta("automation_id").AsString();
        for (var index = 0; index < shown.Length; index++)
        {
            var panel = new MeshInstance3D
            {
                Name = $"ServicePanel{index}",
                Position = new Vector3(start + index * spacing, boardY - 5.35f, -0.06f),
                Mesh = Owned(new BoxMesh { Size = new Vector3(2.45f, 1.25f, 0.12f) }),
                MaterialOverride = _visualKit.ServiceBlue,
            };
            RoadVisualKit.MarkSemantic(panel, $"{rootId}.service.{index}.panel");
            root.AddChild(panel);
            AddSemanticLabel(
                root,
                $"ServiceIcon{index}",
                shown[index].ToUpperInvariant(),
                new Vector3(start + index * spacing, boardY - 5.35f, -0.14f),
                32,
                0.009f,
                Colors.White,
                $"service.{index}.text",
                trackDiagnostic: false);
            ServiceIconCount++;
        }
    }

    private void AddRouteContextLabel(
        Node3D root,
        string name,
        string text,
        Vector3 position,
        int fontSize,
        float pixelSize,
        Color color)
    {
        AddSemanticLabel(
            root,
            name,
            text,
            position,
            fontSize,
            pixelSize,
            color,
            "text",
            trackDiagnostic: true);
    }

    private void AddSemanticLabel(
        Node3D root,
        string name,
        string text,
        Vector3 position,
        int fontSize,
        float pixelSize,
        Color color,
        string automationSuffix,
        bool trackDiagnostic)
    {
        var label = new Label3D
        {
            Name = name,
            Text = text,
            Position = position,
            FontSize = fontSize,
            PixelSize = pixelSize,
            Modulate = color,
            OutlineSize = 4,
            NoDepthTest = false,
            DoubleSided = false,
            CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
            RotationDegrees = new Vector3(0, 180, 0),
            VisibilityRangeEnd = RouteContextLabelRangeMeters,
            VisibilityRangeEndMargin = 35,
            VisibilityRangeFadeMode = GeometryInstance3D.VisibilityRangeFadeModeEnum.Self,
        };
        RoadVisualKit.MarkSemantic(
            label,
            $"{root.GetMeta("automation_id")}.{automationSuffix}");
        if (trackDiagnostic)
        {
            (_routeContextLabels ??= []).Add(label);
        }
        root.AddChild(label);
    }

    private static (
        Vector3 Point,
        Vector3 Tangent,
        LaneGeometrySample Layout) SamplePlacement(
        string chunkId,
        double distanceMeters,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        for (var index = 0; index < samples.Count - 1; index++)
        {
            var first = samples[index].DistanceMeters;
            var second = samples[index + 1].DistanceMeters;
            if (distanceMeters < first || distanceMeters > second)
            {
                continue;
            }
            var factor = second <= first ? 0 : (distanceMeters - first) / (second - first);
            return (
                points[index].Lerp(points[index + 1], (float)factor),
                tangents[index].Lerp(tangents[index + 1], (float)factor).Normalized(),
                factor < 0.5 ? layouts[index] : layouts[index + 1]);
        }

        throw new InvalidDataException(
            $"Route-context placement at {distanceMeters:F3} meters is outside chunk " +
            $"'{chunkId}'.");
    }

    public double SetCollisionActive(bool active)
    {
        if (active == HasCollision)
        {
            return 0;
        }
        if (!active)
        {
            var body = _collisionBody!;
            body.CollisionLayer = 0;
            body.ProcessMode = ProcessModeEnum.Disabled;
            RemoveChild(body);
            body.Free();
            _collisionBody = null;
            return 0;
        }

        var started = Stopwatch.GetTimestamp();
        _collisionBody = new StaticBody3D
        {
            Name = "RoadCollision",
            CollisionLayer = 1,
            CollisionMask = 2,
        };
        // The shape is owned by the CollisionShape3D once assigned; releasing the
        // local wrapper keeps no stray reference alive past engine shutdown.
        using (var trimesh = _collisionMesh.CreateTrimeshShape())
        {
            _collisionBody.AddChild(new CollisionShape3D { Shape = trimesh });
        }
        // The ground either side of the road is the collider a car that
        // leaves the paved edge lands on: from the paved edge to the
        // ribbon's 460 m outer band on the surface the ribbon draws. Without
        // it the only collider in the world was the paved ribbon and a wheel
        // past the shoulder found nothing until the vehicle reached the
        // recovery depth; a 120 m margin alone was crossed in two seconds at
        // highway speed. Twelve triangles per segment, a fraction of the
        // paved trimesh.
        using (var terrain = _terrainCollisionMesh.CreateTrimeshShape())
        {
            // Back faces collide too: a margin folded on the inside of a tight
            // curve must still hold the car from either winding.
            terrain.BackfaceCollision = true;
            _collisionBody.AddChild(new CollisionShape3D
            {
                Name = "TerrainCollision",
                Shape = terrain,
            });
        }
        if (_routeStartBarrier?.Mesh is BoxMesh barrierMesh)
        {
            _collisionBody.AddChild(new CollisionShape3D
            {
                Name = "RouteStartBarrierCollision",
                Shape = Owned(new BoxShape3D { Size = barrierMesh.Size }),
                Transform = _routeStartBarrier.Transform,
            });
        }
        AddChild(_collisionBody);
        return Stopwatch.GetElapsedTime(started).TotalMilliseconds;
    }

    private void BuildRoad(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        _collisionMesh = BuildRibbonMesh(
            points,
            tangents,
            samples,
            layouts,
            layout => layout.PavedLeftMeters,
            layout => layout.PavedRightMeters,
            -0.035f,
            RouteDistance);
        var shoulders = new MeshInstance3D
        {
            Name = "PavedShoulders",
            Mesh = _collisionMesh,
            MaterialOverride = _visualKit.Shoulder,
        };
        MarkRoadSemantic(shoulders, "paved-shoulders");
        AddChild(shoulders);
        using var laneMesh = BuildRibbonMesh(
            points,
            tangents,
            samples,
            layouts,
            layout => layout.LaneLeftMeters,
            layout => layout.LaneRightMeters,
            0,
            RouteDistance);
        var surface = new MeshInstance3D
        {
            Name = "RoadSurface",
            Mesh = laneMesh,
            MaterialOverride = _visualKit.Pavement,
        };
        MarkRoadSemantic(surface, "pavement");
        AddChild(surface);
    }

    private static ArrayMesh BuildRibbonMesh(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<LaneGeometrySample> layouts,
        Func<LaneGeometrySample, double> leftOffset,
        Func<LaneGeometrySample, double> rightOffset,
        float verticalOffset,
        Func<RouteChunkSample, double> routeDistance)
    {
        using var surface = new SurfaceTool();
        surface.Begin(Mesh.PrimitiveType.Triangles);
        for (var index = 0; index < points.Count - 1; index++)
        {
            var center0 = points[index] + Vector3.Up * verticalOffset;
            var center1 = points[index + 1] + Vector3.Up * verticalOffset;
            var right0Direction = tangents[index].Cross(Vector3.Up).Normalized();
            var right1Direction = tangents[index + 1].Cross(Vector3.Up).Normalized();
            var left0 = center0 + right0Direction * (float)leftOffset(layouts[index]);
            var right0 = center0 + right0Direction * (float)rightOffset(layouts[index]);
            var left1 = center1 + right1Direction * (float)leftOffset(layouts[index + 1]);
            var right1 = center1 + right1Direction * (float)rightOffset(layouts[index + 1]);
            // Metre UVs: U is lateral offset, V is route distance wrapped per
            // segment so float32 stays precise across the continent.
            var distance0 = routeDistance(samples[index]);
            var distance1 = routeDistance(samples[index + 1]);
            var v0 = (float)Environments.RegionalTerrainRibbon.WrapUv(distance0);
            var v1 = v0 + (float)(distance1 - distance0);
            var uLeft0 = (float)leftOffset(layouts[index]);
            var uRight0 = (float)rightOffset(layouts[index]);
            var uLeft1 = (float)leftOffset(layouts[index + 1]);
            var uRight1 = (float)rightOffset(layouts[index + 1]);

            AddTriangle(surface, left0, right1, right0, new Vector2(uLeft0, v0), new Vector2(uRight1, v1), new Vector2(uRight0, v0));
            AddTriangle(surface, left0, left1, right1, new Vector2(uLeft0, v0), new Vector2(uLeft1, v1), new Vector2(uRight1, v1));
        }

        surface.GenerateNormals();
        surface.GenerateTangents();
        return surface.Commit();
    }

    private void BuildTerrain(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        var stations = new Environments.GroundStation[points.Count];
        for (var index = 0; index < points.Count; index++)
        {
            stations[index] = new Environments.GroundStation(
                points[index],
                tangents[index].Cross(Vector3.Up).Normalized(),
                RouteDistance(samples[index]),
                layouts[index].PavedLeftMeters,
                layouts[index].PavedRightMeters);
        }
        _terrainCollisionMesh = Owned(
            Environments.RegionalTerrainRibbon.BuildGroundCollisionMesh(stations, _routeLengthMeters));
        var terrain = new MeshInstance3D
        {
            Name = "TerrainShoulders",
            Mesh = Owned(BuildTerrainMarginMesh(points, tangents, samples, layouts)),
            MaterialOverride = _visualKit.Terrain,
            CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
        };
        MarkRoadSemantic(terrain, "terrain-shoulders");
        AddChild(terrain);
    }

    /// <summary>
    /// The 120 m terrain margin either side of the paved edge, with the ground
    /// shader's metre UVs (lateral offset, wrapped route distance) and layer
    /// weights so it is continuous with the regional terrain ribbon beyond it.
    /// It winds like the paved ribbon, clockwise seen from above, which Godot
    /// treats as the front face; the collider built beside it in BuildTerrain
    /// winds the same way because a concave shape ignores back faces for the
    /// downward suspension rays.
    /// </summary>
    private ArrayMesh BuildTerrainMarginMesh(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        const float verticalOffset = Environments.RegionalTerrainRibbon.NearGroundOffsetMeters;
        using var surface = new SurfaceTool();
        surface.Begin(Mesh.PrimitiveType.Triangles);
        for (var index = 0; index < points.Count - 1; index++)
        {
            var center0 = points[index] + Vector3.Up * verticalOffset;
            var center1 = points[index + 1] + Vector3.Up * verticalOffset;
            var right0 = tangents[index].Cross(Vector3.Up).Normalized();
            var right1 = tangents[index + 1].Cross(Vector3.Up).Normalized();
            var distance0 = RouteDistance(samples[index]);
            var distance1 = RouteDistance(samples[index + 1]);
            var v0 = (float)Environments.RegionalTerrainRibbon.WrapUv(distance0);
            var v1 = v0 + (float)(distance1 - distance0);
            var color0 = GroundWeights(distance0);
            var color1 = GroundWeights(distance1);
            foreach (var side in new[] { -1f, 1f })
            {
                var inner0 = side < 0 ? layouts[index].PavedLeftMeters : layouts[index].PavedRightMeters;
                var inner1 = side < 0 ? layouts[index + 1].PavedLeftMeters : layouts[index + 1].PavedRightMeters;
                var outer0 = inner0 + side * RoadVisualKit.TerrainMarginMeters;
                var outer1 = inner1 + side * RoadVisualKit.TerrainMarginMeters;
                var a = center0 + right0 * (float)inner0;
                var b = center0 + right0 * (float)outer0;
                var c = center1 + right1 * (float)inner1;
                var d = center1 + right1 * (float)outer1;
                var uvA = new Vector2((float)inner0, v0);
                var uvB = new Vector2((float)outer0, v0);
                var uvC = new Vector2((float)inner1, v1);
                var uvD = new Vector2((float)outer1, v1);
                if (side < 0)
                {
                    AddTerrainTriangle(surface, a, b, d, uvA, uvB, uvD, color0, color0, color1);
                    AddTerrainTriangle(surface, a, d, c, uvA, uvD, uvC, color0, color1, color1);
                }
                else
                {
                    AddTerrainTriangle(surface, a, d, b, uvA, uvD, uvB, color0, color1, color0);
                    AddTerrainTriangle(surface, a, c, d, uvA, uvC, uvD, color0, color1, color1);
                }
            }
        }
        surface.GenerateNormals();
        surface.GenerateTangents();
        return surface.Commit();
    }

    private double RouteDistance(RouteChunkSample sample) =>
        double.IsNaN(_routeStartMeters)
            ? sample.DistanceMeters - _contentStartMeters
            : _routeStartMeters + sample.DistanceMeters - _contentStartMeters;

    private Color GroundWeights(double routeDistance) =>
        double.IsNaN(_routeLengthMeters)
            ? new Color(0.35f, 0.12f, 0.02f)
            : Environments.RegionalTerrainRibbon.GroundWeights(routeDistance, _routeLengthMeters);

    private static void AddTerrainTriangle(
        SurfaceTool surface,
        Vector3 first,
        Vector3 second,
        Vector3 third,
        Vector2 firstUv,
        Vector2 secondUv,
        Vector2 thirdUv,
        Color firstColor,
        Color secondColor,
        Color thirdColor)
    {
        surface.SetColor(firstColor);
        surface.SetUV(firstUv);
        surface.AddVertex(first);
        surface.SetColor(secondColor);
        surface.SetUV(secondUv);
        surface.AddVertex(second);
        surface.SetColor(thirdColor);
        surface.SetUV(thirdUv);
        surface.AddVertex(third);
    }

    private static void AddTriangle(
        SurfaceTool surface,
        Vector3 first,
        Vector3 second,
        Vector3 third,
        Vector2 firstUv,
        Vector2 secondUv,
        Vector2 thirdUv)
    {
        surface.SetUV(firstUv);
        surface.AddVertex(first);
        surface.SetUV(secondUv);
        surface.AddVertex(second);
        surface.SetUV(thirdUv);
        surface.AddVertex(third);
    }

    private void BuildLaneMarkings(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        using var whiteSurface = new SurfaceTool();
        whiteSurface.Begin(Mesh.PrimitiveType.Triangles);
        using var yellowSurface = new SurfaceTool();
        yellowSurface.Begin(Mesh.PrimitiveType.Triangles);
        for (var index = 0; index < points.Count - 1; index++)
        {
            var segment = points[index + 1] - points[index];
            if (segment.LengthSquared() < 0.001f)
            {
                continue;
            }
            var firstMarkings = GetMarkingOffsets(layouts[index]);
            var secondMarkings = GetMarkingOffsets(layouts[index + 1]);
            foreach (var id in firstMarkings.Keys.Intersect(
                         secondMarkings.Keys,
                         StringComparer.Ordinal))
            {
                AddDashedMarkingQuads(
                    whiteSurface,
                    points[index],
                    points[index + 1],
                    tangents[index],
                    tangents[index + 1],
                    firstMarkings[id],
                    secondMarkings[id],
                    samples[index].DistanceMeters,
                    samples[index + 1].DistanceMeters);
            }
            AddMarkingQuad(
                whiteSurface,
                points[index],
                points[index + 1],
                tangents[index],
                tangents[index + 1],
                layouts[index].LaneRightMeters,
                layouts[index + 1].LaneRightMeters,
                0.10f);
            AddMarkingQuad(
                yellowSurface,
                points[index],
                points[index + 1],
                tangents[index],
                tangents[index + 1],
                layouts[index].LaneLeftMeters,
                layouts[index + 1].LaneLeftMeters,
                0.10f);
        }
        var markings = Owned(whiteSurface.Commit());
        var laneMarkings = new MeshInstance3D
        {
            Name = "LaneMarkings",
            Mesh = markings,
            MaterialOverride = _visualKit.MarkingWhite,
        };
        MarkRoadSemantic(laneMarkings, "lane-markings");
        AddChild(laneMarkings);
        var medianEdgeMarking = new MeshInstance3D
        {
            Name = "MedianEdgeMarking",
            Mesh = Owned(yellowSurface.Commit()),
            MaterialOverride = _visualKit.MarkingYellow,
        };
        MarkRoadSemantic(medianEdgeMarking, "median-edge-marking");
        AddChild(medianEdgeMarking);
    }

    private static void AddDashedMarkingQuads(
        SurfaceTool surface,
        Vector3 first,
        Vector3 second,
        Vector3 firstTangent,
        Vector3 secondTangent,
        double firstOffset,
        double secondOffset,
        double startMeters,
        double endMeters)
    {
        const double dashMeters = 5;
        const double periodMeters = 13;
        if (endMeters <= startMeters)
        {
            return;
        }
        var dashStart = Math.Floor(startMeters / periodMeters) * periodMeters;
        for (; dashStart < endMeters; dashStart += periodMeters)
        {
            var visibleStart = Math.Max(startMeters, dashStart);
            var visibleEnd = Math.Min(endMeters, dashStart + dashMeters);
            if (visibleEnd <= visibleStart)
            {
                continue;
            }
            var firstFactor = (float)((visibleStart - startMeters) / (endMeters - startMeters));
            var secondFactor = (float)((visibleEnd - startMeters) / (endMeters - startMeters));
            AddMarkingQuad(
                surface,
                first.Lerp(second, firstFactor),
                first.Lerp(second, secondFactor),
                firstTangent.Lerp(secondTangent, firstFactor).Normalized(),
                firstTangent.Lerp(secondTangent, secondFactor).Normalized(),
                firstOffset + (secondOffset - firstOffset) * firstFactor,
                firstOffset + (secondOffset - firstOffset) * secondFactor,
                0.07f);
        }
    }

    private static Dictionary<string, double> GetMarkingOffsets(LaneGeometrySample layout)
    {
        var lanes = layout.Lanes
            .Where(lane => lane.WidthMeters > 0.05 && !lane.IsTransitioning)
            .OrderBy(lane => lane.CenterMeters)
            .ThenBy(lane => lane.Index)
            .ThenBy(lane => lane.Id, StringComparer.Ordinal)
            .ToArray();
        var result = new Dictionary<string, double>(StringComparer.Ordinal);
        for (var index = 0; index < lanes.Length - 1; index++)
        {
            var left = lanes[index];
            var right = lanes[index + 1];
            result[$"{left.Id}|{right.Id}"] =
                (left.CenterMeters + left.WidthMeters / 2 +
                    right.CenterMeters - right.WidthMeters / 2) / 2;
        }
        return result;
    }

    private void BuildReflectors(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        var yellow = new List<Transform3D>();
        var white = new List<Transform3D>();
        for (var index = 0; index < points.Count; index++)
        {
            var tangent = tangents[index].Normalized();
            var right = tangent.Cross(Vector3.Up).Normalized();
            var basis = Basis.LookingAt(tangent, Vector3.Up);
            var layout = layouts[index];
            yellow.Add(new Transform3D(
                basis,
                points[index] + right * (float)layout.LaneLeftMeters + Vector3.Up * 0.045f));
            white.Add(new Transform3D(
                basis,
                points[index] + right * (float)layout.LaneRightMeters + Vector3.Up * 0.045f));
            foreach (var offset in GetMarkingOffsets(layout).Values)
            {
                white.Add(new Transform3D(
                    basis,
                    points[index] + right * (float)offset + Vector3.Up * 0.045f));
            }
        }
        AddMultiMesh(
            "MedianReflectors",
            "reflectors.median",
            _visualKit.ReflectorMesh,
            yellow,
            _visualKit.ReflectorYellow);
        AddMultiMesh(
            "LaneReflectors",
            "reflectors.lane-and-shoulder",
            _visualKit.ReflectorMesh,
            white,
            _visualKit.ReflectorWhite);
        ReflectorCount = yellow.Count + white.Count;
    }

    private static void AddMarkingQuad(
        SurfaceTool surface,
        Vector3 first,
        Vector3 second,
        Vector3 firstTangent,
        Vector3 secondTangent,
        double firstOffset,
        double secondOffset,
        float halfWidth)
    {
        var firstRight = firstTangent.Cross(Vector3.Up).Normalized();
        var secondRight = secondTangent.Cross(Vector3.Up).Normalized();
        var firstCenter = first + firstRight * (float)firstOffset + Vector3.Up * 0.026f;
        var secondCenter = second + secondRight * (float)secondOffset + Vector3.Up * 0.026f;
        var firstLeft = firstCenter - firstRight * halfWidth;
        var firstRightPoint = firstCenter + firstRight * halfWidth;
        var secondLeft = secondCenter - secondRight * halfWidth;
        var secondRightPoint = secondCenter + secondRight * halfWidth;
        AddTriangle(
            surface,
            firstLeft,
            secondRightPoint,
            firstRightPoint,
            Vector2.Zero,
            Vector2.One,
            Vector2.Right);
        AddTriangle(
            surface,
            firstLeft,
            secondLeft,
            secondRightPoint,
            Vector2.Zero,
            Vector2.Up,
            Vector2.One);
    }

    private void AddMultiMesh(
        string name,
        string automationSuffix,
        Mesh mesh,
        IReadOnlyList<Transform3D> transforms,
        Material? materialOverride = null,
        GeometryInstance3D.ShadowCastingSetting castShadow =
            GeometryInstance3D.ShadowCastingSetting.On,
        IReadOnlyList<Color>? customData = null)
    {
        if (transforms.Count == 0)
        {
            return;
        }
        // Disposed once the instance owns it, so no wrapper survives to
        // finalisation after the engine has torn down.
        using var multiMesh = new MultiMesh
        {
            TransformFormat = MultiMesh.TransformFormatEnum.Transform3D,
            UseCustomData = customData is not null,
            Mesh = mesh,
            InstanceCount = transforms.Count,
        };
        for (var index = 0; index < transforms.Count; index++)
        {
            multiMesh.SetInstanceTransform(index, transforms[index]);
            if (customData is not null)
            {
                multiMesh.SetInstanceCustomData(index, customData[index]);
            }
        }
        var instance = new MultiMeshInstance3D
        {
            Name = name,
            Multimesh = multiMesh,
            MaterialOverride = materialOverride,
            CastShadow = castShadow,
        };
        MarkRoadSemantic(instance, automationSuffix);
        AddChild(instance);
    }

    private void BuildGoreAreas(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        var transforms = new List<Transform3D>();
        for (var index = 0; index < layouts.Count; index++)
        {
            foreach (var lane in layouts[index].Lanes.Where(lane =>
                         (lane.Role is LaneRole.ExitOnly or LaneRole.EntranceOnly) &&
                         lane.WidthMeters is > 0.2 and < 3.5))
            {
                var right = tangents[index].Cross(Vector3.Up).Normalized();
                var basis = Basis.LookingAt(tangents[index], Vector3.Up);
                transforms.Add(new Transform3D(
                    basis,
                    points[index] + right * (float)lane.CenterMeters + Vector3.Up * 0.04f));
            }
        }
        if (transforms.Count == 0)
        {
            return;
        }
        using var mesh = new BoxMesh
        {
            Size = new Vector3(0.18f, 0.025f, 2.5f),
        };
        AddMultiMesh("GoreAreas", "gore-markings", mesh, transforms, _visualKit.Gore);
        HasGoreGeometry = true;
    }

    private void BuildBarriers(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<RouteChunkSample> samples,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        var barrierTransforms = new List<Transform3D>();
        var guardrailTransforms = new List<Transform3D>();
        var guardrailPostTransforms = new List<Transform3D>();
        var segmentOffsets = new List<Color>();
        for (var index = 0; index < points.Count - 1; index++)
        {
            var length = points[index].DistanceTo(points[index + 1]);
            if (length < 0.01f)
            {
                continue;
            }
            var midpointDistance = Environments.RegionalTerrainRibbon.WrapUv(
                (RouteDistance(samples[index]) + RouteDistance(samples[index + 1])) * 0.5);
            segmentOffsets.Add(new Color((float)midpointDistance, 0, 0, 0));
            var tangent = (tangents[index] + tangents[index + 1]).Normalized();
            var right = tangent.Cross(Vector3.Up).Normalized();
            var segmentBasis = Basis.LookingAt(tangent, Vector3.Up);
            var stretchedBasis = segmentBasis;
            stretchedBasis.Z *= length;
            var midpoint = points[index].Lerp(points[index + 1], 0.5f);
            var leftOffset = (layouts[index].PavedLeftMeters +
                layouts[index + 1].PavedLeftMeters) / 2 - 0.45;
            var rightOffset = (layouts[index].PavedRightMeters +
                layouts[index + 1].PavedRightMeters) / 2 + 0.45;
            barrierTransforms.Add(new Transform3D(
                stretchedBasis,
                midpoint + right * (float)leftOffset + Vector3.Up * 0.41f));
            guardrailTransforms.Add(new Transform3D(
                stretchedBasis,
                midpoint + right * (float)rightOffset + Vector3.Up * 0.72f));
            guardrailPostTransforms.Add(new Transform3D(
                segmentBasis,
                points[index] + right * (float)rightOffset + Vector3.Up * 0.4f));
        }
        AddMultiMesh(
            "RoadBarriers",
            "median-barriers",
            _visualKit.MedianBarrierMesh,
            barrierTransforms,
            customData: segmentOffsets);
        AddMultiMesh(
            "Guardrails",
            "guardrails",
            _visualKit.GuardrailMesh,
            guardrailTransforms,
            customData: segmentOffsets);
        AddMultiMesh(
            "GuardrailPosts",
            "guardrail-posts",
            _visualKit.GuardrailPostMesh,
            guardrailPostTransforms);
        BarrierSegmentCount = barrierTransforms.Count;
        GuardrailSegmentCount = guardrailTransforms.Count;
    }

    private void BuildRouteStartBarrier(
        Vector3 point,
        Vector3 tangent,
        LaneGeometrySample layout)
    {
        const float extraWidthMeters = 1.5f;
        const float heightMeters = 1.05f;
        const float depthMeters = 0.75f;
        var left = (float)layout.PavedLeftMeters - extraWidthMeters / 2;
        var right = (float)layout.PavedRightMeters + extraWidthMeters / 2;
        var width = right - left;
        var lateralCenter = (left + right) / 2;
        var roadRight = tangent.Cross(Vector3.Up).Normalized();
        _routeStartBarrier = new MeshInstance3D
        {
            Name = "RouteStartBarrier",
            Mesh = Owned(new BoxMesh
            {
                Size = new Vector3(width, heightMeters, depthMeters),
            }),
            MaterialOverride = _visualKit.Concrete,
            Transform = new Transform3D(
                Basis.LookingAt(tangent, Vector3.Up),
                point + roadRight * lateralCenter + Vector3.Up * (heightMeters / 2)),
        };
        MarkRoadSemantic(_routeStartBarrier, "route-start-barrier");
        AddChild(_routeStartBarrier);
    }

    private void BuildScenery(
        IReadOnlyList<Vector3> points,
        IReadOnlyList<Vector3> tangents,
        IReadOnlyList<LaneGeometrySample> layouts)
    {
        var transforms = new List<Transform3D>();
        for (var index = 0; index < points.Count - 1; index++)
        {
            var tangent = tangents[index];
            var right = tangent.Cross(Vector3.Up).Normalized();
            transforms.Add(new Transform3D(
                Basis.Identity,
                points[index] + right * (float)(layouts[index].PavedLeftMeters - 1.5) +
                    Vector3.Up * 0.55f));
            transforms.Add(new Transform3D(
                Basis.Identity,
                points[index] + right * (float)(layouts[index].PavedRightMeters + 1.5) +
                    Vector3.Up * 0.55f));
        }

        AddMultiMesh(
            "RoadsidePosts",
            "delineator-posts",
            _visualKit.DelineatorMesh,
            transforms);

        // Sparse riprap boulders in the clear zone; stands of trees belong to the
        // regional environment layer, which knows the region and its density.
        var rockTransforms = new List<Transform3D>();
        for (var index = 0; index < points.Count - 1; index += 5)
        {
            var right = tangents[index].Cross(Vector3.Up).Normalized();
            var side = index % 10 == 0 ? -1 : 1;
            var edge = side < 0 ? layouts[index].PavedLeftMeters : layouts[index].PavedRightMeters;
            var distance = (float)Math.Abs(edge) + 9 + index % 7 * 1.6f;
            var size = 0.45f + index % 4 * 0.22f;
            var basis = Basis.FromEuler(new Vector3(0, index * 0.71f, 0))
                .Scaled(new Vector3(size * 1.3f, size * 0.7f, size));
            rockTransforms.Add(new Transform3D(
                basis,
                points[index] + right * (side * distance) +
                    Vector3.Up * (Environments.RegionalTerrainRibbon.NearGroundOffsetMeters - size * 0.15f)));
        }
        if (rockTransforms.Count == 0)
        {
            rockTransforms.Add(new Transform3D(
                Basis.Identity.Scaled(new Vector3(0.6f, 0.4f, 0.5f)),
                points[0] + tangents[0].Cross(Vector3.Up).Normalized() *
                    (float)(layouts[0].PavedRightMeters + 10) + Vector3.Up * -0.25f));
        }
        AddMultiMesh(
            "TerrainScenery",
            "placeholder-scenery",
            _visualKit.SceneryMesh,
            rockTransforms,
            castShadow: GeometryInstance3D.ShadowCastingSetting.Off);
    }

    private void MarkRoadSemantic(Node node, string suffix) =>
        RoadVisualKit.MarkSemantic(node, $"road.visual.chunk.{ChunkId}.{suffix}");

    // Godot resources are RefCounted, and a C# wrapper holds one of those
    // references until it is disposed or finalised. A chunk that is QueueFree'd
    // frees its node immediately, but any resource wrapper still held in a field
    // survives to finalisation, which can run after the engine has torn down.
    // That is what produces "Leaked unsafe reference to object" at shutdown and,
    // intermittently, a segmentation fault in the Linux smoke.
    //
    // Predelete fires only on actual destruction, unlike _ExitTree which also
    // fires on reparenting, so releasing here cannot strand a live node.
    public override void _Notification(int what)
    {
        if (what == NotificationPredelete)
        {
            _collisionMesh?.Dispose();
            _collisionMesh = null!;
            ReleaseOwnedResources();
        }
    }


    // Godot resources are RefCounted and their C# wrappers hold one of those
    // references. A wrapper built inline in a node initializer is dropped as soon
    // as the initializer completes, so nothing disposes it and it survives to
    // finalisation, which can run after the engine has torn down. That is what
    // produces "Leaked unsafe reference to object" at shutdown and, intermittently,
    // a segmentation fault in the Linux smoke.
    //
    // Wrapping a construction in Owned() records it so the wrapper is released with
    // this node. The node it was assigned to holds its own reference, so releasing
    // ours never affects anything rendering.
    private readonly List<Resource> _ownedResources = [];

    private T Owned<T>(T resource) where T : Resource
    {
        _ownedResources.Add(resource);
        return resource;
    }

    private void ReleaseOwnedResources()
    {
        foreach (var resource in _ownedResources)
        {
            resource.Dispose();
        }
        _ownedResources.Clear();
    }
}

public sealed record RouteContextLabelDiagnostic(
    string AutomationId,
    bool VisibleInTree,
    bool InCameraFrustum,
    float CameraDistanceMeters,
    float ForwardDistanceMeters,
    bool WithinDeclaredRange);

public sealed record RoadChunkVisualSnapshot(
    string ChunkId,
    string ProfileId,
    bool ContractResolved,
    bool MarkingSemanticsResolved,
    bool SignageContractResolved,
    int SemanticNodeCount,
    int SharedMaterialCount,
    int SharedMeshCount,
    int RetroreflectiveMaterialCount,
    int ReflectorCount,
    int BarrierSegmentCount,
    int GuardrailSegmentCount,
    int GuideSignCount,
    int RouteShieldCount,
    int StandardRouteShieldCount,
    int GeometricLaneArrowCount,
    int TypographyFallbackCount,
    int ServiceIconCount,
    bool HasGoreGeometry);
