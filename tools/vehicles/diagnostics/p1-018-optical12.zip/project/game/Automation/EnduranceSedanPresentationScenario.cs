using System.Security.Cryptography;
using System.Text.Json;
using Cannonball.Core.Runs;
using Cannonball.Game.Input;
using Cannonball.Game.Vehicle;
using Cannonball.Game.World;
using Cannonball.Game.World.Environments;
using Godot;

namespace Cannonball.Game.Automation;

/// <summary>Posed inspection fixtures. Never substitutes for the unfrozen driving scenario.</summary>
public sealed class EnduranceSedanPresentationScenario : IDisposable
{
    public static readonly string[] BaseStages =
    [
        "contract", "view-front", "view-rear", "view-left", "view-right", "view-top", "view-underside",
        "view-front-three-quarter", "view-rear-three-quarter", "turntable", "cockpit", "view-footwell", "view-rear-cabin",
        "inspection-keyboard", "inspection-controller",
        "open-Door_FL", "close-Door_FL", "open-Door_FR", "close-Door_FR",
        "open-Door_RL", "close-Door_RL", "open-Door_RR", "close-Door_RR",
        "open-Hood_Hinge", "close-Hood_Hinge", "open-Trunk_Hinge", "close-Trunk_Hinge",
        "lights-off", "headlights", "brake-lights", "reverse-lights", "left-indicator", "right-indicator", "hazards",
        "wipers-sweep", "wipers-park", "steering-small-right", "controls-left", "controls-right",
        "instruments-forward", "instruments-reverse", "instruments-low-fuel", "instruments-damage",
        "instruments-cooling", "instruments-tires", "instruments-panel-open", "instruments-park-brake", "mirrors-configuration",
        "lod-near", "lod-middle", "lod-far", "lod-return",
    ];
    private static readonly string[] FinalStages =
    [
        "contract", "wall-headlights-off", "wall-headlights-on", "wall-brake-headlights-off", "wall-brake-headlights-on",
        "partial-Door_FL", "partial-Door_FR", "partial-Door_RL", "partial-Door_RR", "partial-Hood_Hinge", "partial-Trunk_Hinge",
        "wipers-three-cycles", "wipers-park",
    ];
    private readonly List<object> _finalEvents = [];
    private bool _partialReversed;
    private int _wiperCycles;
    private bool _wiperReachedSweep;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };
    private static readonly DriveInputState Neutral = new(0, 0, 0, 0, 0, false, false);
    private static readonly Dictionary<string, string> WarningStages = new(StringComparer.Ordinal)
    {
        ["instruments-low-fuel"] = "LOW FUEL", ["instruments-damage"] = "DAMAGE",
        ["instruments-cooling"] = "COOLING", ["instruments-tires"] = "TIRES",
        ["instruments-panel-open"] = "PANEL OPEN", ["instruments-park-brake"] = "PARK BRAKE",
    };
    private readonly Node _parent;
    private readonly CannonballVehicle _vehicle;
    private readonly WorldStreamer _streamer;
    private readonly VehicleVisualRig _rig;
    private readonly EnduranceSedanPresentation _presentation;
    private readonly VehicleCondition _originalCondition;
    private readonly Camera3D _camera = new() { Name = "SedanInspectionCamera", Fov = 45, Near = 0.025f, Far = 200 };
    private readonly Node3D _fixture = new() { Name = "SedanPresentationFixture" };
    private readonly List<MeshInstance3D> _mirrorTargets = [];
    private readonly Dictionary<string, int> _mirrorObservedUpdates = new(StringComparer.Ordinal);
    private readonly Dictionary<string, int> _doorMirrorUpdateStart = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<Vector2>> _mirrorCentroids = new(StringComparer.Ordinal);
    private readonly List<object> _mirrorSamples = [];
    private readonly Dictionary<string, object> _displayUvMeasurements = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Vector3[]> _displayUvCorners = new(StringComparer.Ordinal);
    private readonly Dictionary<string, object> _warningVisibilities = new(StringComparer.Ordinal);
    private readonly Dictionary<string, int> _mirrorImageSamples = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Basis> _rest = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Vector3> _pedalCenters = new(StringComparer.Ordinal);
    private readonly List<object> _results = [];
    private readonly List<object> _captures = [];
    private readonly StreamWriter _frames;
    private readonly StreamWriter _mirrorFrameLog;
    private readonly string _directory;
    private readonly bool _rendered;
    private readonly string[] _expected;
    private readonly string? _diagnosticProbe;
    private readonly float? _diagnosticCameraSourceY;
    private readonly LightingPreset _mirrorLighting = LightingPreset.Day;
    private readonly Dictionary<Node3D, Transform3D> _originalMirrorAnchorTransforms = [];
    private readonly MeshInstance3D _floor;
    private Task? _captureTask;
    private Exception? _renderException;
    private int _stage;
    private long _frameSamples;
    private double _stageTime;
    private bool _begun;
    private bool _captured;
    private bool _leftSeenOn;
    private bool _rightSeenOn;
    private bool _blinkSeenOff;
    private bool _hazardsSeenTogether;
    private bool _hazardsMixedAfterLatency;
    private ulong _stageStartRenderFrame;
    private float _minimumWiperLeft;
    private float _minimumWiperRight;
    private bool _disposed;

    public EnduranceSedanPresentationScenario(Node parent, CannonballVehicle vehicle, WorldStreamer streamer, string directory)
    {
        _parent = parent;
        _vehicle = vehicle;
        _streamer = streamer;
        _rig = vehicle.VisualRig ?? throw new InvalidOperationException("Presentation requires the actual sedan wrapper.");
        _presentation = _rig.Presentation ?? throw new InvalidOperationException("Production presentation is missing; --sedan-blockout cannot pass this suite.");
        _originalCondition = vehicle.Condition;
        _directory = Path.GetFullPath(directory);
        _rendered = OS.GetCmdlineUserArgs().Contains("--sedan-captures", StringComparer.Ordinal);
        if (_rendered && DisplayServer.GetName() == "headless") throw new InvalidOperationException("Rendered mirror/capture proof requires a native renderer.");
        var probeArguments = OS.GetCmdlineUserArgs().Where(argument => argument.StartsWith("--sedan-presentation-probe=", StringComparison.Ordinal)).ToArray();
        if (probeArguments.Length > 1) throw new InvalidOperationException("Only one sedan presentation diagnostic probe may be selected.");
        _diagnosticProbe = probeArguments.Length == 1 ? probeArguments[0]["--sedan-presentation-probe=".Length..] : null;
        if (_diagnosticProbe is not null && (_diagnosticProbe is not ("mirrors" or "presentation-final") || !_rendered))
            throw new InvalidOperationException("--sedan-presentation-probe=mirrors requires native --sedan-captures and is not a full acceptance run.");
        var lightingArguments = OS.GetCmdlineUserArgs().Where(argument => argument.StartsWith("--sedan-mirror-lighting=", StringComparison.Ordinal)).ToArray();
        if (lightingArguments.Length > 1) throw new InvalidOperationException("Only one mirror diagnostic lighting preset may be selected.");
        if (lightingArguments.Length == 1)
        {
            var lighting = lightingArguments[0]["--sedan-mirror-lighting=".Length..];
            if (_diagnosticProbe != "mirrors" || lighting is not ("daylight" or "night"))
                throw new InvalidOperationException("--sedan-mirror-lighting=daylight|night requires the native mirror-only probe.");
            _mirrorLighting = lighting == "night" ? LightingPreset.Night : LightingPreset.Day;
        }
        var cameraArguments = OS.GetCmdlineUserArgs().Where(argument => argument.StartsWith("--sedan-mirror-camera-source-y=", StringComparison.Ordinal)).ToArray();
        if (cameraArguments.Length > 1) throw new InvalidOperationException("Only one diagnostic mirror-camera source Y may be selected.");
        if (cameraArguments.Length == 1)
        {
            if (_diagnosticProbe != "mirrors" || !float.TryParse(cameraArguments[0]["--sedan-mirror-camera-source-y=".Length..],
                    System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var sourceY) ||
                !float.IsFinite(sourceY) || sourceY is < 0.4f or > 0.7f)
                throw new InvalidOperationException("A diagnostic mirror-camera Y in 0.4..0.7 m requires the native mirror-only probe.");
            _diagnosticCameraSourceY = sourceY;
        }
        _expected = _diagnosticProbe == "presentation-final" ? FinalStages : _diagnosticProbe == "mirrors" ? ["mirrors-configuration", "mirrors-live", "mirrors-door-follow", "mirrors-disabled"] :
            _rendered ? [.. BaseStages, "mirrors-live", "mirrors-door-follow", "mirrors-disabled"] : BaseStages;
        Directory.CreateDirectory(_directory);
        _frames = new StreamWriter(Path.Combine(_directory, "presentation-frames.jsonl"), false);
        _mirrorFrameLog = new StreamWriter(Path.Combine(_directory, "mirror-samples.jsonl"), false) { AutoFlush = true };
        parent.AddChild(_fixture);
        parent.AddChild(_camera);
        _floor = Box("InspectionFloor", new Vector3(0, -0.06f, 0), new Vector3(240, 0.12f, 240), new Color("7c858c"));
        _fixture.AddChild(_floor);
        if (_diagnosticProbe == "presentation-final")
        {
            _fixture.AddChild(Box("DeclaredHeadlampWall", new Vector3(0, 1.2f, -8), new Vector3(12, 2.4f, 0.2f), new Color("7c858c")));
            _fixture.AddChild(Box("DeclaredRearLampWall", new Vector3(0, 0.8f, 4), new Vector3(12, 1.6f, 0.2f), new Color("7c858c")));
        }
        using (var floorShape = new BoxShape3D { Size = new Vector3(240, 0.12f, 240) })
        {
            var floorBody = new StaticBody3D { Name = "InspectionFloorContact", Position = _floor.Position, CollisionLayer = 1, CollisionMask = 2 };
            floorBody.AddChild(new CollisionShape3D { Shape = floorShape });
            _fixture.AddChild(floorBody);
        }
        for (var i = 0; i < 3; i++)
        {
            var target = Box("MirrorTarget" + i, Vector3.Zero, new Vector3(0.55f, 0.7f, 0.2f),
                i == 0 ? new Color(1, 0, 1) : i == 1 ? new Color(0, 1, 0) : new Color(0, 1, 1), unshaded: true);
            target.Visible = false;
            _fixture.AddChild(target);
            _mirrorTargets.Add(target);
        }
        _streamer.ProcessMode = Node.ProcessModeEnum.Disabled;
        _streamer.Visible = false;
        _vehicle.PlaceForReview(Vector3.Zero, Vector3.Forward);
        if (_diagnosticCameraSourceY is { } cameraSourceY)
        {
            var frame = _rig.ResolveAnchor("AssetRoot").GlobalTransform;
            foreach (var mirror in _presentation.Mirrors.Where(mirror => mirror.Name != "Rear"))
            {
                _originalMirrorAnchorTransforms[mirror.Anchor] = mirror.Anchor.Transform;
                var point = frame.AffineInverse() * mirror.Anchor.GlobalPosition;
                point.Z = -cameraSourceY;
                mirror.Anchor.GlobalPosition = frame * point;
            }
        }
        _vehicle.AutopilotEnabled = false;
        _vehicle.AutomationInputOverride = Neutral;
        foreach (var name in EnduranceSedanPresentation.OpeningNames.Concat(new[] { "SteeringWheel_Pivot", "Pedal_Accelerator", "Pedal_Brake", "Wiper_L", "Wiper_R" }))
            _rest[name] = _rig.ResolveAnchor(name).Basis;
        foreach (var name in new[] { "Pedal_Accelerator", "Pedal_Brake" })
        {
            var pad = _rig.ResolveAnchor("LOD0_" + name + "Pad") as MeshInstance3D ?? throw new InvalidOperationException("Pedal pad mesh is missing.");
            _pedalCenters[name] = _rig.ResolveAnchor(name).GlobalTransform.AffineInverse() * (pad.GlobalTransform * pad.GetAabb().GetCenter());
        }
        Lighting(_mirrorLighting);
        CameraAt(new Vector3(4.6f, 2.6f, -6.4f));
        if (_rendered) RenderingServer.FramePostDraw += ObserveRenderedFrame;
        GD.Print($"CANNONBALL_SEDAN_PRESENTATION_BEGIN stages={_expected.Length} posed=true rendered={_rendered.ToString().ToLowerInvariant()} diagnostic={_diagnosticProbe ?? "none"}");
    }

    public bool Complete { get; private set; }
    public string CurrentStage => _stage < _expected.Length ? _expected[_stage] : "complete";

    public void Advance(double delta)
    {
        if (Complete || _disposed) return;
        if (_renderException is not null) throw new InvalidOperationException("Rendered presentation verification failed.", _renderException);
        if (_captureTask is { IsFaulted: true }) _captureTask.GetAwaiter().GetResult();
        if (!_begun) { BeginStage(); _begun = true; }
        _stageTime += delta;
        if (CurrentStage == "turntable") CameraAt(new Vector3(Mathf.Sin((float)(_stageTime / 8 * Mathf.Tau)) * 6.8f, 2.5f, -Mathf.Cos((float)(_stageTime / 8 * Mathf.Tau)) * 6.8f));
        _vehicle.Condition = CurrentStage switch
        {
            "instruments-low-fuel" => _originalCondition with { FuelLiters = 10 },
            "instruments-damage" => _originalCondition with { Damage = 0.2 },
            "instruments-cooling" => _originalCondition with { CoolingCondition = 0.2 },
            "instruments-tires" => _originalCondition with { TireCondition = 0.2 },
            _ => _vehicle.Condition,
        };
        if (CurrentStage == "mirrors-live")
        {
            for (var i = 0; i < _mirrorTargets.Count; i++)
            {
                var mirror = _presentation.Mirrors[i];
                _mirrorTargets[i].GlobalPosition = mirror.Anchor.GlobalPosition + new Vector3(i == 0 ? -1.0f : i == 1 ? 1.0f : 0, 0.0f, 7.0f) +
                    Vector3.Right * Mathf.Sin((float)_stageTime * 1.4f) * 0.6f;
            }
        }
        // Main advances this fixture before the child's presenter process.
        // The first sample can therefore still belong to the previous input.
        // Apply the same explicit bounded output latency to every blink test.
        if (Engine.GetProcessFrames() - _stageStartRenderFrame > 2)
        {
            _leftSeenOn |= _presentation.LeftIndicatorLit;
            _rightSeenOn |= _presentation.RightIndicatorLit;
            _blinkSeenOff |= !_presentation.LeftIndicatorLit && !_presentation.RightIndicatorLit;
            if (CurrentStage == "hazards")
            {
                _hazardsSeenTogether |= _presentation.LeftIndicatorLit && _presentation.RightIndicatorLit;
                _hazardsMixedAfterLatency |= _presentation.LeftIndicatorLit != _presentation.RightIndicatorLit;
            }
        }
        var presentationState = _presentation.CaptureSnapshot();
        using var snapshot = JsonDocument.Parse(JsonSerializer.Serialize(presentationState));
        _minimumWiperLeft = Math.Min(_minimumWiperLeft, (float)snapshot.RootElement.GetProperty("joints").GetProperty("Wiper_L").GetProperty("angle_deg").GetDouble());
        _minimumWiperRight = Math.Min(_minimumWiperRight, (float)snapshot.RootElement.GetProperty("joints").GetProperty("Wiper_R").GetProperty("angle_deg").GetDouble());
        ObserveFinalMechanisms(snapshot.RootElement);
        _frames.WriteLine(JsonSerializer.Serialize(new
        {
            stage = CurrentStage, elapsed_s = _stageTime, render_frame = Engine.GetProcessFrames(), physics_frame = Engine.GetPhysicsFrames(),
            fixture = "posed presentation; conditioned input/state fixture", frozen = _vehicle.Freeze,
            input = _vehicle.LastDriveInput, signed_speed_mps = _vehicle.SignedLongitudinalSpeedMetersPerSecond,
            camera = _vehicle.GetViewport().GetCamera3D().Name.ToString(), lod = _rig.ActiveLod,
            lighting = SkyLighting.CurrentPreset?.ToString(),
            source_geometry_visible = _streamer.Visible, state = presentationState,
            stance = CaptureStance(),
        }));
        _frameSamples++;
        if (_stageTime < Duration()) return;
        ValidateStage(snapshot.RootElement);
        if (_rendered && !_captured)
        {
            _captureTask ??= CaptureAsync(CurrentStage);
            return;
        }
        _results.Add(new { stage = CurrentStage, status = "passed", duration_s = _stageTime, posed = true, rendered = _rendered, state = _presentation.CaptureSnapshot() });
        GD.Print($"CANNONBALL_SEDAN_PRESENTATION_STAGE_OK stage={CurrentStage} posed=true");
        _frames.Flush();
        _stage++;
        _stageTime = 0;
        _begun = _captured = false;
        _captureTask = null;
        if (_stage == _expected.Length) Finish();
    }

    private double Duration() => CurrentStage switch
    {
        "wipers-three-cycles" => _wiperCycles >= 3 ? _stageTime : 15,
        _ when CurrentStage.StartsWith("partial-", StringComparison.Ordinal) => 2.2,
        "turntable" => 8, "mirrors-live" => 6, "wipers-sweep" => 4, "wipers-park" => 1.6,
        "left-indicator" or "right-indicator" or "hazards" => 1.6,
        _ => 1.1,
    };

    private void BeginStage()
    {
        _vehicle.InspectionPanel.Close();
        _vehicle.LinearVelocity = Vector3.Zero;
        _vehicle.AutomationInputOverride = Neutral;
        _vehicle.Condition = _originalCondition;
        _floor.Visible = CurrentStage != "view-underside";
        _leftSeenOn = _rightSeenOn = _blinkSeenOff = false;
        _hazardsSeenTogether = _hazardsMixedAfterLatency = false;
        _stageStartRenderFrame = Engine.GetProcessFrames();
        _minimumWiperLeft = _minimumWiperRight = 0;
        if (CurrentStage.StartsWith("open-", StringComparison.Ordinal) || CurrentStage.StartsWith("close-", StringComparison.Ordinal))
        {
            var name = CurrentStage[(CurrentStage.IndexOf('-') + 1)..];
            _vehicle.InspectionPanel.Open();
            var control = Descendants(_vehicle.InspectionPanel).OfType<CheckButton>().Single(node => node.GetMeta("automation_id", "").AsString() == "vehicle.opening." + name.ToLowerInvariant().Replace('_', '-'));
            control.ButtonPressed = CurrentStage.StartsWith("open-", StringComparison.Ordinal);
            _vehicle.InspectionPanel.Close();
            CameraAt(name is "Hood_Hinge" ? new Vector3(3.6f, 2.5f, -4.6f) : name is "Trunk_Hinge" ? new Vector3(3.6f, 2.3f, 4.6f) : new Vector3(name.EndsWith("L", StringComparison.Ordinal) ? -4.8f : 4.8f, 1.9f, -1.2f));
        }
        if (CurrentStage.StartsWith("partial-", StringComparison.Ordinal))
        {
            _partialReversed = false;
            CommandOpening(CurrentStage["partial-".Length..], true);
        }
        if (CurrentStage.StartsWith("wall-", StringComparison.Ordinal))
        {
            Lighting(LightingPreset.Night);
            _presentation.SetHeadlampMode(CurrentStage.EndsWith("-on", StringComparison.Ordinal) ? 1 : 2);
            _vehicle.AutomationInputOverride = Neutral with { Brake = CurrentStage.Contains("brake", StringComparison.Ordinal) ? 0.8f : 0 };
            CameraAt(new Vector3(6, 2.8f, 0), new Vector3(0, 0.8f, -1));
        }
        if (CurrentStage == "wipers-three-cycles")
        {
            Lighting(LightingPreset.Overcast); Cockpit();
            _wiperCycles = 0; _wiperReachedSweep = false; _presentation.SetWipers(true);
        }
        switch (CurrentStage)
        {
            case "view-front": CameraAt(new Vector3(0, 1.3f, -7)); break;
            case "view-rear": CameraAt(new Vector3(0, 1.3f, 7)); break;
            case "view-left": CameraAt(new Vector3(-7, 1.2f, 0)); break;
            case "view-right": CameraAt(new Vector3(7, 1.2f, 0)); break;
            case "view-top": CameraAt(new Vector3(0.001f, 9, 0)); break;
            case "view-underside": CameraAt(new Vector3(0.001f, -6, 0)); break;
            case "view-front-three-quarter": CameraAt(new Vector3(4.6f, 2.6f, -6.4f)); break;
            case "view-rear-three-quarter": CameraAt(new Vector3(-4.6f, 2.6f, 6.4f)); break;
            case "cockpit": Cockpit(); break;
            case "view-footwell": CameraAt(new Vector3(-0.43f, 0.67f, 0.20f), new Vector3(-0.40f, 0.33f, -0.70f)); break;
            case "view-rear-cabin": CameraAt(new Vector3(0, 1.12f, -0.03f), new Vector3(0, 0.92f, 1.15f)); break;
            case "inspection-keyboard":
                CameraAt(new Vector3(4.6f, 2.6f, -6.4f));
                using (var key = new InputEventKey { Keycode = Key.F2, PhysicalKeycode = Key.F2, Pressed = true }) Godot.Input.ParseInputEvent(key);
                using (var key = new InputEventKey { Keycode = Key.F2, PhysicalKeycode = Key.F2, Pressed = false }) Godot.Input.ParseInputEvent(key);
                break;
            case "inspection-controller":
                using (var button = new InputEventJoypadButton { Device = 0, ButtonIndex = JoyButton.RightShoulder, Pressed = true }) Godot.Input.ParseInputEvent(button);
                using (var button = new InputEventJoypadButton { Device = 0, ButtonIndex = JoyButton.RightShoulder, Pressed = false }) Godot.Input.ParseInputEvent(button);
                break;
            case "lights-off": Lighting(LightingPreset.Night); _presentation.SetHeadlampMode(2); CameraAt(new Vector3(4.6f, 2.3f, -6.4f)); break;
            case "headlights": _presentation.SetHeadlampMode(1); break;
            case "brake-lights": CameraAt(new Vector3(3.5f, 1.9f, 6)); _vehicle.AutomationInputOverride = Neutral with { Brake = 0.8f }; break;
            case "reverse-lights": _vehicle.AutomationInputOverride = Neutral with { Reverse = 0.6f }; break;
            case "left-indicator": _presentation.SetIndicator(-1); break;
            case "right-indicator": _presentation.SetIndicator(1); break;
            case "hazards": _presentation.SetHazards(true); break;
            case "wipers-sweep": _presentation.SetHazards(false); _presentation.SetIndicator(1); Lighting(LightingPreset.Overcast); CameraAt(new Vector3(-3.4f, 2.7f, -3.5f)); _presentation.SetWipers(true); break;
            case "wipers-park": _presentation.SetWipers(false); break;
            case "steering-small-right": Cockpit(); _vehicle.AutomationInputOverride = Neutral with { Steering = 0.02f }; break;
            case "controls-left": Cockpit(); _vehicle.AutomationInputOverride = Neutral with { Throttle = 0.7f, Steering = -0.75f }; break;
            case "controls-right": _vehicle.AutomationInputOverride = Neutral with { Brake = 0.6f, Steering = 0.75f }; break;
            case "instruments-forward": Cockpit(); _vehicle.LinearVelocity = Vector3.Forward * 32.18688f; _vehicle.AutomationInputOverride = Neutral with { Throttle = 0.5f }; break;
            case "instruments-reverse": _vehicle.LinearVelocity = Vector3.Back * 3; _vehicle.AutomationInputOverride = Neutral with { Reverse = 0.4f }; break;
            case "instruments-low-fuel": _vehicle.Condition = _originalCondition with { FuelLiters = 10 }; break;
            case "instruments-panel-open": _presentation.SetOpening("Door_FL", true); break;
            case "instruments-park-brake": _presentation.SetOpening("Door_FL", false); _vehicle.AutomationInputOverride = Neutral with { Handbrake = 1 }; break;
            case "mirrors-configuration": Cockpit(); Lighting(_mirrorLighting); break;
            case "lod-near": CameraAt(new Vector3(0, 1.3f, 12)); break;
            case "lod-middle": CameraAt(new Vector3(0, 1.3f, 40)); break;
            case "lod-far": CameraAt(new Vector3(0, 1.3f, 80)); break;
            case "lod-return": CameraAt(new Vector3(0, 1.3f, 12)); break;
            case "mirrors-live": Cockpit(); Lighting(_mirrorLighting); foreach (var target in _mirrorTargets) target.Visible = true; break;
            case "mirrors-door-follow":
                foreach (var target in _mirrorTargets) target.Visible = false;
                foreach (var mirror in _presentation.Mirrors) _doorMirrorUpdateStart[mirror.Name] = mirror.UpdateCount;
                _presentation.SetOpening("Door_FL", true);
                _presentation.SetOpening("Door_FR", true);
                Cockpit();
                break;
            case "mirrors-disabled":
                _presentation.SetOpening("Door_FL", false);
                _presentation.SetOpening("Door_FR", false);
                CameraAt(new Vector3(4.6f, 2.6f, -6.4f));
                foreach (var target in _mirrorTargets) target.Visible = false;
                break;
        }
    }

    private void ValidateStage(JsonElement state)
    {
        Require(_vehicle.Freeze, "posed suite unexpectedly enabled rigid-body driving");
        ValidateFinalMechanisms(state);
        ValidateRearSpill();
        if (CurrentStage.StartsWith("lod-", StringComparison.Ordinal)) ValidateVisibleLamps(state);
        if (CurrentStage.StartsWith("open-", StringComparison.Ordinal) || CurrentStage.StartsWith("close-", StringComparison.Ordinal))
        {
            var name = CurrentStage[(CurrentStage.IndexOf('-') + 1)..];
            var open = CurrentStage.StartsWith("open-", StringComparison.Ordinal);
            var index = Array.IndexOf(EnduranceSedanPresentation.OpeningNames, name);
            var expectedAngle = open ? _presentation.Setup.OpeningAnglesDegrees[index] : 0;
            Require(Math.Abs(_presentation.OpeningAngleDegrees(name) - expectedAngle) < 0.01f, "opening endpoint mismatch");
            var expectedBasis = new Basis(index < 4 ? Vector3.Up : Vector3.Right, Mathf.DegToRad(expectedAngle)) * _rest[name];
            Require(_rig.ResolveAnchor(name).Basis.IsEqualApprox(expectedBasis), "actual hinge basis differs from its source contract");
            Require(state.GetProperty("joints").GetProperty(name).GetProperty("mesh_descendants").GetInt32() > 0, "opening has no modeled assembly");
        }
        switch (CurrentStage)
        {
            case "contract":
                Require(_rig.ContractResolved && _presentation.Mirrors.Count == 3, "production contract incomplete");
                VerifyDisplayUv("Instrument_Cluster", _presentation.InstrumentViewport);
                foreach (var mirror in _presentation.Mirrors) VerifyDisplayUv("Mirror_" + mirror.Name, mirror.Viewport, mirror: true);
                break;
            case "inspection-keyboard":
            case "inspection-controller": Require(_vehicle.InspectionPanel.IsOpen && _vehicle.GetViewport().GuiGetFocusOwner() is not null, "input event did not open a focused inspection panel"); break;
            case "lights-off": Require(!state.GetProperty("headlights").GetBoolean(), "headlights did not switch off"); break;
            case "headlights": Require(state.GetProperty("headlights").GetBoolean(), "headlights did not switch on"); break;
            case "brake-lights": Require(state.GetProperty("brakes").GetBoolean(), "brake state did not light brakes"); break;
            case "reverse-lights": Require(state.GetProperty("reverse").GetBoolean(), "reverse state did not light reverse emitters"); break;
            case "left-indicator": Require(_leftSeenOn && !_rightSeenOn && _blinkSeenOff, "left indicator did not blink independently"); break;
            case "right-indicator": Require(_rightSeenOn && !_leftSeenOn && _blinkSeenOff, "right indicator did not blink independently"); break;
            case "hazards": Require(_hazardsSeenTogether && !_hazardsMixedAfterLatency && _blinkSeenOff, "hazards did not blink simultaneously after the two-frame latency allowance"); break;
            case "wipers-sweep": Require(_minimumWiperLeft < -77.5f && _minimumWiperRight < -73.5f, "wipers did not traverse their declared sweep"); break;
            case "wipers-park":
                Require(!state.GetProperty("wiper_parking").GetBoolean(), "wipers are still parking");
                foreach (var name in new[] { "Wiper_L", "Wiper_R" })
                    Require(Math.Abs(state.GetProperty("joints").GetProperty(name).GetProperty("angle_deg").GetDouble()) < 1 && _rig.ResolveAnchor(name).Basis.IsEqualApprox(_rest[name]), "wiper angle or actual rest basis did not return to park: " + name);
                break;
            case "steering-small-right":
                var column = _rig.ResolveAnchor("SteeringWheel_Pivot");
                var restTop = _rest["SteeringWheel_Pivot"] * (Vector3.Up * 0.18f);
                var movedTop = column.Basis * (Vector3.Up * 0.18f);
                var tireNose = _rig.ResolveAnchor("Suspension_FL").Basis * Vector3.Forward;
                Require(_vehicle.CurrentSteeringRadians is > 0 and < 0.03f && tireNose.X > 0 && movedTop.X - restTop.X > 0.01f,
                    "small right steering does not move both the actual tire nose and the top of the actual rim right");
                break;
            case "controls-left":
            case "controls-right":
                Require(Math.Abs(state.GetProperty("steering_wheel_deg").GetDouble() - Mathf.RadToDeg(_vehicle.CurrentSteeringRadians) * 14.5) < 0.01, "steering wheel does not follow the actual steering state");
                Require(Math.Abs(state.GetProperty("accelerator_deg").GetDouble() - _vehicle.LastDriveInput.Throttle * -18) < 0.01 && Math.Abs(state.GetProperty("brake_pedal_deg").GetDouble() - _vehicle.LastDriveInput.Brake * -12) < 0.01, "pedals do not follow control state");
                foreach (var name in new[] { "Pedal_Accelerator", "Pedal_Brake" })
                {
                    var amount = name == "Pedal_Accelerator" ? _vehicle.LastDriveInput.Throttle : _vehicle.LastDriveInput.Brake;
                    var maximum = name == "Pedal_Accelerator" ? -18 : -12;
                    var actual = _rig.ResolveAnchor(name).Basis;
                    Require(actual.IsEqualApprox(_rest[name] * new Basis(Vector3.Right, Mathf.DegToRad(maximum * amount))), "pedal actual basis does not match control input: " + name);
                    if (amount > 0.1f)
                        Require((actual * _pedalCenters[name]).Z < (_rest[name] * _pedalCenters[name]).Z - 0.005f, "actual pedal pad does not move forward under pressure: " + name);
                }
                break;
            case "instruments-forward": Require(state.GetProperty("display").GetProperty("speed").GetString() == "72" && state.GetProperty("gear").GetString() == "4" && state.GetProperty("rpm").GetDouble() is > 3850 and < 3900, "72mph fictional kinematic instrument fixture mismatch"); break;
            case "instruments-reverse": Require(state.GetProperty("gear").GetString() == "R", "reverse instrument fixture mismatch"); break;
            case "instruments-low-fuel": Require(state.GetProperty("warning").GetString() == "LOW FUEL" && state.GetProperty("display").GetProperty("fuel").GetString() == "10 L", "fuel/warning does not follow explicit vehicle condition"); break;
            case "mirrors-configuration":
                for (var mirrorIndex = 0; mirrorIndex < _presentation.Mirrors.Count; mirrorIndex++)
                {
                    var mirror = _presentation.Mirrors[mirrorIndex];
                    Require(mirror.Viewport.Size == (mirror.Name == "Rear" ? new Vector2I(384, 128) : new Vector2I(256, 128)) && (mirror.Camera.CullMask & EnduranceSedanPresentation.MirrorSurfaceLayer) == 0 && !mirror.Viewport.OwnWorld3D, "mirror size/world/nonrecursive configuration mismatch");
                    VerifyMirrorBinding(mirror);
                    if (_rendered && !_mirrorImageSamples.ContainsKey("hidden-" + mirror.Name))
                    {
                        using var image = mirror.Viewport.GetTexture().GetImage();
                        Require(image is not null && !image.IsEmpty(), "mirror hidden-target image is empty");
                        image!.Convert(Image.Format.Rgba8);
                        var pixels = MeasureTargetPixels(image, mirrorIndex);
                        var sample = new { mirror = mirror.Name, frame = Engine.GetProcessFrames(), scope = "targets-hidden-negative-control", pixels = pixels.Count, targets_visible = _mirrorTargets.Any(target => target.Visible) };
                        _mirrorSamples.Add(sample);
                        _mirrorFrameLog.WriteLine(JsonSerializer.Serialize(sample));
                        SaveImage(image, "mirror-" + mirror.Name + "-targets-hidden.png");
                        _mirrorImageSamples["hidden-" + mirror.Name] = 1;
                        Require(mirror.UpdateCount >= 3 && !_mirrorTargets.Any(target => target.Visible) && pixels.Count < 8,
                            "mirror detector found its target color in the hidden-target background: " + mirror.Name);
                    }
                }
                break;
            case "lod-near":
            case "lod-return": Require(_rig.ActiveLod == 0, "near distance did not select LOD0"); break;
            case "lod-middle": Require(_rig.ActiveLod == 1, "middle distance did not select LOD1"); break;
            case "lod-far": Require(_rig.ActiveLod == 2, "far distance did not select LOD2"); break;
            case "mirrors-live":
                foreach (var mirror in _presentation.Mirrors)
                    Require(_mirrorCentroids.TryGetValue(mirror.Name, out var points) && points.Count >= 10 && points.Max(point => point.X) - points.Min(point => point.X) >= 3, "live mirror has no independently observed moving target: " + mirror.Name);
                break;
            case "mirrors-door-follow":
                foreach (var mirror in _presentation.Mirrors.Where(mirror => mirror.Name != "Rear"))
                {
                    var doorName = mirror.Name == "Left" ? "Door_FL" : "Door_FR";
                    var door = _rig.ResolveAnchor(doorName);
                    Require(door.IsAncestorOf(mirror.Anchor) && door.IsAncestorOf(_rig.ResolveAnchor("Mirror_" + mirror.Name)), "side mirror or camera is not attached to its front door");
                    Require(Math.Abs(_presentation.OpeningAngleDegrees(doorName)) > 60, "front door did not open for mirror-follow check");
                    var expected = mirror.Anchor.GetGlobalTransformInterpolated() * new Transform3D(
                        new Basis(Vector3.Up, Mathf.Pi + mirror.Yaw) * new Basis(Vector3.Right, -0.03f), Vector3.Zero);
                    Require(mirror.Active && mirror.UpdateCount - _doorMirrorUpdateStart[mirror.Name] >= 8 &&
                        mirror.Camera.GlobalPosition.DistanceTo(expected.Origin) < 0.001f && mirror.Camera.GlobalBasis.IsEqualApprox(expected.Basis),
                        "actual mirror camera/render updates did not follow the opening door: " + mirror.Name);
                    VerifyMirrorBinding(mirror);
                }
                break;
            case "mirrors-disabled": Require(_presentation.Mirrors.All(mirror => !mirror.Active && !mirror.PendingUpdate), "mirrors continued outside cockpit"); break;
        }
        foreach (var lamp in state.GetProperty("lamps").EnumerateObject())
        {
            var lit = lamp.Value.GetProperty("lit").GetBoolean();
            Require(lamp.Value.GetProperty("material_emission").EnumerateArray().All(value => lit ? value.GetDouble() > 0 : value.GetDouble() == 0), "native lamp material does not match state: " + lamp.Name);
            var lightVisible = lamp.Value.GetProperty("light_visible");
            Require(lightVisible.ValueKind == JsonValueKind.Null || lightVisible.GetBoolean() == lit, "native light visibility does not match its emitter state: " + lamp.Name);
        }
        if (WarningStages.TryGetValue(CurrentStage, out var expectedWarning))
            Require(state.GetProperty("warning").GetString() == expectedWarning &&
                state.GetProperty("display").GetProperty("warning").GetString()!.Contains(expectedWarning, StringComparison.Ordinal),
                "warning does not follow explicit condition/input/opening state: " + expectedWarning);
    }

    private void CommandOpening(string name, bool open)
    {
        _vehicle.InspectionPanel.Open();
        var control = Descendants(_vehicle.InspectionPanel).OfType<CheckButton>().Single(node =>
            node.GetMeta("automation_id", "").AsString() == "vehicle.opening." + name.ToLowerInvariant().Replace('_', '-'));
        control.ButtonPressed = open;
        _vehicle.InspectionPanel.Close();
        CameraAt(name is "Hood_Hinge" ? new Vector3(3.6f, 2.5f, -4.6f) : name is "Trunk_Hinge" ?
            new Vector3(3.6f, 2.3f, 4.6f) : new Vector3(name.EndsWith("L", StringComparison.Ordinal) ? -4.8f : 4.8f, 1.9f, -1.2f));
        _finalEvents.Add(new { kind = "opening-command", stage = CurrentStage, name, open,
            frame = Engine.GetProcessFrames(), elapsed_s = _stageTime,
            angle_deg = _presentation.OpeningAngleDegrees(name), control = control.GetPath().ToString() });
    }

    private void ObserveFinalMechanisms(JsonElement state)
    {
        if (CurrentStage.StartsWith("partial-", StringComparison.Ordinal) && !_partialReversed)
        {
            var name = CurrentStage["partial-".Length..];
            var index = Array.IndexOf(EnduranceSedanPresentation.OpeningNames, name);
            var fraction = _presentation.OpeningAngleDegrees(name) / _presentation.Setup.OpeningAnglesDegrees[index];
            if (fraction >= 0.5f)
            {
                Require(fraction < 1, "opening reached full endpoint before its partial reversal");
                _finalEvents.Add(new { kind = "partial-reversal", stage = CurrentStage, name,
                    fraction, frame = Engine.GetProcessFrames(), elapsed_s = _stageTime, observed = state.Clone() });
                CommandOpening(name, false); _partialReversed = true;
            }
        }
        if (CurrentStage != "wipers-three-cycles") return;
        Require(_presentation.WipersOn, "three-cycle sweep was interrupted");
        var left = state.GetProperty("joints").GetProperty("Wiper_L").GetProperty("angle_deg").GetDouble();
        var right = state.GetProperty("joints").GetProperty("Wiper_R").GetProperty("angle_deg").GetDouble();
        _wiperReachedSweep |= left < -77.5 && right < -73.5;
        if (_wiperReachedSweep && Math.Abs(left) < 1 && Math.Abs(right) < 1)
        {
            _wiperCycles++; _wiperReachedSweep = false;
            _finalEvents.Add(new { kind = "wiper-cycle", stage = CurrentStage, cycle = _wiperCycles,
                frame = Engine.GetProcessFrames(), elapsed_s = _stageTime, left_deg = left, right_deg = right, enabled = _presentation.WipersOn });
        }
    }

    private void ValidateFinalMechanisms(JsonElement state)
    {
        if (CurrentStage.StartsWith("partial-", StringComparison.Ordinal))
        {
            var name = CurrentStage["partial-".Length..];
            Require(_partialReversed && Math.Abs(_presentation.OpeningAngleDegrees(name)) < 0.01f &&
                _rig.ResolveAnchor(name).Basis.IsEqualApprox(_rest[name]) &&
                state.GetProperty("joints").GetProperty(name).GetProperty("target").GetDouble() == 0,
                "partial UI-command reversal did not return to the complete original rest basis");
        }
        if (CurrentStage == "wipers-three-cycles")
            Require(_wiperCycles >= 3 && _presentation.WipersOn && _minimumWiperLeft < -77.5f && _minimumWiperRight < -73.5f,
                "three uninterrupted complete wiper cycles missing");
        if (!CurrentStage.StartsWith("wall-", StringComparison.Ordinal)) return;
        Require(_presentation.CaptureDrivingIllumination().Matches(CurrentStage.EndsWith("-on", StringComparison.Ordinal)) &&
            _presentation.BrakeLightsOn == CurrentStage.Contains("brake", StringComparison.Ordinal), "matched wall/road lamp state differs");
        ValidateVisibleLamps(state);
    }

    private void ValidateRearSpill()
    {
        Require(!Descendants(_rig.ResolveAnchor("Light_Brake_Center")).OfType<Light3D>().Any(),
            "central brake lamp must not have an artificial interior spill light");
        foreach (var name in new[] { "Light_Brake_L", "Light_Brake_R", "Light_Reverse_L", "Light_Reverse_R" })
        {
            var lights = Descendants(_rig.ResolveAnchor(name)).OfType<Light3D>().ToArray();
            Require(lights.Length == 1 && lights[0] is SpotLight3D, "rear lamp spill must use one directed spot: " + name);
            var spot = (SpotLight3D)lights[0];
            var forward = _vehicle.GlobalBasis.Inverse() * -spot.GlobalBasis.Z;
            Require(forward.DistanceTo(new Vector3(0, -0.1391731f, 0.9902681f)) < 0.00001f &&
                spot.SpotRange == 4 && spot.SpotAngle == 55 && !spot.ShadowEnabled,
                "actual rear/downward spill direction, range or shadow cost changed: " + name);
        }
    }

    private void ObserveRenderedFrame()
    {
        if (Complete || CurrentStage != "mirrors-live" || !_begun) return;
        try
        {
            for (var i = 0; i < _presentation.Mirrors.Count; i++)
            {
                var mirror = _presentation.Mirrors[i];
                if (mirror.UpdateCount == 0 || mirror.UpdateCount == _mirrorObservedUpdates.GetValueOrDefault(mirror.Name)) continue;
                _mirrorObservedUpdates[mirror.Name] = mirror.UpdateCount;
                var texture = mirror.Viewport.GetTexture();
                using var image = texture.GetImage();
                if (image is null || image.IsEmpty()) throw new InvalidOperationException("Mirror image is empty.");
                image.Convert(Image.Format.Rgba8);
                var pixels = MeasureTargetPixels(image, i);
                var count = pixels.Count;
                var target = _mirrorTargets[i].GlobalPosition;
                var projected = mirror.Camera.UnprojectPosition(target);
                var inMainCamera = _vehicle.GetViewport().GetCamera3D().IsPositionInFrustum(target);
                var centroid = pixels.Centroid;
                var sample = new { mirror = mirror.Name, frame = Engine.GetProcessFrames(), completed_frame = mirror.LastUpdateFrame, requested_frame = mirror.RequestedAtFrame, update = mirror.UpdateCount, pixels = count, target_world = Vec(target), target_projection = new[] { projected.X, projected.Y }, observed_centroid = new[] { centroid.X, centroid.Y }, projection_error_px = count > 0 ? centroid.DistanceTo(projected) : (float?)null, main_camera_visible = inMainCamera };
                _mirrorSamples.Add(sample);
                _mirrorFrameLog.WriteLine(JsonSerializer.Serialize(sample));
                var imageSample = _mirrorImageSamples.GetValueOrDefault(mirror.Name) + 1;
                _mirrorImageSamples[mirror.Name] = imageSample;
                if (imageSample is 1 or 20) SaveImage(image, $"mirror-{mirror.Name}-sample-{imageSample:00}.png");
                Require(!inMainCamera, "mirror target is visible to the main camera");
                if (count >= 8)
                {
                    Require(centroid.DistanceTo(projected) <= 5.0f, "mirror target pixels differ by more than 5px from their camera projection: " + mirror.Name);
                    VerifyMirrorBinding(mirror);
                    if (!_mirrorCentroids.TryGetValue(mirror.Name, out var points)) _mirrorCentroids[mirror.Name] = points = [];
                    points.Add(centroid);
                    if (points.Count is 1 or 20) SaveImage(image, $"mirror-{mirror.Name}-{points.Count:00}.png");
                }
            }
        }
        catch (Exception exception) { _renderException = exception; }
    }

    internal static (int Count, Vector2 Centroid) MeasureTargetPixels(Image image, int marker)
    {
        // Tone mapping changes a bright green marker to (123,209,70), and
        // the modeled rear glass attenuates cyan to about (20,122,125).
        // Color separation preserves the marker identity through those real
        // responses. A rendered targets-hidden check rejects background hits.
        var bytes = image.GetData();
        var count = 0;
        double sumX = 0, sumY = 0;
        for (var y = 0; y < image.GetHeight(); y++) for (var x = 0; x < image.GetWidth(); x++)
        {
            var at = (y * image.GetWidth() + x) * 4;
            var red = (int)bytes[at]; var green = (int)bytes[at + 1]; var blue = (int)bytes[at + 2];
            var match = marker switch
            {
                0 => red > 80 && blue > 80 && red - green > 40 && blue - green > 40,
                1 => green > 80 && green - red > 40 && green - blue > 40,
                _ => green > 80 && blue > 80 && green - red > 40 && blue - red > 40,
            };
            if (match) { count++; sumX += x; sumY += y; }
        }
        return (count, count > 0 ? new Vector2((float)(sumX / count), (float)(sumY / count)) : new Vector2(-1, -1));
    }

    private object CaptureStance()
    {
        var suffixes = new[] { "FL", "FR", "RL", "RR" };
        return new
        {
            chassis_origin = Vec(_vehicle.GlobalPosition), visible_floor_y = _floor.GlobalPosition.Y + 0.06f,
            wheels = Enumerable.Range(0, 4).Select(index =>
            {
                var ray = _vehicle.SuspensionRay(index);
                var center = _rig.ResolveAnchor("Wheel_" + suffixes[index]).GlobalPosition;
                return new
                {
                    wheel = suffixes[index], center = Vec(center),
                    nominal_tire_bottom_y = center.Y - _vehicle.RigSetup.TireRadiusMeters,
                    compression_m = _vehicle.SuspensionCompressionMeters(index),
                    contact = ray.IsColliding(),
                    collider = ray.IsColliding() ? (ray.GetCollider() as Node)?.Name.ToString() : null,
                    contact_position = ray.IsColliding() ? Vec(ray.GetCollisionPoint()) : null,
                    collision_mask = ray.CollisionMask,
                };
            }).ToArray(),
        };
    }

    private void VerifyDisplayUv(string name, SubViewport viewport, bool mirror = false)
    {
        var anchor = _rig.ResolveAnchor(name);
        var meshes = Descendants(anchor).OfType<MeshInstance3D>().Where(mesh => mesh.IsVisibleInTree()).ToArray();
        Require(meshes.Length > 0, "display has no visible mesh: " + name);
        var sums = new Vector3[4];
        var counts = new int[4];
        var expectedTexture = viewport.GetTexture();
        foreach (var mesh in meshes)
        {
            if (mirror)
                VerifyMirrorSurface(mesh, name["Mirror_".Length..], expectedTexture);
            else
            {
                var material = mesh.MaterialOverride as StandardMaterial3D;
                Require(material?.AlbedoTexture?.GetRid() == expectedTexture.GetRid(), "display uses a different viewport texture: " + name);
                Require(material!.Uv1Scale.IsEqualApprox(Vector3.One) && material.Uv1Offset.IsZeroApprox(), "instrument material changes the authored UV transform");
            }
            var transform = anchor.GlobalTransform.AffineInverse() * mesh.GlobalTransform;
            for (var surface = 0; surface < mesh.Mesh.GetSurfaceCount(); surface++)
            {
                using var arrays = mesh.Mesh.SurfaceGetArrays(surface);
                var vertices = arrays[(int)Mesh.ArrayType.Vertex].AsVector3Array();
                var uvs = arrays[(int)Mesh.ArrayType.TexUV].AsVector2Array();
                Require(vertices.Length > 0 && vertices.Length == uvs.Length, "display vertex/UV inventory mismatch: " + name);
                for (var index = 0; index < vertices.Length; index++)
                {
                    var uv = uvs[index];
                    Require(uv.IsFinite() && uv.X is >= -0.0001f and <= 1.0001f && uv.Y is >= -0.0001f and <= 1.0001f, "display UV lies outside its single image: " + name);
                    var u = Mathf.Abs(uv.X) < 0.0001f ? 0 : Mathf.Abs(uv.X - 1) < 0.0001f ? 1 : -1;
                    var v = Mathf.Abs(uv.Y) < 0.0001f ? 0 : Mathf.Abs(uv.Y - 1) < 0.0001f ? 1 : -1;
                    if (u < 0 || v < 0) continue;
                    var corner = u + 2 * v;
                    sums[corner] += transform * vertices[index];
                    counts[corner]++;
                }
            }
        }
        Require(counts.All(count => count > 0), "display does not cover all four image corners: " + name);
        var corners = sums.Select((sum, index) => sum / counts[index]).ToArray();
        _displayUvCorners[name] = corners;
        var right = corners[1] - corners[0];
        var down = corners[2] - corners[0];
        var aspect = right.Length() / down.Length();
        _displayUvMeasurements[name] = new
        {
            corners = corners.Select(Vec).ToArray(), corner_vertex_counts = counts,
            u_direction = Vec(right.Normalized()), v_direction = Vec(down.Normalized()),
            aspect_ratio = aspect, viewport_aspect_ratio = (float)viewport.Size.X / viewport.Size.Y,
            matching_viewport_texture = true, material_horizontal_reflection = mirror,
        };
        Require(right.Normalized().Dot(Vector3.Right) > 0.99f && down.Normalized().Dot(Vector3.Down) > 0.95f,
            "actual display UV axes do not run right and down on the visible surface: " + name);
        if (!mirror)
            Require(Math.Abs(aspect / ((float)viewport.Size.X / viewport.Size.Y) - 1) < 0.02,
                "instrument surface stretches its viewport aspect by more than two percent");
    }

    private void VerifyMirrorBinding(EnduranceSedanPresentation.Mirror mirror) =>
        VerifyMirrorBinding(_rig, _presentation, mirror, Require);

    internal static void VerifyMirrorBinding(VehicleVisualRig rig, EnduranceSedanPresentation presentation,
        EnduranceSedanPresentation.Mirror mirror, Action<bool, string> require)
    {
        // These resources belong to the presenter/viewport. Several surfaces
        // share the same material and texture, so disposing a borrowed alias
        // would invalidate the expected identity used by the next surface.
        var expectedTexture = mirror.Viewport.GetTexture();
        var meshes = Descendants(rig.ResolveAnchor("Mirror_" + mirror.Name)).OfType<MeshInstance3D>().ToArray();
        require(meshes.Length > 0, "mirror has no display surfaces: " + mirror.Name);
        foreach (var mesh in meshes)
            VerifyMirrorSurface(rig, presentation, mesh, mirror.Name, expectedTexture, require);
    }

    private void VerifyMirrorSurface(MeshInstance3D mesh, string name, Texture2D expectedTexture) =>
        VerifyMirrorSurface(_rig, _presentation, mesh, name, expectedTexture, Require);

    private static void VerifyMirrorSurface(VehicleVisualRig rig, EnduranceSedanPresentation presentation,
        MeshInstance3D mesh, string name, Texture2D expectedTexture, Action<bool, string> require)
    {
        var channel = name switch { "Left" => 0, "Right" => 1, "Rear" => 2, _ => -1 };
        var material = mesh.MaterialOverride as ShaderMaterial;
        require(channel >= 0 && material?.Shader?.ResourcePath == "res://game/Vehicle/mirror_display.gdshader",
            "mirror has no actual project shader override: " + name);
        var selector = mesh.GetInstanceShaderParameter("mirror_index");
        require(selector.VariantType == Variant.Type.Int && selector.AsInt32() == channel,
            "mirror surface instance selects a different channel: " + name);
        require(material!.GetShaderParameter("mirror_" + name.ToLowerInvariant()).AsGodotObject() is Texture2D texture &&
            texture.GetRid() == expectedTexture.GetRid() && mesh.Layers == EnduranceSedanPresentation.MirrorSurfaceLayer,
            "mirror surface texture identity or self-exclusion layer differs: " + name);
        foreach (var other in presentation.Mirrors)
        {
            var expected = other.Viewport.GetTexture();
            require(material.GetShaderParameter("mirror_" + other.Name.ToLowerInvariant()).AsGodotObject() is Texture2D bound &&
                bound.GetRid() == expected.GetRid(), "shared mirror material crosses presentation feeds");
            foreach (var member in Descendants(rig.ResolveAnchor("Mirror_" + other.Name)).OfType<MeshInstance3D>())
                require(member.MaterialOverride?.GetRid() == material.GetRid(), "mirror materials are not shared across all LOD descendants");
        }
    }

    private void ValidateVisibleLamps(JsonElement state)
    {
        foreach (var lamp in state.GetProperty("lamps").EnumerateObject())
        {
            var visible = Descendants(_rig.ResolveAnchor(lamp.Name)).OfType<MeshInstance3D>().Where(mesh => mesh.IsVisibleInTree()).ToArray();
            Require(visible.Length > 0, "active LOD has no state-driven lamp emitter: " + lamp.Name);
            var expectedEnergy = lamp.Value.GetProperty("emission").GetDouble();
            foreach (var mesh in visible)
            {
                Require(mesh.Name.ToString().StartsWith($"LOD{_rig.ActiveLod}_", StringComparison.Ordinal), "visible lamp does not belong to the actual selected LOD: " + mesh.Name);
                for (var surface = 0; surface < mesh.Mesh.GetSurfaceCount(); surface++)
                {
                    var material = mesh.GetActiveMaterial(surface) as StandardMaterial3D;
                    Require(material is not null && material.EmissionEnabled && Math.Abs(material.EmissionEnergyMultiplier - expectedEnergy) < 0.001,
                        "visible lamp material does not match runtime emission state: " + mesh.Name);
                }
            }
        }
    }

    private async Task CaptureAsync(string stage)
    {
        await _parent.ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
        var contactShading = CaptureRenderedContactShading();
        var viewport = _vehicle.GetViewport();
        var texture = viewport.GetTexture();
        using var image = texture.GetImage();
        if (image is null || image.IsEmpty()) throw new InvalidOperationException("Actual presentation capture is empty.");
        var path = SaveImage(image, $"{_stage + 1:00}-{stage}.png");
        _captures.Add(new { stage, camera = viewport.GetCamera3D().Name.ToString(), camera_position = Vec(viewport.GetCamera3D().GlobalPosition),
            size = new[] { image.GetWidth(), image.GetHeight() }, path, sha256 = Hash(path), frame = Engine.GetProcessFrames(), posed = true,
            lighting = SkyLighting.CurrentPreset?.ToString(), actual_environment_preset = _parent.GetNode<WorldEnvironment>("NightEnvironment").Environment!.GetMeta("lighting_preset", "missing").AsString(),
            renderer = RenderingServer.GetCurrentRenderingMethod().ToString(),
            render_quality = new
            {
                actual_msaa_3d = viewport.Msaa3D.ToString(),
                applied_tier = viewport.GetMeta("render_quality", "missing").AsString(),
                applied_directional_shadow_size = viewport.GetMeta("directional_shadow_size", -1).AsInt32(),
                global_quality_basis = "Atlas/tier are applied-call metadata; MSAA is a live Viewport property.",
            }, lod = _rig.ActiveLod, contact_shading = contactShading });
        if (stage is "cockpit" or "instruments-forward" || WarningStages.ContainsKey(stage))
        {
            var display = _presentation.InstrumentViewport.GetTexture();
            using var displayImage = display.GetImage();
            SaveImage(displayImage, "display-" + stage + ".png");
            if (WarningStages.TryGetValue(stage, out var expectedWarning)) VerifyWarningVisibility(image, displayImage, expectedWarning);
        }
        _captured = true;
    }

    private object CaptureRenderedContactShading()
    {
        var shading = _vehicle.ContactShading;
        Require(shading is not null, "selected sedan has no contact-shading component");
        var floorTransform = _floor.GetGlobalTransformInterpolated();
        var floorTop = floorTransform * new Vector3(0, 0.06f, 0);
        var floorNormal = floorTransform.Basis.Y.Normalized();
        var stance = Enumerable.Range(0, 4).Select(index =>
        {
            var suffix = new[] { "FL", "FR", "RL", "RR" }[index];
            var ray = _vehicle.SuspensionRay(index);
            var center = _rig.ResolveAnchor("Wheel_" + suffix).GetGlobalTransformInterpolated().Origin;
            if (shading!.SupportedRenderer)
            {
                var state = shading.ReadWheel(index);
                Require(state.Supported && state.EligibleReceiver && state.Visible,
                    "actual inspection contact shading is not visible on all four supported wheels: " + suffix);
                Require(ray.GetCollider() is Node collider && collider.Name == "InspectionFloorContact" && collider.GetParent() == _fixture,
                    "inspection contact ray did not hit this fixture's actual floor: " + suffix);
                Require(state.DerivedDisplayErrorMeters <= 0.001f && state.WheelTangentialErrorMeters <= 0.001f && state.ContactPlaneErrorMeters <= 0.001f,
                    "displayed contact shading is displaced from the interpolated wheel/contact plane: " + suffix);
            }
            return new { wheel = suffix, displayed_center = Vec(center), nominal_tire_bottom_above_floor_m = (center - floorTop).Dot(floorNormal) - _vehicle.RigSetup.TireRadiusMeters };
        }).ToArray();
        if (shading!.SupportedRenderer)
        {
            Require((_floor.Layers & VehicleContactShading.ReceiverLayer) != 0,
                "actual visible inspection floor is missing the contact-shading receiver layer");
            Require(Descendants(_fixture).OfType<MeshInstance3D>().All(mesh => mesh == _floor || (mesh.Layers & VehicleContactShading.ReceiverLayer) == 0),
                "contact shading registered an unrelated inspection mesh");
        }
        return new
        {
            boundary = "native-frame-post-draw", process_frame = Engine.GetProcessFrames(), physics_frame = Engine.GetPhysicsFrames(), drawn_frame = Engine.GetFramesDrawn(),
            status = shading.SupportedRenderer ? "passed" : "unsupported-renderer",
            snapshot = shading.CaptureSnapshot(), floor_path = _floor.GetPath().ToString(), floor_layers = _floor.Layers,
            floor_visible = _floor.IsVisibleInTree(), displayed_floor_origin = Vec(floorTransform.Origin), displayed_floor_top = Vec(floorTop), displayed_floor_normal = Vec(floorNormal),
            displayed_chassis_origin = Vec(_vehicle.GetGlobalTransformInterpolated().Origin), stance,
            scope = "Actual contact eligibility, layers and displayed alignment; visual quality and performance need independent review.",
        };
    }

    private void VerifyWarningVisibility(Image cockpitImage, Image displayImage, string expectedWarning)
    {
        var rectangle = _presentation.InstrumentWarningRect;
        var glyphs = new List<Vector2I>();
        for (var y = (int)rectangle.Position.Y; y < rectangle.End.Y; y++)
            for (var x = (int)rectangle.Position.X; x < rectangle.End.X; x++)
            {
                var color = displayImage.GetPixel(x, y);
                if (color.R >= 0.8f && color.G >= 0.45f && color.R - color.G >= 0.1f && color.G - color.B >= 0.2f)
                    glyphs.Add(new Vector2I(x, y));
            }
        _warningVisibilities[CurrentStage] = new { stage = CurrentStage, warning = expectedWarning, source_glyph_pixels = glyphs.Count,
            passed = false, failure = "No strong amber glyphs measured yet" };
        Require(glyphs.Count >= 40, "actual " + expectedWarning + " viewport has no strong amber warning glyphs");
        var corners = _displayUvCorners["Instrument_Cluster"];
        var transform = _rig.ResolveAnchor("Instrument_Cluster").GetGlobalTransformInterpolated();
        var camera = _vehicle.GetViewport().GetCamera3D();
        var middle = (glyphs.Min(point => point.Y) + glyphs.Max(point => point.Y)) * 0.5f;
        var counts = new int[2];
        var matched = new int[2];
        var projected = new List<object>();
        foreach (var glyph in glyphs)
        {
            var u = (glyph.X + 0.5f) / displayImage.GetWidth();
            var v = (glyph.Y + 0.5f) / displayImage.GetHeight();
            var local = corners[0] + (corners[1] - corners[0]) * u + (corners[2] - corners[0]) * v;
            var pixel = camera.UnprojectPosition(transform * local);
            var x = Mathf.RoundToInt(pixel.X);
            var y = Mathf.RoundToInt(pixel.Y);
            var seen = false;
            for (var dy = -1; dy <= 1; dy++)
                for (var dx = -1; dx <= 1; dx++)
                    if (x + dx >= 0 && x + dx < cockpitImage.GetWidth() && y + dy >= 0 && y + dy < cockpitImage.GetHeight())
                    {
                        var color = cockpitImage.GetPixel(x + dx, y + dy);
                        seen |= color.R >= 0.3f && color.G >= 0.2f && color.R - color.G >= 0.06f && color.G - color.B >= 0.1f;
                    }
            var half = glyph.Y <= middle ? 0 : 1;
            counts[half]++;
            if (seen) matched[half]++;
            projected.Add(new { source_pixel = new[] { glyph.X, glyph.Y }, cockpit_pixel = new[] { pixel.X, pixel.Y }, matched = seen });
        }
        var totalRatio = (float)matched.Sum() / glyphs.Count;
        var halfRatios = matched.Select((value, index) => counts[index] > 0 ? (float)value / counts[index] : 0).ToArray();
        _warningVisibilities[CurrentStage] = new
        {
            stage = CurrentStage, frame = Engine.GetProcessFrames(), warning = expectedWarning,
            warning_rect = new[] { rectangle.Position.X, rectangle.Position.Y, rectangle.Size.X, rectangle.Size.Y },
            source_glyph_pixels = glyphs.Count, matched_glyph_pixels = matched.Sum(), total_ratio = totalRatio,
            half_source_counts = counts, half_matched_counts = matched, half_ratios = halfRatios,
            required_total_ratio = 0.90, required_half_ratio = 0.85, search_radius_pixels = 1,
            screen_corners = corners.Select(point => Vec(transform * point)).ToArray(),
            camera_position = Vec(camera.GlobalPosition), camera_forward = Vec(-camera.GlobalBasis.Z),
            passed = totalRatio >= 0.90f && halfRatios.All(ratio => ratio >= 0.85f), projected_glyph_samples = projected,
        };
        Require(totalRatio >= 0.90f && halfRatios.All(ratio => ratio >= 0.85f),
            $"actual cockpit warning glyphs are occluded: total={totalRatio:0.000}, upper={halfRatios[0]:0.000}, lower={halfRatios[1]:0.000}");
    }

    private void CameraAt(Vector3 point, Vector3? target = null)
    {
        _vehicle.SetCameraMode(false);
        _camera.GlobalPosition = point;
        _camera.LookAt(target ?? new Vector3(0, 0.8f, 0), Math.Abs(point.Y) > 5 ? Vector3.Forward : Vector3.Up);
        _camera.MakeCurrent();
    }
    private void Cockpit() { _camera.Current = false; _vehicle.SetCameraMode(true); }
    private void Lighting(LightingPreset preset) => SkyLighting.Apply(_parent.GetNode<DirectionalLight3D>(SkyLighting.LightNodeName), _parent.GetNode<WorldEnvironment>(SkyLighting.EnvironmentNodeName).Environment!, preset);
    private static MeshInstance3D Box(string name, Vector3 point, Vector3 size, Color color, bool unshaded = false)
    {
        using var material = new StandardMaterial3D { AlbedoColor = color, Roughness = 0.85f, ShadingMode = unshaded ? BaseMaterial3D.ShadingModeEnum.Unshaded : BaseMaterial3D.ShadingModeEnum.PerPixel };
        using var mesh = new BoxMesh { Size = size, Material = material };
        return new MeshInstance3D { Name = name, Position = point, Mesh = mesh };
    }
    private string SaveImage(Image image, string name)
    {
        var path = Path.Combine(_directory, name);
        var error = image.SavePng(path);
        if (error != Error.Ok) throw new IOException($"Could not save {path}: {error}");
        return path;
    }
    private static float[] Vec(Vector3 value) => [value.X, value.Y, value.Z];
    private static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    private static IEnumerable<Node> Descendants(Node node) { foreach (var child in node.GetChildren()) { yield return child; foreach (var descendant in Descendants(child)) yield return descendant; } }
    private void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException($"Sedan presentation '{CurrentStage}': {message}"); }

    private void Finish()
    {
        _vehicle.InspectionPanel.Close();
        _vehicle.Condition = _originalCondition;
        _vehicle.AutomationInputOverride = Neutral;
        _frames.Dispose();
        _mirrorFrameLog.Dispose();
        WriteSummary("passed");
        Complete = true;
        GD.Print($"CANNONBALL_SEDAN_PRESENTATION_OK stages={_results.Count} posed=true rendered={_rendered.ToString().ToLowerInvariant()} diagnostic={_diagnosticProbe ?? "none"}");
    }

    private void WriteSummary(string status)
    {
        var inputs = new Dictionary<string, string>();
        var unavailableInputs = new List<string>();
        foreach (var relative in new[] { "game/Automation/EnduranceSedanPresentationScenario.cs", "game/Vehicle/VehicleContactShading.cs", "game/Vehicle/EnduranceSedanPresentation.cs", "game/Vehicle/mirror_display.gdshader", "game/Vehicle/mirror_display.gdshader.uid", "game/Vehicle/EnduranceSedanPresentationSetup.cs", "game/Vehicle/Setups/EnduranceSedanPresentation.tres", "game/Vehicle/VehicleInspectionPanel.cs", "game/Main.cs", "game/Vehicle/Setups/EnduranceSedan.tres", "game/Vehicle/Visuals/EnduranceSedan.tscn", "docs/vehicles/endurance-sedan/specification.json", "data/assets/vehicles/derived/endurance-sedan.glb", "assets/vehicles/endurance-sedan/endurance-sedan.generated.tscn" })
        {
            var absolute = ProjectSettings.GlobalizePath("res://" + relative);
            if (File.Exists(absolute)) inputs[relative] = Hash(absolute);
            else unavailableInputs.Add(relative);
        }
        File.WriteAllText(Path.Combine(_directory, "presentation-summary.json"), JsonSerializer.Serialize(new
        {
            schema_version = 1, task_id = "P1-018", status,
            vehicle = "endurance-sedan", loaded_asset = _vehicle.RigSetup.AssetId,
            physics_hz = Engine.PhysicsTicksPerSecond, frame_samples = _frameSamples,
            scope = _diagnosticProbe is null ? "posed presentation fixtures; not driving evidence" : "targeted native diagnostic only; not full presentation acceptance",
            diagnostic_probe = _diagnosticProbe, failed_stage = status == "passed" ? null : CurrentStage,
            diagnostic_side_mirror_camera_source_y_m = _diagnosticCameraSourceY,
            mirror_lighting = _mirrorLighting == LightingPreset.Night ? "night" : "daylight",
            git_revision = OS.GetEnvironment("CANNONBALL_GIT_REVISION"), utc = DateTimeOffset.UtcNow, platform = OS.GetName(), engine = Engine.GetVersionInfo()["string"].AsString(),
            arguments = OS.GetCmdlineUserArgs(), input_hashes = inputs,
            input_hash_scope = "physically available repository files; packaged PCK/assembly hashes are bound by the external package verifier",
            unavailable_input_paths = unavailableInputs, user_data_directory = OS.GetUserDataDir(),
            executable_path = OS.GetExecutablePath(), runtime_is_debug_build = OS.IsDebugBuild(),
            expected_stages = _expected, completed_stages = _results,
            rendered = _rendered, renderer = RenderingServer.GetCurrentRenderingMethod().ToString(), captures = _captures, mirror_samples = _mirrorSamples,
            final_events = _finalEvents,
            display_uv_measurements = _displayUvMeasurements,
            warning_visibility = _warningVisibilities.GetValueOrDefault("instruments-low-fuel"),
            warning_visibilities = _warningVisibilities,
            mirror_samples_sha256 = Hash(Path.Combine(_directory, "mirror-samples.jsonl")),
            frames_sha256 = Hash(Path.Combine(_directory, "presentation-frames.jsonl")), human_approval = (string?)null,
            limitations = new[] { "Posed fixtures do not prove handling or physical device usability", "Native target pixels prove mirror image updates; frame-budget and freshness deadlines need the separate real-time benchmark", "Swept mesh clearances and wiper glass contact require the geometric export/QA pass", "Human visual, rights and usability gates remain open" },
        }, JsonOptions));
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        if (_rendered) RenderingServer.FramePostDraw -= ObserveRenderedFrame;
        foreach (var (anchor, transform) in _originalMirrorAnchorTransforms)
            if (GodotObject.IsInstanceValid(anchor)) anchor.Transform = transform;
        _frames.Dispose();
        _mirrorFrameLog.Dispose();
        if (!Complete) WriteSummary("failed");
    }
}

/// <summary>Opt-in capture fixture only. Never changes vehicle, camera or mirror scheduling.</summary>
internal sealed class SedanFinalMirrorCapture : IDisposable
{
    private readonly Node _parent;
    private readonly CannonballVehicle _vehicle;
    private readonly WorldStreamer _streamer;
    private readonly EnduranceSedanPresentation _presentation;
    private readonly Func<string> _stage;
    private readonly Func<bool> _running;
    private readonly string _directory;
    private readonly Node3D _fixture = new() { Name = "FinalMovingNumberedTargets", PhysicsInterpolationMode = Node.PhysicsInterpolationModeEnum.Off };
    private readonly List<MeshInstance3D> _targets = [];
    private readonly Dictionary<string, Draw> _draws = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<Vector2>> _centroids = new(StringComparer.Ordinal);
    private readonly HashSet<string> _hidden = new(StringComparer.Ordinal);
    private readonly HashSet<(string Mirror, int Count)> _rebaseDraws = [];
    private readonly StreamWriter _log;
    private string? _failure;
    private string _activeStage = "";
    private bool _retainedProjectionFailure;
    private bool _disposed;
    private bool _complete;
    private int _rows;
    private int _dashboardRows;
    private readonly List<object> _stages = [];

    private sealed record Draw(string Stage, ulong Frame, ulong Requested, int RequestCount, int Updates,
        Transform3D Mirror, Transform3D Main, Transform3D EffectiveMirror, Transform3D EffectiveMain, Transform3D AssignedMirror,
        bool MirrorInterpolated, bool MirrorInterpolationEnabled,
        Transform3D Body, Transform3D Target, Transform3D Label, ulong TargetRid, ulong LabelRid,
        Vector2 Projection, bool Hidden, bool Outside, object MainProjection, WorldStreamSnapshot Origin,
        object Presentation, object Illumination, DriveInputState Input);

    internal SedanFinalMirrorCapture(Node parent, CannonballVehicle vehicle, WorldStreamer streamer, string directory,
        Func<string> stage, Func<bool> running)
    {
        _parent = parent; _vehicle = vehicle; _streamer = streamer; _directory = directory;
        _stage = stage; _running = running; _presentation = vehicle.VisualRig!.Presentation!;
        _log = new StreamWriter(Path.Combine(directory, "final-live.jsonl"), false) { AutoFlush = true };
        parent.AddChild(_fixture);
        Require(_presentation.Mirrors.Count == 3 && _presentation.Setup.MirrorRefreshHz == 15,
            "original three-feed/15Hz configuration missing");
        using var fiducialShader = new Shader { Code = MovingFiducialShader };
        for (var i = 0; i < 3; i++)
        {
            using var material = new ShaderMaterial { Shader = fiducialShader };
            material.SetShaderParameter("frame_color", i == 0 ? new Color(1, 0, 1) : i == 1 ? new Color(0, 1, 0) : new Color(0, 1, 1));
            material.SetShaderParameter("marker_number", i + 1);
            using var mesh = new BoxMesh { Size = new Vector3(0.55f, 0.7f, 0.2f), Material = material };
            var target = new MeshInstance3D { Name = "DiagnosticTarget" + (i + 1), Mesh = mesh, Visible = false,
                PhysicsInterpolationMode = Node.PhysicsInterpolationModeEnum.Off };
            target.AddChild(new Label3D { Text = (i + 1).ToString(), FontSize = 48, PixelSize = 0.003f,
                Modulate = Colors.White, OutlineSize = 4, Position = new Vector3(0, 0, 0.12f),
                Billboard = BaseMaterial3D.BillboardModeEnum.Disabled });
            _fixture.AddChild(target); _targets.Add(target);
        }
        RenderingServer.FramePreDraw += BeforeDraw;
        RenderingServer.FramePostDraw += AfterDraw;
        Write(new { kind = "fixture", channels = new[] { "Left", "Right", "Rear" }, numbered_targets = new[] { 1, 2, 3 },
            box_triangles = 36, labels = 3, collision_bodies = 0, shipping = false,
            submission_method = "RenderingServer.InstanceSetTransform", scene_physics_interpolation = parent.GetTree().PhysicsInterpolation,
            instance_membership = _targets.Select((target, index) => new { marker = index + 1,
                target_instance_rid = target.GetInstance().Id,
                label_instance_rid = target.GetChildren().OfType<Label3D>().Single().GetInstance().Id,
                target_interpolated = target.IsPhysicsInterpolated(),
                label_interpolated = target.GetChildren().OfType<Label3D>().Single().IsPhysicsInterpolated() }).ToArray(),
            policy = "Moving numbered diagnostic targets; no traffic, mirror-optics or performance claim.",
            optical_fiducial = MovingFiducialPolicy(),
            optical_shader_sha256 = Convert.ToHexString(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(fiducialShader.Code))).ToLowerInvariant(),
            detector = new { minimum_pixels = 8, maximum_projection_error_px = 5, minimum_observations = 10, minimum_span_px = 3,
                source = "EnduranceSedanPresentationScenario.MeasureTargetPixels; original hidden and moving target bounds" } });
    }

    private sealed record ColorComponent(int Count, long SumX, long SumY, Vector2 Centroid, int[] Bounds, int[] Indices);
    private sealed record ColorComponents(int Width, int Height, int RawCount, long RawSumX, long RawSumY,
        ColorComponent[] Components, int QualifyingCount, int Count, Vector2 Centroid);

    // Final moving fixture only. Identity uses the whole image, never a predicted position or crop.
    private static ColorComponents MeasureMovingTargetComponents(byte[] bytes, int width, int height, int marker)
    {
        if (width <= 0 || height <= 0 || bytes.Length != checked(width * height * 4) || marker is < 0 or > 2)
            throw new ArgumentException("Invalid moving target image domain.");
        var mask = new bool[width * height];
        var rawCount = 0; long rawSumX = 0, rawSumY = 0;
        for (var y = 0; y < height; y++) for (var x = 0; x < width; x++)
        {
            var at = (y * width + x) * 4;
            var red = (int)bytes[at]; var green = (int)bytes[at + 1]; var blue = (int)bytes[at + 2];
            var match = marker switch
            {
                0 => red > 80 && blue > 80 && red - green > 40 && blue - green > 40,
                1 => green > 80 && green - red > 40 && green - blue > 40,
                _ => green > 80 && blue > 80 && green - red > 40 && blue - red > 40,
            };
            if (!match) continue;
            mask[y * width + x] = true; rawCount++; rawSumX += x; rawSumY += y;
        }
        var components = new List<ColorComponent>();
        var queue = new int[mask.Length];
        for (var seed = 0; seed < mask.Length; seed++)
        {
            if (!mask[seed]) continue;
            mask[seed] = false;
            var head = 0; var tail = 1; queue[0] = seed;
            var count = 0; long sumX = 0, sumY = 0;
            var minX = width; var minY = height; var maxX = -1; var maxY = -1;
            while (head < tail)
            {
                var at = queue[head++]; var x = at % width; var y = at / width;
                count++; sumX += x; sumY += y;
                minX = Math.Min(minX, x); minY = Math.Min(minY, y);
                maxX = Math.Max(maxX, x); maxY = Math.Max(maxY, y);
                for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++)
                {
                    var nx = x + dx; var ny = y + dy;
                    if (dx == 0 && dy == 0 || nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                    var next = ny * width + nx;
                    if (!mask[next]) continue;
                    mask[next] = false; queue[tail++] = next;
                }
            }
            components.Add(new ColorComponent(count, sumX, sumY,
                new Vector2((float)((double)sumX / count), (float)((double)sumY / count)), [minX, minY, maxX, maxY], queue[..tail]));
        }
        var qualifying = components.Where(component => component.Count >= 8).ToArray();
        var selected = qualifying.Length == 1 ? qualifying[0] : null;
        return new ColorComponents(width, height, rawCount, rawSumX, rawSumY, components.ToArray(),
            qualifying.Length, selected?.Count ?? 0, selected?.Centroid ?? new Vector2(-1, -1));
    }

    private static object DescribeMovingComponents(ColorComponents result) => new
    {
        connectivity = 8, minimum_pixels = 8, image_size = new[] { result.Width, result.Height },
        raw_count = result.RawCount, raw_sum_x = result.RawSumX, raw_sum_y = result.RawSumY,
        qualifying_count = result.QualifyingCount,
        components = result.Components.Select(component => new { count = component.Count,
            sum_x = component.SumX, sum_y = component.SumY,
            centroid = new[] { component.Centroid.X, component.Centroid.Y }, bounds = component.Bounds }).ToArray(),
    };

    private const string MovingFiducialShader = """
        shader_type spatial;
        render_mode unshaded, fog_disabled;
        uniform vec4 frame_color : source_color = vec4(1.0);
        uniform int marker_number = 1;
        varying vec2 marker_xy;
        void vertex() {
            marker_xy = VERTEX.xy / vec2(0.55, 0.70) + vec2(0.5);
        }
        void fragment() {
            ALBEDO = frame_color.rgb;
            if (marker_xy.x >= 0.2 && marker_xy.x < 0.8 && marker_xy.y >= 0.2 && marker_xy.y < 0.8) {
                vec2 cell_xy = (marker_xy - vec2(0.2)) / vec2(0.6);
                int column = int(floor(cell_xy.x * 2.0));
                int row = 2 - int(floor(cell_xy.y * 3.0));
                int code = marker_number == 1 ? 25 : (marker_number == 2 ? 35 : 22);
                ALBEDO = vec3(float((code >> (row * 2 + column)) & 1));
            }
        }
        """;

    private sealed record FiducialPixel(int X, int Y, int[] Rgb);
    private sealed record FiducialFrame(FiducialPixel Pixel, bool Member);
    private sealed record FiducialCell(int Row, int Column, FiducialPixel[] Pixels, long[] Sums)
    {
        internal long Total => Sums[0] + Sums[1] + Sums[2];
        internal long Denominator => Pixels.Length * 3L;
    }
    private sealed record FiducialCandidate(int ComponentIndex, FiducialFrame[] Frame, FiducialCell[] Cells,
        int? DecodedMarker, string? Rejection);
    private sealed record FiducialResult(int ExpectedMarker, FiducialCandidate[] Candidates, int IdentifiedCount,
        int? SelectedComponent, int Count, Vector2 Centroid);

    private static object MovingFiducialPolicy() => new
    {
        schema = "moving-optical-code12.v1", frame_fraction = 0.2, columns = 2, rows = 3,
        codes = new[] { new[] { 1, 0, 0, 1, 1, 0 }, new[] { 1, 1, 0, 0, 0, 1 }, new[] { 0, 1, 1, 0, 1, 0 } },
        corner_fractions = new[] { 0.1, 0.9 }, corner_rounding = "nearest pixel center, positive tie; floor(fraction*extent)",
        core_fraction = 0.5, channel_contrast_min = 64, channel_agreement = "exact-six-bit-code",
        achromatic_core_required = false, extreme_quarter = 0.25,
        code_error_correction = false, selection_uses_projection = false,
    };

    private static FiducialResult MeasureMovingFiducials(byte[] bytes, int width, int height, int marker, ColorComponents measured)
    {
        if (width <= 0 || height <= 0 || bytes.Length != checked(width * height * 4) || marker is < 0 or > 2 ||
            measured.Width != width || measured.Height != height)
            throw new ArgumentException("Invalid optical marker image domain.");
        FiducialPixel Read(int x, int y)
        {
            var at = (y * width + x) * 4;
            return new FiducialPixel(x, y, [bytes[at], bytes[at + 1], bytes[at + 2]]);
        }
        var candidates = new List<FiducialCandidate>();
        for (var index = 0; index < measured.Components.Length; index++)
        {
            var component = measured.Components[index];
            if (component.Count < 8) continue;
            var bounds = component.Bounds;
            var x0 = bounds[0]; var y0 = bounds[1]; var x1 = bounds[2]; var y1 = bounds[3];
            var extentX = x1 - x0 + 1; var extentY = y1 - y0 + 1;
            var frame = new List<FiducialFrame>();
            foreach (var cy in new[] { 1, 9 }) foreach (var cx in new[] { 1, 9 })
            {
                var x = x0 + cx * extentX / 10; var y = y0 + cy * extentY / 10;
                frame.Add(new FiducialFrame(Read(x, y), component.Indices.Contains(y * width + x)));
            }
            var cells = new List<FiducialCell>();
            for (var cy = 0; cy < 3; cy++) for (var cx = 0; cx < 2; cx++)
            {
                var pixels = new List<FiducialPixel>();
                var sums = new long[3];
                // Exact normalized pixel-center domains: central half of each cell, in fortieths.
                for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++)
                {
                    var ux = (2 * (x - x0) + 1) * 20; var uy = (2 * (y - y0) + 1) * 20;
                    if (ux < (11 + cx * 12) * extentX || ux >= (17 + cx * 12) * extentX ||
                        uy < (10 + cy * 8) * extentY || uy >= (14 + cy * 8) * extentY) continue;
                    var pixel = Read(x, y);
                    pixels.Add(pixel);
                    for (var channel = 0; channel < 3; channel++) sums[channel] += pixel.Rgb[channel];
                }
                cells.Add(new FiducialCell(cy, cx, pixels.ToArray(), sums));
            }
            var (decoded, rejection) = DecodeMovingFiducial(bounds, width, height, frame, cells);
            candidates.Add(new FiducialCandidate(index, frame.ToArray(), cells.ToArray(), decoded, rejection));
        }
        var identified = candidates.Where(value => value.DecodedMarker.HasValue).ToArray();
        var selected = identified.Length == 1 && identified[0].DecodedMarker == marker + 1 ? identified[0] : null;
        var selectedComponent = selected is null ? null : measured.Components[selected.ComponentIndex];
        return new FiducialResult(marker + 1, candidates.ToArray(), identified.Length, selected?.ComponentIndex,
            selectedComponent?.Count ?? 0, selectedComponent?.Centroid ?? new Vector2(-1, -1));
    }

    private static (int? DecodedMarker, string? Rejection) DecodeMovingFiducial(int[] bounds, int width, int height,
        List<FiducialFrame> frame, List<FiducialCell> cells)
    {
        if (bounds[0] == 0 || bounds[1] == 0 || bounds[2] == width - 1 || bounds[3] == height - 1)
            return (null, "clipped-frame");
        if (frame.Any(value => !value.Member)) return (null, "incomplete-colored-frame");
        if (cells.Any(value => value.Pixels.Length == 0)) return (null, "empty-core");
        var codes = new int[3];
        for (var channel = 0; channel < 3; channel++)
        {
            var low = cells.Aggregate((a, b) => a.Sums[channel] * b.Pixels.Length <= b.Sums[channel] * a.Pixels.Length ? a : b);
            var high = cells.Aggregate((a, b) => a.Sums[channel] * b.Pixels.Length >= b.Sums[channel] * a.Pixels.Length ? a : b);
            var rangeNumerator = high.Sums[channel] * low.Pixels.Length - low.Sums[channel] * high.Pixels.Length;
            var rangeDenominator = (long)high.Pixels.Length * low.Pixels.Length;
            if (rangeNumerator < 64L * rangeDenominator) return (null, "per-channel-low-contrast");
            for (var index = 0; index < cells.Count; index++)
            {
                var value = cells[index];
                var lower = 4 * (value.Sums[channel] * low.Pixels.Length - low.Sums[channel] * value.Pixels.Length) * high.Pixels.Length;
                var upper = 4 * (high.Sums[channel] * value.Pixels.Length - value.Sums[channel] * high.Pixels.Length) * low.Pixels.Length;
                if (lower <= rangeNumerator * value.Pixels.Length) continue;
                if (upper <= rangeNumerator * value.Pixels.Length) codes[channel] |= 1 << index;
                else return (null, "per-channel-intermediate-core");
            }
        }
        if (codes[0] != codes[1] || codes[0] != codes[2]) return (null, "per-channel-code-disagreement");
        return codes[0] switch { 25 => (1, null), 35 => (2, null), 22 => (3, null), _ => (null, "unknown-code") };
    }

    private static object DescribeMovingFiducials(FiducialResult result) => new
    {
        policy = MovingFiducialPolicy(), expected_marker = result.ExpectedMarker,
        identified_count = result.IdentifiedCount, selected_component_index = result.SelectedComponent,
        candidates = result.Candidates.Select(value => new
        {
            component_index = value.ComponentIndex, decoded_marker = value.DecodedMarker, rejection = value.Rejection,
            frame_samples = value.Frame.Select(sample => new { x = sample.Pixel.X, y = sample.Pixel.Y,
                rgb = sample.Pixel.Rgb, member = sample.Member }).ToArray(),
            cells = value.Cells.Select(cell => new { row = cell.Row, column = cell.Column, count = cell.Pixels.Length,
                sums_rgb = cell.Sums, pixels = cell.Pixels.Select(pixel => new { x = pixel.X, y = pixel.Y, rgb = pixel.Rgb }).ToArray() }).ToArray(),
        }).ToArray(),
    };
    private static Transform3D AssignedMirrorPose(Camera3D camera)
    {
        // Match pinned Camera3D::_get_adjusted_camera_transform, preserving native float precision.
        var expected = camera.GlobalTransform.Orthonormalized();
        expected.Origin += expected.Basis.Y * camera.VOffset;
        expected.Origin += expected.Basis.X * camera.HOffset;
        return expected;
    }

    private void RequireAssignedMirrorPose(EnduranceSedanPresentation.Mirror mirror, Transform3D expected, string boundary)
    {
        var actual = mirror.Camera.GetCameraTransform();
        var interpolated = mirror.Camera.IsPhysicsInterpolated();
        var enabled = mirror.Camera.IsPhysicsInterpolatedAndEnabled();
        var valid = !interpolated && !enabled && actual == expected;
        if (!valid) Write(new { kind = "failed-mirror-assigned-pose", frame = Engine.GetProcessFrames(),
            stage = _stage(), mirror = mirror.Name, boundary,
            node = Matrix(mirror.Camera.GlobalTransform), assigned_mirror = Matrix(expected), effective_mirror = Matrix(actual),
            mirror_interpolated = interpolated, mirror_interpolation_enabled = enabled });
        Require(valid, "effective mirror does not match current explicitly assigned camera pose");
    }

    private void BeforeDraw()
    {
        if (_disposed || _complete || !_running()) return;
        try
        {
            var stage = _stage();
            if (_activeStage != stage) { _draws.Clear(); _activeStage = stage; }
            var hidden = stage == "static-ride";
            var active = stage != "lod-inward";
            var main = _parent.GetViewport().GetCamera3D();
            var origin = _streamer.CaptureStreamSnapshot();
            for (var i = 0; i < 3; i++)
            {
                var target = _targets[i];
                target.Visible = active && !hidden;
                var mirror = _presentation.Mirrors[i];
                if (!active || !mirror.PendingUpdate) continue;
                var assignedMirror = AssignedMirrorPose(mirror.Camera);
                RequireAssignedMirrorPose(mirror, assignedMirror, "before-draw");
                // This is declared target motion in the camera's sampled world, never body motion.
                // Its absolute coordinates are retained with the actual origin below at each draw.
                var phase = Engine.GetProcessFrames() / 30.0 * 1.4;
                target.GlobalTransform = new Transform3D(mirror.Camera.GlobalBasis,
                    mirror.Camera.GlobalTransform * new Vector3(Mathf.Sin((float)phase) * 0.6f, 0, -7));
                // FTI uploads visual instances before FramePreDraw, even when these nodes are Off.
                // Submit only this fixture-owned marker and label, never a production instance.
                var label = target.GetChildren().OfType<Label3D>().Single();
                Require(_targets.Contains(target) && target.GetParent() == _fixture && label.GetParent() == target &&
                    !_fixture.IsPhysicsInterpolated() && !target.IsPhysicsInterpolated() && !label.IsPhysicsInterpolated(),
                    "direct submission is not the owned noninterpolated marker/label");
                RenderingServer.InstanceSetTransform(target.GetInstance(), target.GlobalTransform);
                RenderingServer.InstanceSetTransform(label.GetInstance(), label.GlobalTransform);
                var corners = Enumerable.Range(0, 8).Select(index => target.GlobalTransform *
                    new Vector3((index & 1) == 0 ? -0.275f : 0.275f, (index & 2) == 0 ? -0.35f : 0.35f,
                        (index & 4) == 0 ? -0.12f : 0.12f)).ToArray();
                var behind = corners.Select(main.IsPositionBehind).ToArray();
                var pixels = corners.Select((point, index) => behind[index] ? (Vector2?)null : main.UnprojectPosition(point)).ToArray();
                var size = _parent.GetViewport().GetVisibleRect().Size;
                var outside = behind.All(value => value) || behind.All(value => !value) &&
                    (pixels.All(value => value!.Value.X < 0) || pixels.All(value => value!.Value.X > size.X) ||
                     pixels.All(value => value!.Value.Y < 0) || pixels.All(value => value!.Value.Y > size.Y));
                var projection = new { corners = corners.Select(Vec).ToArray(), behind,
                    pixels = pixels.Select(value => value is { } pixel ? new[] { pixel.X, pixel.Y } : null).ToArray(),
                    viewport_size = new[] { size.X, size.Y }, center_behind = main.IsPositionBehind(target.GlobalPosition),
                    center_in_frustum = main.IsPositionInFrustum(target.GlobalPosition) };
                _draws[mirror.Name] = new Draw(stage, Engine.GetProcessFrames(), mirror.RequestedAtFrame, mirror.RequestCount,
                    mirror.UpdateCount, mirror.Camera.GlobalTransform, main.GlobalTransform,
                    mirror.Camera.GetCameraTransform(), main.GetCameraTransform(), assignedMirror,
                    mirror.Camera.IsPhysicsInterpolated(), mirror.Camera.IsPhysicsInterpolatedAndEnabled(),
                    _vehicle.GetGlobalTransformInterpolated(), target.GlobalTransform, label.GlobalTransform,
                    target.GetInstance().Id, label.GetInstance().Id, mirror.Camera.UnprojectPosition(target.GlobalPosition),
                    hidden, outside, projection, origin, _presentation.CaptureSnapshot(), _presentation.CaptureDrivingIllumination(), _vehicle.LastDriveInput);
            }
        }
        catch (Exception error) { _failure = error.ToString(); }
    }

    private void AfterDraw()
    {
        if (_disposed || _complete || !_running()) return;
        try
        {
            var frame = Engine.GetProcessFrames();
            Write(new { kind = "live-draw", stage = _stage(), frame, physics_frame = Engine.GetPhysicsFrames(),
                body = Matrix(_vehicle.GetGlobalTransformInterpolated()), velocity = Vec(_vehicle.LinearVelocity),
                angular_velocity = Vec(_vehicle.AngularVelocity), frozen = _vehicle.Freeze,
                input = _vehicle.LastDriveInput, autopilot = _vehicle.AutopilotEnabled,
                automation_override = _vehicle.AutomationInputOverride is not null,
                camera = Matrix(_parent.GetViewport().GetCamera3D().GlobalTransform),
                camera_name = _parent.GetViewport().GetCamera3D().Name.ToString(),
                local_origin = _streamer.CaptureStreamSnapshot(), actual_lod = _vehicle.VisualRig!.ActiveLod,
                presentation = _presentation.CaptureSnapshot(), illumination = _presentation.CaptureDrivingIllumination() });
            _dashboardRows++;
            for (var i = 0; i < 3; i++)
            {
                var mirror = _presentation.Mirrors[i];
                if (!_draws.TryGetValue(mirror.Name, out var draw) || draw.Frame != frame || draw.Stage != _stage()) continue;
                Require(mirror.LastUpdateFrame == frame && mirror.UpdateCount == draw.Updates + 1 &&
                    mirror.RequestCount == draw.RequestCount && mirror.RequestedAtFrame == draw.Requested,
                    "mirror image does not belong to the held request/completed draw");
                Require(mirror.Camera.GlobalTransform == draw.Mirror && _targets[i].GlobalTransform == draw.Target &&
                    _parent.GetViewport().GetCamera3D().GlobalTransform == draw.Main &&
                    _vehicle.GetGlobalTransformInterpolated() == draw.Body,
                    "camera, body or target moved between held before/after-draw observations");
                Require(mirror.Camera.GetCameraTransform() == draw.EffectiveMirror &&
                    _parent.GetViewport().GetCamera3D().GetCameraTransform() == draw.EffectiveMain,
                    "effective camera moved between held before/after-draw observations");
                RequireAssignedMirrorPose(mirror, AssignedMirrorPose(mirror.Camera), "after-draw");
                var label = _targets[i].GetChildren().OfType<Label3D>().Single();
                Require(_targets[i].GetInstance().Id == draw.TargetRid && label.GetInstance().Id == draw.LabelRid &&
                    label.GlobalTransform == draw.Label, "submitted diagnostic instance identity or label pose changed");
                EnduranceSedanPresentationScenario.VerifyMirrorBinding(_vehicle.VisualRig!, _presentation, mirror, Require);
                using var image = mirror.Viewport.GetTexture().GetImage();
                Require(image is not null && !image.IsEmpty(), "completed mirror has no native image");
                image!.Convert(Image.Format.Rgba8);
                var imageBytes = image.GetData();
                var measured = MeasureMovingTargetComponents(imageBytes, image.GetWidth(), image.GetHeight(), i);
                var identified = MeasureMovingFiducials(imageBytes, image.GetWidth(), image.GetHeight(), i, measured);
                var components = DescribeMovingComponents(measured);
                var optical = DescribeMovingFiducials(identified);
                var pixels = draw.Hidden
                    ? (Count: measured.RawCount, Centroid: measured.RawCount > 0
                        ? new Vector2((float)((double)measured.RawSumX / measured.RawCount), (float)((double)measured.RawSumY / measured.RawCount))
                        : new Vector2(-1, -1))
                    : (Count: identified.Count, Centroid: identified.Centroid);
                if (!draw.Hidden && !identified.SelectedComponent.HasValue)
                {
                    var path = Path.Combine(_directory, "moving-first-fiducial-failure.png");
                    if (image.SavePng(path) != Error.Ok) throw new IOException("Failed component PNG retention failed.");
                    var failure = new { kind = "failed-mirror-fiducial", stage = draw.Stage, mirror = mirror.Name,
                        marker = i + 1, frame, hidden = false, color_components = components, optical_fiducials = optical,
                        guard = "visible moving fiducial missing, ambiguous or wrong",
                        before_draw = new { mirror = Matrix(draw.Mirror), effective_mirror = Matrix(draw.EffectiveMirror),
                            assigned_mirror = Matrix(draw.AssignedMirror), effective_main = Matrix(draw.EffectiveMain),
                            body = Matrix(draw.Body), target = Matrix(draw.Target), label = Matrix(draw.Label),
                            target_instance_rid = draw.TargetRid, label_instance_rid = draw.LabelRid, origin = draw.Origin },
                        after_draw = new { mirror = Matrix(mirror.Camera.GlobalTransform), effective_mirror = Matrix(mirror.Camera.GetCameraTransform()),
                            assigned_mirror = Matrix(AssignedMirrorPose(mirror.Camera)), effective_main = Matrix(_parent.GetViewport().GetCamera3D().GetCameraTransform()),
                            body = Matrix(_vehicle.GetGlobalTransformInterpolated()), target = Matrix(_targets[i].GlobalTransform), label = Matrix(label.GlobalTransform),
                            target_instance_rid = _targets[i].GetInstance().Id, label_instance_rid = label.GetInstance().Id, origin = _streamer.CaptureStreamSnapshot() },
                        target_projection = new[] { draw.Projection.X, draw.Projection.Y }, main_projection = draw.MainProjection,
                        input = draw.Input, presentation = draw.Presentation, illumination = draw.Illumination,
                        png = new { path, sha256 = Hash(path), size = new[] { image.GetWidth(), image.GetHeight() } } };
                    File.WriteAllText(Path.Combine(_directory, "moving-first-fiducial-failure.json"), JsonSerializer.Serialize(failure));
                    Write(failure);
                    Require(false, "visible moving fiducial missing, ambiguous or wrong");
                }
                var key = draw.Stage + "/" + mirror.Name;
                if (draw.Hidden)
                {
                    Require(!_targets.Any(target => target.Visible) && pixels.Count < 8,
                        "hidden numbered target detector reported background pixels");
                    if (mirror.UpdateCount >= 3) _hidden.Add(mirror.Name);
                }
                else
                {
                    Require(draw.Outside, "complete numbered target box is not proven outside the actual main projection");
                    if (pixels.Count >= 8)
                    {
                        if (pixels.Centroid.DistanceTo(draw.Projection) > 5 && !_retainedProjectionFailure)
                        {
                            var failurePath = Path.Combine(_directory, "moving-first-projection-failure.png");
                            if (image.SavePng(failurePath) != Error.Ok) throw new IOException("Failed mirror PNG retention failed.");
                            var failure = new { kind = "failed-mirror-projection", stage = draw.Stage, mirror = mirror.Name, marker = i + 1,
                                frame, completed_frame = mirror.LastUpdateFrame, requested_frame = draw.Requested,
                                request_count = draw.RequestCount, update_count = mirror.UpdateCount,
                                guard = "completed mirror target centroid differs from held projection by more than5px",
                                maximum_projection_error_px = 5, projection_error_px = pixels.Centroid.DistanceTo(draw.Projection),
                                pixels = pixels.Count, centroid = new[] { pixels.Centroid.X, pixels.Centroid.Y }, color_components = components, optical_fiducials = optical,
                                target_projection = new[] { draw.Projection.X, draw.Projection.Y },
                                target_world = Vec(draw.Target.Origin), hidden = draw.Hidden, visible = _targets[i].Visible,
                                main_outside = draw.Outside, main_projection = draw.MainProjection,
                                before_draw = new { frame = draw.Frame, mirror = Matrix(draw.Mirror), main = Matrix(draw.Main),
                                    effective_mirror = Matrix(draw.EffectiveMirror), effective_main = Matrix(draw.EffectiveMain),
                                    assigned_mirror = Matrix(draw.AssignedMirror), mirror_interpolated = draw.MirrorInterpolated, mirror_interpolation_enabled = draw.MirrorInterpolationEnabled,
                                    body = Matrix(draw.Body), target = Matrix(draw.Target), label = Matrix(draw.Label),
                                    target_instance_rid = draw.TargetRid, label_instance_rid = draw.LabelRid, origin = draw.Origin },
                                after_draw = new { frame, mirror = Matrix(mirror.Camera.GlobalTransform),
                                    main = Matrix(_parent.GetViewport().GetCamera3D().GlobalTransform),
                                    effective_mirror = Matrix(mirror.Camera.GetCameraTransform()),
                                    assigned_mirror = Matrix(AssignedMirrorPose(mirror.Camera)),
                                    mirror_interpolated = mirror.Camera.IsPhysicsInterpolated(),
                                    mirror_interpolation_enabled = mirror.Camera.IsPhysicsInterpolatedAndEnabled(),
                                    effective_main = Matrix(_parent.GetViewport().GetCamera3D().GetCameraTransform()),
                                    body = Matrix(_vehicle.GetGlobalTransformInterpolated()), target = Matrix(_targets[i].GlobalTransform),
                                    label = Matrix(label.GlobalTransform), target_instance_rid = _targets[i].GetInstance().Id,
                                    label_instance_rid = label.GetInstance().Id, origin = _streamer.CaptureStreamSnapshot() },
                                label_transforms = _targets[i].GetChildren().OfType<Label3D>().Select(item => Matrix(item.GlobalTransform)).ToArray(),
                                input = draw.Input, presentation = draw.Presentation, illumination = draw.Illumination,
                                feed_rid = mirror.Viewport.GetTexture().GetRid().Id,
                                png = new { path = failurePath, sha256 = Hash(failurePath), size = new[] { image.GetWidth(), image.GetHeight() } } };
                            File.WriteAllText(Path.Combine(_directory, "moving-first-projection-failure.json"), JsonSerializer.Serialize(failure));
                            Write(failure);
                            _retainedProjectionFailure = true;
                        }
                        Require(pixels.Centroid.DistanceTo(draw.Projection) <= 5,
                            "completed mirror target centroid differs from held projection by more than5px");
                        if (!_centroids.TryGetValue(key, out var points)) _centroids[key] = points = [];
                        points.Add(pixels.Centroid);
                        if (draw.Stage == "natural-rebase") _rebaseDraws.Add((mirror.Name, draw.Origin.RebaseCount));
                    }
                }
                var count = _centroids.GetValueOrDefault(key)?.Count ?? 0;
                object? png = null;
                if (draw.Hidden && mirror.UpdateCount == 3 || !draw.Hidden && pixels.Count >= 8 && count is 1 or 20)
                {
                    var path = Path.Combine(_directory, $"moving-{draw.Stage}-{mirror.Name}-{(draw.Hidden ? "hidden" : count.ToString("00"))}.png");
                    if (image.SavePng(path) != Error.Ok) throw new IOException("Completed mirror PNG failed.");
                    png = new { path, sha256 = Hash(path), size = new[] { image.GetWidth(), image.GetHeight() } };
                }
                var surfaces = Descendants(_vehicle.VisualRig!.ResolveAnchor("Mirror_" + mirror.Name)).OfType<MeshInstance3D>().ToArray();
                Write(new { kind = "completed-mirror", stage = draw.Stage, mirror = mirror.Name, marker = i + 1,
                    frame, completed_frame = mirror.LastUpdateFrame, requested_frame = draw.Requested,
                    request_count = draw.RequestCount, update_count = mirror.UpdateCount, hidden = draw.Hidden,
                    before_draw = new { frame = draw.Frame, mirror = Matrix(draw.Mirror), main = Matrix(draw.Main),
                        effective_mirror = Matrix(draw.EffectiveMirror), effective_main = Matrix(draw.EffectiveMain),
                                    assigned_mirror = Matrix(draw.AssignedMirror), mirror_interpolated = draw.MirrorInterpolated, mirror_interpolation_enabled = draw.MirrorInterpolationEnabled,
                        body = Matrix(draw.Body), target = Matrix(draw.Target), label = Matrix(draw.Label),
                                    target_instance_rid = draw.TargetRid, label_instance_rid = draw.LabelRid, origin = draw.Origin },
                    after_draw = new { frame, mirror = Matrix(mirror.Camera.GlobalTransform),
                        effective_mirror = Matrix(mirror.Camera.GetCameraTransform()),
                                    assigned_mirror = Matrix(AssignedMirrorPose(mirror.Camera)),
                                    mirror_interpolated = mirror.Camera.IsPhysicsInterpolated(),
                                    mirror_interpolation_enabled = mirror.Camera.IsPhysicsInterpolatedAndEnabled(),
                        effective_main = Matrix(_parent.GetViewport().GetCamera3D().GetCameraTransform()),
                        main = Matrix(_parent.GetViewport().GetCamera3D().GlobalTransform), body = Matrix(_vehicle.GetGlobalTransformInterpolated()),
                        target = Matrix(_targets[i].GlobalTransform), label = Matrix(label.GlobalTransform),
                        target_instance_rid = _targets[i].GetInstance().Id, label_instance_rid = label.GetInstance().Id,
                        origin = _streamer.CaptureStreamSnapshot() },
                    target_world = Vec(draw.Target.Origin), target_absolute = new[] { draw.Origin.OriginWorldX + draw.Target.Origin.X,
                        draw.Origin.OriginWorldY + draw.Target.Origin.Y, draw.Origin.OriginWorldZ + draw.Target.Origin.Z },
                    target_projection = new[] { draw.Projection.X, draw.Projection.Y }, main_projection = draw.MainProjection,
                    main_outside = draw.Outside, pixels = pixels.Count, centroid = new[] { pixels.Centroid.X, pixels.Centroid.Y }, color_components = components, optical_fiducials = optical,
                    projection_error_px = pixels.Count > 0 ? pixels.Centroid.DistanceTo(draw.Projection) : (float?)null,
                    feed_rid = mirror.Viewport.GetTexture().GetRid().Id, material_rids = surfaces.Select(surface => surface.MaterialOverride!.GetRid().Id).ToArray(),
                    selectors = surfaces.Select(surface => surface.GetInstanceShaderParameter("mirror_index").AsInt32()).ToArray(),
                    shader = ((ShaderMaterial)surfaces[0].MaterialOverride!).Shader!.ResourcePath,
                    input = draw.Input, presentation = draw.Presentation, illumination = draw.Illumination, png });
                _rows++;
            }
        }
        catch (Exception error) { _failure = error.ToString(); }
    }

    internal void ValidateStage(string stage)
    {
        CheckFailure();
        if (stage == "static-ride") Require(_hidden.SetEquals(["Left", "Right", "Rear"]), "all three hidden detector controls missing");
        else if (stage != "lod-inward")
            foreach (var mirror in _presentation.Mirrors)
                Require(_centroids.TryGetValue(stage + "/" + mirror.Name, out var points) && points.Count >= 10 &&
                    points.Max(point => point.X) - points.Min(point => point.X) >= 3,
                    "actual moving target coverage missing in " + stage + "/" + mirror.Name);
        _stages.Add(new { stage, actual_rebases = _streamer.RebaseCount, hidden_controls = _hidden.Order().ToArray(),
            mirror_observations = _presentation.Mirrors.ToDictionary(mirror => mirror.Name,
                mirror => _centroids.GetValueOrDefault(stage + "/" + mirror.Name)?.Count ?? 0) });
    }

    internal void CheckFailure() { if (_failure is not null) throw new InvalidOperationException(_failure); }
    internal bool RebaseReady(int baseline) => _presentation.Mirrors.All(mirror =>
        _rebaseDraws.Contains((mirror.Name, baseline)) && _rebaseDraws.Contains((mirror.Name, _streamer.RebaseCount)));
    internal void Complete() { CheckFailure(); _complete = true; _log.Flush(); }
    internal object Summary() => new { completed = _complete, failure = _failure, mirror_rows = _rows,
        live_dashboard_rows = _dashboardRows, stages = _stages, path = Path.Combine(_directory, "final-live.jsonl"),
        sha256 = Hash(Path.Combine(_directory, "final-live.jsonl")) };
    private void Write(object row) => _log.WriteLine(JsonSerializer.Serialize(row));
    private static float[] Vec(Vector3 value) => [value.X, value.Y, value.Z];
    private static float[][] Matrix(Transform3D value) => [Vec(value.Basis.X), Vec(value.Basis.Y), Vec(value.Basis.Z), Vec(value.Origin)];
    private static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    private static IEnumerable<Node> Descendants(Node node) { foreach (var child in node.GetChildren()) { yield return child; foreach (var item in Descendants(child)) yield return item; } }
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException("Final moving capture: " + message); }
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true; RenderingServer.FramePreDraw -= BeforeDraw; RenderingServer.FramePostDraw -= AfterDraw;
        _log.Dispose();
        File.WriteAllText(Path.Combine(_directory, "final-live-status.json"), JsonSerializer.Serialize(new
        { completed = _complete, failure = _failure, failed_stage = _complete ? null : _stage(), completed_stages = _stages,
            path = Path.Combine(_directory, "final-live.jsonl"), sha256 = Hash(Path.Combine(_directory, "final-live.jsonl")) }));
        if (GodotObject.IsInstanceValid(_fixture)) _fixture.QueueFree();
    }
}
