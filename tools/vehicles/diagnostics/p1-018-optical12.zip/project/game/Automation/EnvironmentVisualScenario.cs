using Cannonball.Game.World;
using Cannonball.Game.World.Environments;
using Godot;

namespace Cannonball.Game.Automation;

public sealed class EnvironmentVisualScenario
{
    private const int ReviewFramesPerStage = 90;
    private static readonly Stage[] Stages =
    [
        new("mountain-dawn", 0.08, EnvironmentRegion.Mountain, LightingPreset.Dawn),
        new("foothill-day", 0.36, EnvironmentRegion.Foothill, LightingPreset.Day),
        new("plains-weather", 0.62, EnvironmentRegion.Plains, LightingPreset.Overcast),
        new("urban-edge-night", 0.88, EnvironmentRegion.UrbanEdge, LightingPreset.Night),
        new("stream-boundary-day", 0.50, EnvironmentRegion.Plains, LightingPreset.Day),
    ];

    private readonly WorldStreamer _streamer;
    private readonly DirectionalLight3D _light;
    private readonly Godot.Environment _environment;
    private readonly bool _review;
    private int _stageIndex;
    private int _stageFrames;
    private bool _stageTargetSet;

    public EnvironmentVisualScenario(
        WorldStreamer streamer,
        DirectionalLight3D light,
        WorldEnvironment environment,
        bool review)
    {
        _streamer = streamer;
        _light = light;
        _environment = environment.Environment ??
            throw new InvalidOperationException(
                "Environment visual scenario requires a world environment.");
        _review = review;
    }

    public bool Complete { get; private set; }
    public int CompletedStageCount { get; private set; }
    public string CurrentStageName => _stageIndex < Stages.Length ? Stages[_stageIndex].Name : "complete";

    public void Advance()
    {
        if (Complete)
        {
            return;
        }
        var stage = Stages[_stageIndex];
        if (!_stageTargetSet)
        {
            _streamer.SetReviewDistance(
                _streamer.TotalRouteLengthMeters * stage.RouteFraction);
            SetLighting(stage.Lighting);
            _stageTargetSet = true;
        }
        if (!_streamer.ReviewTargetReady || !_streamer.IsStreamingSettled ||
            !_streamer.IsEnvironmentStreamingSettled)
        {
            return;
        }
        _stageFrames++;
        if (_stageFrames < (_review ? ReviewFramesPerStage : 3))
        {
            return;
        }

        ValidateStage(stage);
        GD.Print(
            $"CANNONBALL_ENVIRONMENT_STAGE_OK stage={stage.Name} " +
            $"region={stage.Region.ToString().ToLowerInvariant()} " +
            $"lighting={stage.Lighting.ToString().ToLowerInvariant()} " +
            $"index={_stageIndex + 1} of={Stages.Length} frame={Engine.GetProcessFrames()}");
        CompletedStageCount++;
        _stageIndex++;
        _stageFrames = 0;
        _stageTargetSet = false;
        if (_stageIndex < Stages.Length)
        {
            return;
        }

        var snapshot = _streamer.CaptureEnvironmentSnapshot();
        var missingRegions = Enum.GetValues<EnvironmentRegion>()
            .Where(region => !snapshot.RegionsSeen.Contains(region))
            .ToArray();
        if (missingRegions.Length > 0)
        {
            throw new InvalidOperationException(
                $"Environment scenario did not stream regions: {string.Join(",", missingRegions)}.");
        }
        Complete = true;
        GD.Print(
            $"CANNONBALL_ENVIRONMENT_OK profile={snapshot.ProfileId} " +
            $"stages={CompletedStageCount} regions={snapshot.RegionsSeen.Count} " +
            $"observed_chunks={snapshot.ObservedChunkCount} " +
            $"near_instances={snapshot.NearInstanceCount} " +
            $"mid_instances={snapshot.MidInstanceCount} " +
            $"distant_instances={snapshot.DistantInstanceCount} " +
            $"semantic_nodes={snapshot.SemanticNodeCount} " +
            $"terrain_ribbons={snapshot.TerrainRibbonCount} " +
            $"terrain_vertices={snapshot.TerrainVertexCount} " +
            $"terrain_triangles={snapshot.TerrainTriangleCount} " +
            $"max_terrain_seam_m={snapshot.MaximumTerrainSeamMeters:0.0000} " +
            $"max_terrain_seam_float32_ratio={snapshot.MaximumTerrainSeamFloat32Ratio:0.000} " +
            $"seam_magnitude_m={snapshot.MaximumTerrainSeamMagnitudeMeters:0.0} " +
            $"shared_materials={snapshot.SharedMaterialCount} " +
            $"shared_meshes={snapshot.SharedMeshCount} " +
            $"textures={snapshot.TextureSource} " +
            $"conifer={snapshot.ConiferSource} " +
            $"sky={_environment.GetMeta("sky_source", "unknown").AsString()} " +
            $"collision_free={snapshot.CollisionFree} " +
            $"collision_budget={snapshot.CollisionBudget} " +
            $"rebases={_streamer.RebaseCount} " +
            $"max_build_ms={snapshot.MaximumBuildMilliseconds:0.000}");
    }

    private void ValidateStage(Stage stage)
    {
        var snapshot = _streamer.CaptureEnvironmentSnapshot();
        if (!snapshot.CollisionFree || snapshot.CollisionBudget != 0 ||
            snapshot.LoadedChunks.Count == 0 ||
            snapshot.NearInstanceCount == 0 || snapshot.MidInstanceCount == 0 ||
            snapshot.DistantInstanceCount == 0 || snapshot.SemanticNodeCount == 0 ||
            snapshot.TerrainRibbonCount != snapshot.LoadedChunks.Count ||
            snapshot.TerrainVertexCount == 0 || snapshot.TerrainTriangleCount == 0 ||
            !double.IsFinite(snapshot.MaximumTerrainSeamMeters) ||
            !double.IsFinite(snapshot.MaximumTerrainSeamFloat32Ratio) ||
            snapshot.MaximumTerrainSeamFloat32Ratio > 1.0 ||
            snapshot.SharedMaterialCount < 8 || snapshot.SharedMeshCount < 6 ||
            snapshot.LoadedChunks.All(chunk => chunk.Region != stage.Region))
        {
            throw new InvalidOperationException(
                $"Environment stage '{stage.Name}' did not satisfy its streaming contract: " +
                $"loaded={snapshot.LoadedChunks.Count}, region={stage.Region}, " +
                $"near={snapshot.NearInstanceCount}, mid={snapshot.MidInstanceCount}, " +
                $"distant={snapshot.DistantInstanceCount}, semantic={snapshot.SemanticNodeCount}, " +
                $"terrain_ribbons={snapshot.TerrainRibbonCount}, " +
                $"terrain_triangles={snapshot.TerrainTriangleCount}, " +
                $"max_terrain_seam_m={snapshot.MaximumTerrainSeamMeters:0.0000}, " +
                $"max_terrain_seam_float32_ratio={snapshot.MaximumTerrainSeamFloat32Ratio:0.000}, " +
                $"seam_magnitude_m={snapshot.MaximumTerrainSeamMagnitudeMeters:0.0}, " +
                $"collision_free={snapshot.CollisionFree}.");
        }
        if (!SkyLighting.Matches(_light, _environment, stage.Lighting))
        {
            throw new InvalidOperationException(
                $"Environment stage '{stage.Name}' lighting contract drifted.");
        }
    }

    private void SetLighting(LightingPreset lighting) =>
        SkyLighting.Apply(_light, _environment, lighting);

    private sealed record Stage(
        string Name,
        double RouteFraction,
        EnvironmentRegion Region,
        LightingPreset Lighting);
}
