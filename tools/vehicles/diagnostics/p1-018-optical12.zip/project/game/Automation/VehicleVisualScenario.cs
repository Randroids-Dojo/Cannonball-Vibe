using Cannonball.Game.Vehicle;
using Godot;

namespace Cannonball.Game.Automation;

public sealed class VehicleVisualScenario
{
    private const int ReviewFramesPerStage = 60;
    private static readonly string[] StageNames =
    [
        "daylight-chase",
        "night-cockpit",
        "braking-pitch",
        "steering-lock",
        "full-suspension-travel",
        "lod-transitions",
        "damage-zones",
        "graybox-equivalence",
        "walk-around",
        "daylight-cockpit",
    ];

    private readonly CannonballVehicle _vehicle;
    private readonly CannonballVehicle _graybox;
    private readonly DirectionalLight3D _light;
    private readonly Godot.Environment _environment;
    private readonly SpringArm3D _chaseArm;
    private readonly Camera3D _chaseCamera;
    private readonly Camera3D _cockpitCamera;
    private readonly bool _review;
    private readonly HashSet<string> _completedStages = new(StringComparer.Ordinal);
    private int _stageIndex;
    private int _stageFrames;
    private int _rollingGeometryChecks;
    private int _steeringGeometryChecks;
    private WheelGeometry[]? _wheelGeometry;

    public VehicleVisualScenario(
        Node parent,
        CannonballVehicle vehicle,
        Vector3 roadPoint,
        Vector3 roadForward,
        DirectionalLight3D light,
        WorldEnvironment environment,
        bool review)
    {
        _vehicle = vehicle;
        _light = light;
        _environment = environment.Environment ??
            throw new InvalidOperationException("Vehicle visual scenario requires an environment.");
        _review = review;
        _vehicle.PlaceForReview(roadPoint, roadForward);
        _vehicle.AutopilotEnabled = false;
        _chaseArm = _vehicle.ChaseCameraRig.Arm;
        _chaseArm.SpringLength = 5.4f;
        _chaseArm.Position = new Vector3(0, 1.15f, 1.25f);
        _chaseCamera = _vehicle.ChaseCameraRig.Camera;
        _cockpitCamera = _vehicle.CockpitCameraRig.Camera;
        _graybox = new CannonballVehicle
        {
            Name = "GrayboxEquivalenceVehicle",
            ForceGrayboxVisual = true,
            Freeze = true,
        };
        parent.AddChild(_graybox);
        var right = roadForward.Cross(Vector3.Up).Normalized();
        _graybox.PlaceForReview(roadPoint + right * 3.2f, roadForward);
        _graybox.Visible = false;
        _vehicle.SetCameraMode(cockpit: false);
        _chaseArm.SpringLength = 5.4f;
        _chaseArm.Position = new Vector3(0, 1.15f, 1.25f);
        _chaseArm.RotationDegrees = new Vector3(-8, 0, 0);
    }

    public bool Complete { get; private set; }

    public void Advance()
    {
        if (Complete)
        {
            return;
        }
        var rig = _vehicle.VisualRig ??
            throw new InvalidOperationException("Vehicle visual profile requires the Hero GT rig.");
        var rollingWitnesses = _stageIndex == 0 ? CaptureRollingWitnesses(rig) : [];
        ConfigureStage(rig, _stageIndex, _stageFrames);
        foreach (var witness in rollingWitnesses)
        {
            var tireAfter = _vehicle.ToLocal(witness.Geometry.Tire.ToGlobal(witness.TireVertex));
            var rimAfter = _vehicle.ToLocal(witness.Geometry.Rim.ToGlobal(witness.RimVertex));
            // Forward travel is local -Z: the bottom tread moves +Z relative
            // to the body while the top of the rim moves -Z. These are actual
            // imported vertices, independent of the configured rolling sign.
            if (tireAfter.Z <= witness.TireBefore.Z + 0.001f || rimAfter.Z >= witness.RimBefore.Z - 0.001f)
                throw new InvalidOperationException("Hero tire-bottom/rim-top motion opposes forward rolling.");
            _rollingGeometryChecks++;
        }
        _stageFrames++;
        var framesNeeded = _review ? ReviewFramesPerStage : 3;
        if (_stageFrames < framesNeeded)
        {
            return;
        }
        ValidateStage(rig, _stageIndex);
        var stage = StageNames[_stageIndex];
        _completedStages.Add(stage);
        GD.Print(
            $"CANNONBALL_VEHICLE_VISUAL_STAGE_OK stage={stage} " +
            $"index={_stageIndex + 1} of={StageNames.Length}");
        _stageIndex++;
        _stageFrames = 0;
        if (_stageIndex < StageNames.Length)
        {
            return;
        }
        if (_completedStages.Count != StageNames.Length)
        {
            throw new InvalidOperationException("Vehicle visual profile missed a declared stage.");
        }
        Complete = true;
        var snapshot = rig.CaptureSnapshot();
        GD.Print(
            "CANNONBALL_VEHICLE_VISUAL_OK " +
            $"semantic_nodes={snapshot.SemanticNodeCount} lods=3 damage_zones={snapshot.DamageZoneCount} " +
            $"wheelbase_m=2.84 track_m=1.64 graybox_equivalent={_graybox.UsesGrayboxVisual} " +
            $"rolling_geometry_checks={_rollingGeometryChecks} steering_geometry_checks={_steeringGeometryChecks}");
    }

    private void ConfigureStage(VehicleVisualRig rig, int stage, int frame)
    {
        var phase = _review ? frame / (float)Math.Max(ReviewFramesPerStage - 1, 1) : 1.0f;
        _graybox.Visible = false;
        rig.SetDamageHighlight(false);
        rig.SetLod(0);
        _vehicle.SetCameraMode(cockpit: false);
        _vehicle.Rotation = Vector3.Zero;
        // The chase rig rewrites the arm's rotation and spring length every
        // frame; the walk-around stage takes the arm over, so the rig's
        // processing is off for that stage and back on for every other one.
        _vehicle.ChaseCameraRig.SetProcess(true);
        _chaseCamera.Fov = _vehicle.ChaseCameraRig.BaseFieldOfViewDegrees;
        _cockpitCamera.RotationDegrees = Vector3.Zero;
        _chaseArm.SpringLength = 5.4f;
        _chaseArm.Position = new Vector3(0, 1.15f, 1.25f);
        _chaseArm.RotationDegrees = new Vector3(-8, 0, 0);
        switch (stage)
        {
            case 0:
                SetLighting(daylight: true);
                rig.ApplyPhysicsState(0, 24, 1.0f / 60.0f, [0.18f, 0.18f, 0.18f, 0.18f]);
                break;
            case 1:
                SetLighting(daylight: false);
                _vehicle.SetCameraMode(cockpit: true);
                rig.ApplyPhysicsState(0, 42, 1.0f / 60.0f, [0.16f, 0.16f, 0.16f, 0.16f]);
                break;
            case 2:
                SetLighting(daylight: true);
                _vehicle.Rotation = new Vector3(-Mathf.DegToRad(2.2f) * phase, 0, 0);
                rig.ApplyPhysicsState(0, Mathf.Lerp(52, 8, phase), 1.0f / 60.0f, [0.34f, 0.34f, 0.12f, 0.12f]);
                break;
            case 3:
                rig.ApplyPhysicsState(Mathf.Lerp(-0.38f, 0.38f, phase), 18, 1.0f / 60.0f, [0.2f, 0.2f, 0.18f, 0.18f]);
                break;
            case 4:
                var travel = Mathf.Lerp(0, 0.62f, phase);
                rig.ApplyPhysicsState(0, 0, 1.0f / 60.0f, [travel, 0.62f - travel, travel, 0.62f - travel]);
                break;
            case 5:
                rig.SetLod(Math.Min((int)(phase * 3), 2));
                rig.ApplyPhysicsState(0, 30, 1.0f / 60.0f, [0.18f, 0.18f, 0.18f, 0.18f]);
                break;
            case 6:
                rig.SetDamageHighlight(true);
                rig.ApplyPhysicsState(0, 0, 1.0f / 60.0f, [0.22f, 0.22f, 0.22f, 0.22f]);
                break;
            case 7:
                _graybox.Visible = true;
                rig.ApplyPhysicsState(0, 0, 1.0f / 60.0f, [0.18f, 0.18f, 0.18f, 0.18f]);
                break;
            case 8:
                // A full orbit at static ride height, low and close, so the
                // review sheet shows the car from every side rather than only
                // its tail; the second half runs at night with the lamps lit.
                SetLighting(daylight: phase < 0.5f);
                _vehicle.ChaseCameraRig.SetProcess(false);
                // A long lens from further back keeps the proportions honest;
                // the chase camera's 76-degree field of view inflates whatever
                // is nearest and made the body read taller than it is.
                _chaseCamera.Fov = 38.0f;
                _chaseArm.SpringLength = 10.5f;
                _chaseArm.Position = new Vector3(0, 0.95f, 0.1f);
                _chaseArm.RotationDegrees = new Vector3(-4.5f, phase * 360.0f, 0);
                rig.ApplyPhysicsState(0, 0, 1.0f / 60.0f, [0.085f, 0.085f, 0.085f, 0.085f]);
                break;
            case 9:
                // The night cockpit stage proves the anchor; this one shows the
                // interior under daylight so the dash, wheel and seats can be
                // reviewed, with a slow look to the right across the cabin.
                SetLighting(daylight: true);
                _vehicle.SetCameraMode(cockpit: true);
                _cockpitCamera.RotationDegrees = new Vector3(-6.0f, -26.0f * phase, 0);
                rig.ApplyPhysicsState(0, 0, 1.0f / 60.0f, [0.085f, 0.085f, 0.085f, 0.085f]);
                break;
        }
    }

    private void ValidateStage(VehicleVisualRig rig, int stage)
    {
        var snapshot = rig.CaptureSnapshot();
        if (!snapshot.ContractResolved || snapshot.SemanticNodeCount != VehicleVisualRig.RequiredSemanticNodes.Length)
        {
            throw new InvalidOperationException("Hero GT semantic rig did not resolve completely.");
        }
        if (stage == 3)
        {
            foreach (var geometry in WheelGeometryFor(rig))
            {
                var axis = (geometry.Tire.ToGlobal(geometry.RightBandCenter) -
                    geometry.Tire.ToGlobal(geometry.LeftBandCenter)).Normalized();
                var up = _vehicle.GlobalBasis.Y.Normalized();
                var forward = -_vehicle.GlobalBasis.Z.Normalized();
                var heading = up.Cross(axis).Normalized();
                if (heading.Dot(forward) < 0) heading = -heading;
                var expected = geometry.Front ? forward.Rotated(up, -0.38f) : forward;
                if (heading.AngleTo(expected) > Mathf.DegToRad(0.01f))
                    throw new InvalidOperationException("Hero tire plane disagrees with the physical steering heading.");
                _steeringGeometryChecks++;
            }
        }
        switch (stage)
        {
            case 0 when rig.HeadlightsOn:
                throw new InvalidOperationException("Daylight review left the vehicle lamps lit.");
            case 1 when !_cockpitCamera.Current || _chaseCamera.Current:
                throw new InvalidOperationException("Cockpit review did not use the declared cockpit camera anchor.");
            case 1 when !rig.HeadlightsOn:
                throw new InvalidOperationException("Night review did not light the vehicle lamps.");
            case 3 when Math.Abs(snapshot.SteeringRadians - 0.38f) > 0.001f:
                throw new InvalidOperationException("Steering-lock visual did not reach the declared angle.");
            case 4 when snapshot.MaximumSuspensionTravelMeters < 0.619f:
                throw new InvalidOperationException("Visual suspension did not exercise its full measured travel.");
            case 5 when snapshot.ActiveLod != 2:
                throw new InvalidOperationException("Visual LOD profile did not reach LOD2.");
            case 6 when snapshot.DamageZoneCount != 5:
                throw new InvalidOperationException("Damage-zone visual contract drifted.");
            case 7 when !_graybox.UsesGrayboxVisual || _graybox.VisualRig is not null ||
                _graybox.GetNodeOrNull<CollisionShape3D>("ChassisCollision") is null:
                throw new InvalidOperationException("Graybox fallback changed the authoritative collision contract.");
            case 8 when !_chaseCamera.Current || snapshot.ActiveLod != 0 || _graybox.Visible:
                throw new InvalidOperationException("Walk-around review did not orbit the LOD0 hero vehicle with the chase camera.");
            case 9 when !_cockpitCamera.Current || _chaseCamera.Current:
                throw new InvalidOperationException("Daylight cockpit review did not use the cockpit camera.");
        }
    }

    private void SetLighting(bool daylight) =>
        World.Environments.SkyLighting.Apply(
            _light,
            _environment,
            daylight ? World.Environments.LightingPreset.Day : World.Environments.LightingPreset.Night);

    private readonly record struct WheelGeometry(MeshInstance3D Tire, Vector3[] TireVertices,
        MeshInstance3D Rim, Vector3[] RimVertices, Vector3 LeftBandCenter, Vector3 RightBandCenter, bool Front);
    private readonly record struct RollingWitness(WheelGeometry Geometry, Vector3 TireVertex,
        Vector3 RimVertex, Vector3 TireBefore, Vector3 RimBefore);

    private RollingWitness[] CaptureRollingWitnesses(VehicleVisualRig rig) => WheelGeometryFor(rig).Select(geometry =>
    {
        var bodyInverse = _vehicle.GlobalTransform.AffineInverse();
        var tireTransform = bodyInverse * geometry.Tire.GlobalTransform;
        var rimTransform = bodyInverse * geometry.Rim.GlobalTransform;
        var tirePoint = geometry.TireVertices.MinBy(point => (tireTransform * point).Y);
        var rimPoint = geometry.RimVertices.MaxBy(point => (rimTransform * point).Y);
        return new RollingWitness(geometry, tirePoint, rimPoint, tireTransform * tirePoint, rimTransform * rimPoint);
    }).ToArray();

    private WheelGeometry[] WheelGeometryFor(VehicleVisualRig rig) => _wheelGeometry ??= new[] { "FL", "FR", "RL", "RR" }.Select(suffix =>
    {
        var root = rig.ResolveAnchor("Wheel_" + suffix);
        var tire = root.GetNode<MeshInstance3D>("LOD0_Tyre_" + suffix);
        var rim = root.GetNode<MeshInstance3D>("LOD0_Rim_" + suffix + "_Spokes");
        var vertices = Vertices(tire);
        var minX = vertices.Min(point => point.X);
        var maxX = vertices.Max(point => point.X);
        var left = vertices.Where(point => point.X < minX + 0.005f).ToArray();
        var right = vertices.Where(point => point.X > maxX - 0.005f).ToArray();
        return new WheelGeometry(tire, vertices, rim, Vertices(rim),
            left.Aggregate(Vector3.Zero, (sum, point) => sum + point) / left.Length,
            right.Aggregate(Vector3.Zero, (sum, point) => sum + point) / right.Length, suffix.StartsWith('F'));
    }).ToArray();

    private static Vector3[] Vertices(MeshInstance3D node)
    {
        var result = new List<Vector3>();
        for (var surface = 0; surface < node.Mesh.GetSurfaceCount(); surface++)
        {
            using var arrays = node.Mesh.SurfaceGetArrays(surface);
            result.AddRange(arrays[(int)Mesh.ArrayType.Vertex].AsVector3Array());
        }
        return result.ToArray();
    }
}
