using Godot;

namespace Cannonball.Game.Vehicle;

public sealed partial class VehicleVisualRig : Node3D
{
    [Export] public VehicleRigSetup? RigSetup { get; set; }
    [Export] public EnduranceSedanPresentationSetup? PresentationSetup { get; set; }
    public EnduranceSedanPresentation? Presentation { get; private set; }
    private readonly Dictionary<string, Node3D> _resolvedAnchors = new(StringComparer.Ordinal);
    public Node3D ResolveAnchor(string name)
    {
        if (_resolvedAnchors.TryGetValue(name, out var cached) && GodotObject.IsInstanceValid(cached)) return cached;
        var node = FindDescendant(this, name) as Node3D ??
            throw new InvalidOperationException($"Vehicle '{RigSetup?.AssetId}' is missing semantic anchor {name}.");
        _resolvedAnchors[name] = node;
        return node;
    }
    public const uint CockpitExteriorRenderLayer = 1u << 19;
    public const string CarPaintShaderPath = "res://assets/vehicles/hero-gt/shaders/car_paint.gdshader";

    public static readonly string[] RequiredSemanticNodes =
    [
        "AssetRoot", "Chassis", "Visual_LOD0", "Visual_LOD1", "Visual_LOD2",
        "CollisionProxy", "Wheel_FL", "Wheel_FR", "Wheel_RL", "Wheel_RR",
        "Suspension_FL", "Suspension_FR", "Suspension_RL", "Suspension_RR",
        "Contact_FL", "Contact_FR", "Contact_RL", "Contact_RR",
        "Camera_ChaseTarget", "Camera_Cockpit", "Light_Head_FL", "Light_Head_FR",
        "Light_Tail_RL", "Light_Tail_RR", "Exhaust_L", "Exhaust_R",
        "Driver_Reference", "MaterialGroup_Body", "MaterialGroup_Glass",
        "MaterialGroup_Wheels", "MaterialGroup_Interior", "MaterialGroup_Lights",
        "Damage_Front", "Damage_Rear", "Damage_Left", "Damage_Right", "Damage_Roof",
    ];

    /// <summary>
    /// Meshes the cockpit camera must not draw: the glass it sits behind and
    /// the roof it sits under. The interior stays visible; that is the point
    /// of a cockpit view.
    /// </summary>
    public static readonly string[] CockpitExcludedMeshes = ["LOD0_Cabin", "LOD0_RoofSpine"];

    /// <summary>
    /// Texture bindings the packer detached from the generated scene. The
    /// sourced maps live in a rights-gated folder the release presets
    /// exclude, and a scene that names a missing resource fails to load, so
    /// the scene ships untextured and the wrapper binds whatever exists.
    /// </summary>
    public const string SourcedTexturesPath = "res://assets/vehicles/hero-gt/hero-gt.generated.textures.json";

    private static readonly string[] WheelSuffixes = ["FL", "FR", "RL", "RR"];
    private readonly Node3D[] _wheelPivots = new Node3D[4];
    private readonly Node3D[] _suspensionAnchors = new Node3D[4];
    private readonly Vector3[] _suspensionRestPositions = new Vector3[4];
    private readonly Basis[] _suspensionRestBases = new Basis[4];
    private readonly Basis[] _wheelRestBases = new Basis[4];
    private readonly List<GeometryInstance3D>[] _distributedLods = [[], [], []];
    private readonly List<MeshInstance3D> _damageIndicators = [];
    private readonly Godot.Collections.Dictionary _automationState = new();
    private readonly List<Light3D> _lamps = [];
    private readonly Dictionary<string, float> _lampEmission = new(StringComparer.Ordinal);

    /// <summary>
    /// Lamp lens materials whose glow follows the lamps. The LED strips stay
    /// lit by day as running lights, so they are not listed.
    /// </summary>
    private static readonly string[] LampEmissiveMaterials = ["Material_Taillight", "Material_Headlight"];
    private const float DousedEmissionScale = 0.12f;
    private Action<World.Environments.LightingPreset>? _presetHandler;

    /// <summary>Whether the head and tail lamps are lit.</summary>
    private bool _headlightsOn;
    public bool HeadlightsOn => Presentation?.HeadlightsOn ?? _headlightsOn;

    /// <summary>Sidecar texture slots bound at load, and slots whose file was absent.</summary>
    public int SourcedTexturesBound { get; private set; }

    public int SourcedTexturesMissing { get; private set; }
    private Node3D _lod0 = null!;
    private Node3D _lod1 = null!;
    private Node3D _lod2 = null!;
    private float _wheelRotationRadians;

    public bool ContractResolved { get; private set; }
    public int ResolvedSemanticNodeCount { get; private set; }
    public int ActiveLod { get; private set; }
    public float SteeringRadians { get; private set; }
    public float WheelRotationRadians => _wheelRotationRadians;
    public float MaximumSuspensionTravelMeters { get; private set; }
    public Node3D ChaseCameraTarget { get; private set; } = null!;
    public Node3D CockpitCameraAnchor { get; private set; } = null!;

    public override void _Ready()
    {
        RigSetup ??= VehicleRigSetup.Load("hero-gt");
        RigSetup.Validate();
        if (RigSetup.AssetId == "hero-gt")
        {
            Name = "HeroGtVisualRig";
        }
        var resolved = RequiredSemanticNodes.ToDictionary(
            name => name,
            name => FindDescendant(this, name) ??
                throw new InvalidOperationException($"Vehicle '{RigSetup.AssetId}' wrapper is missing semantic node {name}."),
            StringComparer.Ordinal);
        ResolvedSemanticNodeCount = resolved.Count;
        ContractResolved = true;
        SetMeta("vehicle_visual_rig_ready", true);
        SetMeta("automation_state", _automationState);
        _lod0 = (Node3D)resolved["Visual_LOD0"];
        _lod1 = (Node3D)resolved["Visual_LOD1"];
        _lod2 = (Node3D)resolved["Visual_LOD2"];
        ChaseCameraTarget = (Node3D)resolved["Camera_ChaseTarget"];
        CockpitCameraAnchor = (Node3D)resolved["Camera_Cockpit"];
        if (RigSetup.DistributedLodGeometry)
        {
            foreach (var geometry in Descendants(this).OfType<GeometryInstance3D>())
            {
                for (var lod = 0; lod < _distributedLods.Length; lod++)
                {
                    if (geometry.Name.ToString().StartsWith($"LOD{lod}_", StringComparison.Ordinal))
                    {
                        _distributedLods[lod].Add(geometry);
                    }
                }
            }
        }
        for (var index = 0; index < WheelSuffixes.Length; index++)
        {
            var suffix = WheelSuffixes[index];
            _wheelPivots[index] = (Node3D)resolved[$"Wheel_{suffix}"];
            _suspensionAnchors[index] = (Node3D)resolved[$"Suspension_{suffix}"];
            _suspensionRestPositions[index] = _suspensionAnchors[index].Position;
            _suspensionRestBases[index] = _suspensionAnchors[index].Basis;
            _wheelRestBases[index] = _wheelPivots[index].Basis;
        }
        BuildDamageIndicators(resolved);
        if (PresentationSetup is null) BuildLamps(resolved);
        BindSourcedTextures();
        PolishImportedMaterials();
        if (PresentationSetup is not null && GetParent() is CannonballVehicle vehicle &&
            !OS.GetCmdlineUserArgs().Contains("--sedan-blockout", StringComparer.Ordinal))
        {
            Presentation = new EnduranceSedanPresentation();
            Presentation.Configure(this, vehicle, PresentationSetup);
            AddChild(Presentation);
        }
        // The collision proxy is a contract node for collision policy, not a
        // visual; the third-generation body tucks under at the sills and
        // tapers at the tail, so the box would show if it were drawn.
        if (resolved["CollisionProxy"] is GeometryInstance3D collisionProxy)
        {
            collisionProxy.Visible = false;
        }
        SetVisualVisibility(resolved["CollisionProxy"], false);
        SetLod(0);
        SetDamageHighlight(false);
        // The run starts at night; the lamps follow whatever preset the world
        // applies from here on.
        SetHeadlights(World.Environments.SkyLighting.CurrentPreset is { } preset
            ? World.Environments.SkyLighting.LampsLit(preset)
            : true);
        _presetHandler = changed => SetHeadlights(World.Environments.SkyLighting.LampsLit(changed));
        World.Environments.SkyLighting.PresetChanged += _presetHandler;
        _automationState["cockpit_excluded_mesh_count"] = 0;
        _automationState["cockpit_exterior_layer"] = (long)CockpitExteriorRenderLayer;
    }

    public void ApplyPhysicsState(
        float steeringRadians,
        float longitudinalSpeedMetersPerSecond,
        float deltaSeconds,
        IReadOnlyList<float> suspensionCompressionMeters)
    {
        if (!ContractResolved || suspensionCompressionMeters.Count != 4)
        {
            return;
        }
        SteeringRadians = steeringRadians;
        _wheelRotationRadians = Mathf.Wrap(
            _wheelRotationRadians + longitudinalSpeedMetersPerSecond / RigSetup!.TireRadiusMeters * deltaSeconds * RigSetup.WheelRollingSign,
            -Mathf.Pi,
            Mathf.Pi);
        MaximumSuspensionTravelMeters = 0;
        for (var index = 0; index < _wheelPivots.Length; index++)
        {
            var compression = Mathf.Clamp(suspensionCompressionMeters[index], 0, RigSetup!.MaximumVisualCompressionMeters);
            MaximumSuspensionTravelMeters = Math.Max(MaximumSuspensionTravelMeters, compression);
            _suspensionAnchors[index].Position =
                _suspensionRestPositions[index] + Vector3.Up *
                    (compression - (RigSetup.AuthoredAtStaticRide ? RigSetup.StaticCompressionMeters : 0));
            var steering = index < 2 ? steeringRadians : 0;
            if (RigSetup.SteerSuspensionParent)
            {
                _suspensionAnchors[index].Basis = _suspensionRestBases[index] * new Basis(Vector3.Up, -steering);
                _wheelPivots[index].Basis = _wheelRestBases[index] * new Basis(Vector3.Right, _wheelRotationRadians);
            }
            else
            {
                _wheelPivots[index].Basis =
                    _wheelRestBases[index] * new Basis(Vector3.Up, -steering) * new Basis(Vector3.Right, _wheelRotationRadians);
            }
        }
    }

    public void SetLod(int lod)
    {
        ActiveLod = Math.Clamp(lod, 0, 2);
        if (RigSetup?.DistributedLodGeometry == true)
        {
            for (var level = 0; level < _distributedLods.Length; level++)
            {
                foreach (var geometry in _distributedLods[level])
                {
                    geometry.Visible = level == ActiveLod;
                }
            }
            return;
        }
        SetVisualVisibility(_lod0, ActiveLod == 0);
        SetVisualVisibility(_lod1, ActiveLod == 1);
        SetVisualVisibility(_lod2, ActiveLod == 2);
        // Rolling wheels and brakes hang under the pivots and anchors, outside
        // the LOD groups; they show with LOD0 only.
        foreach (var suffix in WheelSuffixes)
        {
            foreach (var root in new[] { FindDescendant(this, $"Wheel_{suffix}"), FindDescendant(this, $"Suspension_{suffix}") })
            {
                if (root is null)
                {
                    continue;
                }
                foreach (var child in Descendants(root).OfType<GeometryInstance3D>())
                {
                    child.Visible = ActiveLod == 0;
                }
            }
        }
    }

    public override void _ExitTree()
    {
        if (_presetHandler is not null)
        {
            World.Environments.SkyLighting.PresetChanged -= _presetHandler;
            _presetHandler = null;
        }
    }

    /// <summary>Lights or douses the head and tail lamps.</summary>
    public void SetHeadlights(bool on)
    {
        _headlightsOn = on;
        Presentation?.SetEnvironmentHeadlights(on);
        foreach (var lamp in _lamps)
        {
            lamp.Visible = on;
        }
        // The sedan presenter owns its lamp materials. The legacy pass mutates
        // shared imported sources and can douse another sedan's base material.
        if (Presentation is null)
        {
            ApplyLampEmission(on);
        }
        _automationState["headlights_on"] = on;
        _automationState["lamp_count"] = _lamps.Count;
        _automationState["beam_shadows"] = _lamps.OfType<SpotLight3D>().Any(beam => beam.ShadowEnabled);
    }

    /// <summary>
    /// Scales the tail bar and projector lens glow with the lamps. The
    /// source emission strength is remembered per material name the first
    /// time it is seen, so a doused lamp is a fraction of the source rather
    /// than a constant that could drift from the asset. Wrappers are released
    /// per surface, as in the polish pass.
    /// </summary>
    private void ApplyLampEmission(bool on)
    {
        foreach (var meshInstance in Descendants(this).OfType<MeshInstance3D>())
        {
            using var mesh = meshInstance.Mesh;
            if (mesh is null)
            {
                continue;
            }
            for (var surface = 0; surface < mesh.GetSurfaceCount(); surface++)
            {
                using var surfaceMaterial = mesh.SurfaceGetMaterial(surface);
                if (surfaceMaterial is not StandardMaterial3D material ||
                    Array.IndexOf(LampEmissiveMaterials, material.ResourceName) < 0)
                {
                    continue;
                }
                if (!_lampEmission.TryGetValue(material.ResourceName, out var source))
                {
                    source = material.EmissionEnergyMultiplier;
                    _lampEmission[material.ResourceName] = source;
                }
                material.EmissionEnergyMultiplier = on ? source : source * DousedEmissionScale;
            }
        }
    }

    /// <summary>
    /// Working lamps under the contract anchors: a low beam per headlamp with
    /// a warm colour and a shadow, and a small red glow per tail lamp. The
    /// anchors carry the identity rotation the exporter enforces, so the
    /// beams point down the vehicle forward axis with a slight dip.
    /// </summary>
    private void BuildLamps(IReadOnlyDictionary<string, Node> resolved)
    {
        // The semantic suite runs the production rig on software renderers
        // behind the graybox-assets flag; two shadowed beams there cost the
        // macOS camera test its rear-view settle window, and nothing in that
        // suite looks at a beam shadow.
        var shadowedBeams = !World.Environments.SkyLighting.GrayboxRequested();
        foreach (var name in new[] { "Light_Head_FL", "Light_Head_FR" })
        {
            var anchor = (Node3D)resolved[name];
            var beam = new SpotLight3D
            {
                Name = $"{name}_Beam",
                LightColor = new Color(1.0f, 0.93f, 0.80f),
                LightEnergy = 30.0f,
                LightSpecular = 0.35f,
                SpotRange = 120.0f,
                SpotAngle = 38.0f,
                SpotAngleAttenuation = 0.7f,
                SpotAttenuation = 0.9f,
                ShadowEnabled = shadowedBeams,
                ShadowBias = 0.06f,
                ShadowNormalBias = 1.5f,
                RotationDegrees = new Vector3(-2.2f, 0, 0),
            };
            anchor.AddChild(beam);
            _lamps.Add(beam);
            var spill = new OmniLight3D
            {
                Name = $"{name}_Spill",
                LightColor = new Color(1.0f, 0.93f, 0.80f),
                LightEnergy = 1.2f,
                OmniRange = 3.0f,
                ShadowEnabled = false,
            };
            anchor.AddChild(spill);
            _lamps.Add(spill);
        }
        foreach (var name in new[] { "Light_Tail_RL", "Light_Tail_RR" })
        {
            var anchor = (Node3D)resolved[name];
            var glow = new OmniLight3D
            {
                Name = $"{name}_Glow",
                LightColor = new Color(1.0f, 0.07f, 0.03f),
                LightEnergy = 0.8f,
                OmniRange = 2.0f,
                ShadowEnabled = false,
            };
            anchor.AddChild(glow);
            _lamps.Add(glow);
        }
    }

    public void SetDamageHighlight(bool visible)
    {
        foreach (var indicator in _damageIndicators)
        {
            indicator.Visible = visible;
        }
    }

    public void ConfigureCockpitCamera(Camera3D camera)
    {
        ArgumentNullException.ThrowIfNull(camera);
        var excludedCount = 0;
        var exclusions = RigSetup?.CockpitExcludedMeshes ?? CockpitExcludedMeshes;
        foreach (var name in exclusions)
        {
            if (FindDescendant(this, name) is not GeometryInstance3D geometry)
            {
                throw new InvalidOperationException(
                    $"Vehicle cockpit exclusion mesh '{name}' is missing.");
            }
            geometry.Layers = CockpitExteriorRenderLayer;
            excludedCount++;
        }
        camera.CullMask &= ~CockpitExteriorRenderLayer;
        _automationState["cockpit_excluded_mesh_count"] = excludedCount;
        _automationState["cockpit_excluded_meshes"] = new Godot.Collections.Array<string>(exclusions);
        _automationState["cockpit_camera_cull_mask"] = (long)camera.CullMask;
        _automationState["chase_exterior_geometry_visible"] = true;
    }

    /// <summary>
    /// Material properties the glTF importer cannot carry, applied by the
    /// project-owned wrapper as ADR-0012 directs. The Blender source records
    /// its intent as material custom properties, which arrive as the
    /// material's <c>extras</c> metadata: the paint becomes the flake
    /// clear-coat shader, glass becomes a depth-sorted transparent surface,
    /// carbon keeps its clear coat, and cut metal stays fully metallic. A
    /// re-export cannot erase this because it is keyed by the extras the
    /// export itself writes; materials without extras fall back to their
    /// names so the second-generation asset keeps working.
    /// </summary>
    private void BindSourcedTextures()
    {
        var textureBindingsPath = RigSetup?.TextureBindingsPath ?? SourcedTexturesPath;
        var bound = 0;
        var missing = 0;
        _automationState["sourced_textures_bound"] = 0;
        _automationState["sourced_textures_missing"] = 0;
        if (string.IsNullOrWhiteSpace(textureBindingsPath) || !Godot.FileAccess.FileExists(textureBindingsPath))
        {
            return;
        }
        var parsed = Json.ParseString(Godot.FileAccess.GetFileAsString(textureBindingsPath));
        if (parsed.Obj is not Godot.Collections.Dictionary sidecar ||
            !sidecar.TryGetValue("materials", out var materialsValue) ||
            materialsValue.Obj is not Godot.Collections.Dictionary bindings)
        {
            GD.PushWarning($"Vehicle texture sidecar {textureBindingsPath} is not a schema-1 binding table.");
            return;
        }
        using (sidecar)
        using (bindings)
        {
            var seen = new HashSet<Rid>();
            foreach (var meshInstance in Descendants(this).OfType<MeshInstance3D>())
            {
                using var mesh = meshInstance.Mesh;
                if (mesh is null)
                {
                    continue;
                }
                for (var surface = 0; surface < mesh.GetSurfaceCount(); surface++)
                {
                    using var surfaceMaterial = mesh.SurfaceGetMaterial(surface);
                    if (surfaceMaterial is not StandardMaterial3D material || !seen.Add(material.GetRid()))
                    {
                        continue;
                    }
                    if (!bindings.TryGetValue(material.ResourceName, out var slotsValue) ||
                        slotsValue.Obj is not Godot.Collections.Dictionary slots)
                    {
                        continue;
                    }
                    using (slots)
                    {
                        foreach (var slot in slots.Keys)
                        {
                            var path = slots[slot].AsString();
                            if (!ResourceLoader.Exists(path))
                            {
                                missing++;
                                continue;
                            }
                            using var texture = ResourceLoader.Load<Texture2D>(path);
                            material.Set(slot.AsString(), texture);
                            bound++;
                        }
                    }
                }
            }
        }
        SourcedTexturesBound = bound;
        SourcedTexturesMissing = missing;
        _automationState["sourced_textures_bound"] = bound;
        _automationState["sourced_textures_missing"] = missing;
    }

    private void PolishImportedMaterials()
    {
        var polished = 0;
        var paintShaderPath = RigSetup?.PaintShaderPath ?? CarPaintShaderPath;
        var paintShader = ResourceLoader.Exists(paintShaderPath)
            ? ResourceLoader.Load<Shader>(paintShaderPath)
            : null;
        var paintMaterials = new Dictionary<string, ShaderMaterial>(StringComparer.Ordinal);
        foreach (var meshInstance in Descendants(this).OfType<MeshInstance3D>())
        {
            // Every wrapper taken here is released before the next mesh: the
            // scene owns the native resources, and managed wrappers left to the
            // garbage collector finalize after the native side is gone at
            // shutdown, which the .NET runtime reports as a fatal error.
            using var mesh = meshInstance.Mesh;
            if (mesh is null)
            {
                continue;
            }
            for (var surface = 0; surface < mesh.GetSurfaceCount(); surface++)
            {
                using var surfaceMaterial = mesh.SurfaceGetMaterial(surface);
                if (surfaceMaterial is not StandardMaterial3D material)
                {
                    if (surfaceMaterial?.HasMeta("cannonball_specular_response") == true)
                        throw new InvalidOperationException("Declared specular response requires StandardMaterial3D.");
                    continue;
                }
                var name = material.ResourceName;
                using var extras = material.HasMeta("extras") && material.GetMeta("extras").Obj is Godot.Collections.Dictionary dictionary
                    ? dictionary
                    : new Godot.Collections.Dictionary();
                var family = extras.TryGetValue("cv_shader", out var shaderValue)
                    ? shaderValue.AsString()
                    : FamilyFromName(name);
                ApplyDeclaredScreenSpecular(material, family);
                switch (family)
                {
                    // Explicit source response is authoritative. In particular,
                    // dark polymer trim must not inherit Hero's metallic fallback.
                    case "standard":
                        ApplyDeclaredStandardCoat(material, extras);
                        break;
                    case "car_paint" when paintShader is not null:
                        if (!paintMaterials.TryGetValue(name, out var paint))
                        {
                            paint = BuildCarPaint(paintShader, material, extras);
                            paintMaterials[name] = paint;
                        }
                        meshInstance.SetSurfaceOverrideMaterial(surface, paint);
                        polished++;
                        break;
                    case "car_paint":
                        material.ClearcoatEnabled = true;
                        material.Clearcoat = 1.0f;
                        material.ClearcoatRoughness = 0.05f;
                        material.Metallic = 0.22f;
                        material.MetallicSpecular = 0.55f;
                        material.Roughness = 0.38f;
                        polished++;
                        break;
                    case "glass":
                        material.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
                        material.DepthDrawMode = BaseMaterial3D.DepthDrawModeEnum.Always;
                        material.CullMode = BaseMaterial3D.CullModeEnum.Back;
                        material.Roughness = Math.Clamp(material.Roughness, 0.02f, 0.1f);
                        material.Metallic = 0.0f;
                        material.MetallicSpecular = 0.6f;
                        material.SpecularMode = BaseMaterial3D.SpecularModeEnum.SchlickGgx;
                        material.RenderPriority = name.Contains("Lens", StringComparison.Ordinal) ? 1 : 0;
                        polished++;
                        break;
                    case "clearcoat":
                        material.ClearcoatEnabled = true;
                        material.Clearcoat = extras.TryGetValue("cv_clearcoat", out var coat) ? (float)coat.AsDouble() : 1.0f;
                        material.ClearcoatRoughness = extras.TryGetValue("cv_clearcoat_roughness", out var coatRoughness)
                            ? (float)coatRoughness.AsDouble()
                            : 0.06f;
                        polished++;
                        break;
                    case "metal":
                        material.Metallic = 1.0f;
                        material.Roughness = Math.Clamp(material.Roughness, 0.12f, 0.4f);
                        polished++;
                        break;
                }
                if (extras.TryGetValue("cv_alpha_scissor", out var scissor))
                {
                    material.Transparency = BaseMaterial3D.TransparencyEnum.AlphaScissor;
                    material.AlphaScissorThreshold = (float)scissor.AsDouble();
                    material.CullMode = BaseMaterial3D.CullModeEnum.Disabled;
                }
            }
        }
        _automationState["polished_material_surfaces"] = polished;
        _automationState["car_paint_shader"] = paintShader is not null;
        // Every surface now holds its own native reference; releasing the
        // managed wrappers here keeps the .NET finalizer from touching
        // resources the scene tree has already freed at shutdown (the same
        // rule the damage indicators follow).
        foreach (var paint in paintMaterials.Values)
        {
            paint.Dispose();
        }
        paintShader?.Dispose();
    }

    private static void ApplyDeclaredStandardCoat(StandardMaterial3D material, Godot.Collections.Dictionary extras)
    {
        var hasWeight = extras.TryGetValue("coat_weight", out var weightValue);
        var hasRoughness = extras.TryGetValue("coat_roughness", out var roughnessValue);
        if (!hasWeight && !hasRoughness) return;
        if (!hasWeight || !hasRoughness ||
            weightValue.VariantType is not (Variant.Type.Int or Variant.Type.Float) ||
            roughnessValue.VariantType is not (Variant.Type.Int or Variant.Type.Float))
        {
            throw new InvalidOperationException($"Material '{material.ResourceName}' must declare a numeric coat_weight and coat_roughness pair.");
        }
        var weight = weightValue.AsDouble();
        var roughness = roughnessValue.AsDouble();
        if (!double.IsFinite(weight) || !double.IsFinite(roughness) ||
            weight is < 0 or > 1 || roughness is < 0 or > 1)
        {
            throw new InvalidOperationException($"Material '{material.ResourceName}' coat_weight and coat_roughness must be finite values in [0, 1].");
        }
        material.ClearcoatEnabled = weight > 0;
        material.Clearcoat = (float)weight;
        material.ClearcoatRoughness = (float)roughness;
    }

    private static void ApplyDeclaredScreenSpecular(StandardMaterial3D material, string family)
    {
        const string key = "cannonball_specular_response";
        if (!material.HasMeta(key)) return;
        if (material.GetMeta(key).Obj is not Godot.Collections.Dictionary declaration)
            throw new InvalidOperationException($"Material '{material.ResourceName}' specular response must be a dictionary.");
        using (declaration)
        {
            if (declaration.Count != 2 ||
                !declaration.TryGetValue("schema", out var schema) || schema.VariantType != Variant.Type.String ||
                schema.AsString() != "khr-specular-f0.v1" ||
                !declaration.TryGetValue("specular_factor", out var value) ||
                value.VariantType is not (Variant.Type.Int or Variant.Type.Float))
                throw new InvalidOperationException($"Material '{material.ResourceName}' has an invalid specular response declaration.");
            var factor = value.AsDouble();
            if (!double.IsFinite(factor) || factor is < 0 or > 1 || family != "standard" ||
                material.ResourceName != "Material_Screen" || material.Metallic != 0 ||
                material.ShadingMode != BaseMaterial3D.ShadingModeEnum.PerPixel ||
                material.SpecularMode != BaseMaterial3D.SpecularModeEnum.SchlickGgx)
                throw new InvalidOperationException($"Material '{material.ResourceName}' requires a finite [0, 1] specular factor on the standard dielectric Screen domain.");
            // Godot 4.7.1 uses F0=.16*SPECULAR^2; scalar-only glTF uses F0=.04*factor.
            // This matches normal incidence only: Godot derives a different grazing F90.
            material.MetallicSpecular = (float)(0.5 * Math.Sqrt(factor));
        }
    }

    private static string FamilyFromName(string name)
    {
        if (name.EndsWith("Material_Body", StringComparison.Ordinal))
        {
            return "car_paint";
        }
        if (name.EndsWith("Material_Glass", StringComparison.Ordinal))
        {
            return "glass";
        }
        if (name.EndsWith("Material_Wheel", StringComparison.Ordinal) || name.EndsWith("Material_Trim", StringComparison.Ordinal))
        {
            return "metal";
        }
        return "";
    }

    private static ShaderMaterial BuildCarPaint(Shader shader, StandardMaterial3D source, Godot.Collections.Dictionary extras)
    {
        var paint = new ShaderMaterial { Shader = shader, ResourceName = source.ResourceName };
        paint.SetShaderParameter("base_color", source.AlbedoColor);
        paint.SetShaderParameter("metallic", source.Metallic);
        paint.SetShaderParameter("roughness", source.Roughness);
        if (extras.TryGetValue("cv_clearcoat", out var coat))
        {
            paint.SetShaderParameter("clearcoat", (float)coat.AsDouble());
        }
        if (extras.TryGetValue("cv_clearcoat_roughness", out var coatRoughness))
        {
            paint.SetShaderParameter("clearcoat_roughness", Math.Max(0.01f, (float)coatRoughness.AsDouble()));
        }
        if (extras.TryGetValue("cv_flake_scale", out var flakeScale))
        {
            paint.SetShaderParameter("flake_scale", (float)flakeScale.AsDouble());
        }
        if (extras.TryGetValue("cv_flake_strength", out var flakeStrength))
        {
            paint.SetShaderParameter("flake_strength", (float)flakeStrength.AsDouble());
        }
        if (extras.TryGetValue("cv_normal_strength", out var normalStrength))
        {
            paint.SetShaderParameter("orange_peel_strength", (float)normalStrength.AsDouble());
        }
        if (extras.TryGetValue("cv_edge_tint", out var edgeTint) && edgeTint.Obj is Godot.Collections.Array tint && tint.Count == 3)
        {
            paint.SetShaderParameter("edge_tint", new Color((float)tint[0].AsDouble(), (float)tint[1].AsDouble(), (float)tint[2].AsDouble()));
        }
        if (source.NormalTexture is { } orangePeel)
        {
            paint.SetShaderParameter("orange_peel", orangePeel);
        }
        return paint;
    }

    public VehicleVisualSnapshot CaptureSnapshot() => new(
        ContractResolved,
        ResolvedSemanticNodeCount,
        ActiveLod,
        SteeringRadians,
        WheelRotationRadians,
        MaximumSuspensionTravelMeters,
        ChaseCameraTarget.Position,
        CockpitCameraAnchor.Position,
        _damageIndicators.Count);

    /// <summary>Explicit verification only; actual active overrides and geometry after LOD selection.</summary>
    public VehicleRuntimeResourceInventory CaptureRuntimeResourceInventory()
    {
        var materials = new Dictionary<ulong, Material>();
        var textures = new Dictionary<ulong, Texture2D>();
        var meshes = new HashSet<ulong>();
        var drawnTriangles = 0;
        var drawnMeshes = 0;
        foreach (var instance in Descendants(this).OfType<MeshInstance3D>())
        {
            if (!instance.IsVisibleInTree() || instance.Mesh is not { } mesh) continue;
            drawnMeshes++;
            meshes.Add(mesh.GetRid().Id);
            for (var surface = 0; surface < mesh.GetSurfaceCount(); surface++)
            {
                using var arrays = mesh.SurfaceGetArrays(surface);
                var indices = arrays[(int)Mesh.ArrayType.Index].AsInt32Array();
                drawnTriangles += (indices.Length > 0 ? indices.Length : arrays[(int)Mesh.ArrayType.Vertex].AsVector3Array().Length) / 3;
                if (instance.GetActiveMaterial(surface) is { } material)
                    materials.TryAdd(material.GetRid().Id, material);
            }
        }
        foreach (var material in materials.Values)
            foreach (var property in material.GetPropertyList())
            {
                if (property["type"].AsInt32() != (int)Variant.Type.Object) continue;
                if (material.Get(property["name"].AsString()).Obj is Texture2D texture)
                    textures.TryAdd(texture.GetRid().Id, texture);
            }
        return new(ActiveLod, drawnTriangles, drawnMeshes, meshes.Count, materials.Count, textures.Count,
            materials.Select(pair => new VehicleMaterialResource(pair.Key, pair.Value.ResourceName, pair.Value.GetClass())).ToArray(),
            textures.Select(pair => new VehicleTextureResource(pair.Key, pair.Value.ResourcePath,
                pair.Value.GetClass(), pair.Value.GetWidth(), pair.Value.GetHeight())).ToArray());
    }

    private void BuildDamageIndicators(IReadOnlyDictionary<string, Node> resolved)
    {
        // Released once every indicator has taken its own reference; see the note
        // in CannonballVehicle.
        using var material = new StandardMaterial3D
        {
            AlbedoColor = new Color(1.0f, 0.08f, 0.035f, 0.72f),
            EmissionEnabled = true,
            Emission = new Color(1.0f, 0.02f, 0.01f),
            EmissionEnergyMultiplier = 2.5f,
            Transparency = BaseMaterial3D.TransparencyEnum.Alpha,
            ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded,
        };
        foreach (var name in new[] { "Damage_Front", "Damage_Rear", "Damage_Left", "Damage_Right", "Damage_Roof" })
        {
            var anchor = (Node3D)resolved[name];
            using var indicatorMesh = new SphereMesh { Radius = 0.12f, Height = 0.24f };
            var indicator = new MeshInstance3D
            {
                Name = $"{name}_Indicator",
                Mesh = indicatorMesh,
                MaterialOverride = material,
            };
            indicator.SetMeta("vehicle_runtime_generated", true);
            anchor.AddChild(indicator);
            _damageIndicators.Add(indicator);
        }
    }

    private static void SetVisualVisibility(Node root, bool visible)
    {
        foreach (var geometry in Descendants(root).OfType<GeometryInstance3D>())
        {
            geometry.Visible = visible;
        }
    }

    private static Node? FindDescendant(Node root, string name) =>
        Descendants(root).FirstOrDefault(node => node.Name == name);

    private static IEnumerable<Node> Descendants(Node root)
    {
        foreach (var child in root.GetChildren())
        {
            yield return child;
            foreach (var descendant in Descendants(child))
            {
                yield return descendant;
            }
        }
    }
}

public sealed record VehicleVisualSnapshot(
    bool ContractResolved,
    int SemanticNodeCount,
    int ActiveLod,
    float SteeringRadians,
    float WheelRotationRadians,
    float MaximumSuspensionTravelMeters,
    Vector3 ChaseCameraTarget,
    Vector3 CockpitCameraAnchor,
    int DamageZoneCount);

public sealed record VehicleRuntimeResourceInventory(int ActiveLod, int DrawnTriangles, int DrawnMeshInstances,
    int UniqueMeshResources, int ActiveMaterialResources, int ActiveTextureResources,
    IReadOnlyList<VehicleMaterialResource> Materials, IReadOnlyList<VehicleTextureResource> Textures);
public sealed record VehicleMaterialResource(ulong Rid, string Name, string ResourceType);
public sealed record VehicleTextureResource(ulong Rid, string Path, string ResourceType, int Width, int Height);
