outcomes = []


def make_row(value, marker, hidden=False):
    raw = copy.deepcopy(value["observation"])
    for component in raw["components"]:
        component["centroid"] = list(map(f32, component["centroid"]))
    optical = copy.deepcopy(value["optical"])
    selected = optical["selected_component_index"]
    component = raw["components"][selected] if selected is not None else None
    count = raw["raw_count"] if hidden else component["count"] if component else 0
    center = ([f32(raw["raw_sum_x"] / count), f32(raw["raw_sum_y"] / count)] if count else [-1, -1]) if hidden else component["centroid"] if component else [-1, -1]
    return {"mirror": ("Left", "Right", "Rear")[marker], "marker": marker + 1, "hidden": hidden,
            "pixels": count, "centroid": center, "color_components": raw, "optical_fiducials": optical}


for case in cases:
    actual = managed[case["name"]]
    if case["name"].startswith("invalid-"):
        assert actual["status"] == "rejected-domain"
    else:
        assert actual["status"] == "returned"
        assert (actual["optical"]["selected_component_index"] is not None) == case["expected_identified"], case["name"]
        if "expected_rejection" in case:
            assert len(actual["optical"]["candidates"]) == 1
            assert actual["optical"]["candidates"][0]["rejection"] == case["expected_rejection"], case["name"]
        data, width = bytes.fromhex(case["rgba_hex"]), case["width"]
        for candidate in actual["optical"]["candidates"]:
            samples = candidate["frame_samples"] + [pixel for cell in candidate["cells"] for pixel in cell["pixels"]]
            for sample in samples:
                at = (sample["y"] * width + sample["x"]) * 4
                assert sample["rgb"] == list(data[at:at + 3]), case["name"]
        value = make_row(actual, case["marker"])
        reader.validate_moving_fiducials(value, value["color_components"]["components"], [case["width"], case["height"]])
        try:
            reader.validate_moving_components(value)
        except ValueError as error:
            assert not case["expected_identified"] and "fiducial" in str(error), (case["name"], str(error))
        else:
            assert case["expected_identified"], case["name"]
    outcomes.append({"case": "actual-managed-" + case["name"], "status": "passed",
                     "expected_identity": case["expected_identified"]})

base = make_row(managed["coded-marker-2"], 1)


def negative(name, value):
    try:
        reader.validate_moving_components(value)
    except (ValueError, KeyError) as error:
        outcomes.append({"case": name, "status": "passed", "expected": "reject", "error": str(error)})
    else:
        raise AssertionError(name)


for name, mutate in (
    ("missing-identity", lambda value: value.pop("optical_fiducials")),
    ("missing-nullable-decoded-field", lambda value: value["optical_fiducials"]["candidates"][0].pop("decoded_marker")),
    ("missing-nullable-rejection-field", lambda value: value["optical_fiducials"]["candidates"][0].pop("rejection")),
    ("omitted-candidate", lambda value: value["optical_fiducials"]["candidates"].clear()),
    ("duplicate-candidate", lambda value: value["optical_fiducials"]["candidates"].append(copy.deepcopy(value["optical_fiducials"]["candidates"][0]))),
    ("changed-expected-marker", lambda value: value["optical_fiducials"].update(expected_marker=1)),
    ("selected-domain", lambda value: value["optical_fiducials"].update(selected_component_index=777)),
    ("false-identified-count", lambda value: value["optical_fiducials"].update(identified_count=0)),
    ("code-error-correction-disallowed", lambda value: value["optical_fiducials"]["policy"].update(code_error_correction=True)),
    ("changed-frame-coordinate", lambda value: value["optical_fiducials"]["candidates"][0]["frame_samples"][0].update(x=1)),
    ("missing-frame-sample", lambda value: value["optical_fiducials"]["candidates"][0]["frame_samples"].pop()),
    ("wrong-frame-membership", lambda value: value["optical_fiducials"]["candidates"][0]["frame_samples"][0].update(member=False)),
    ("missing-cell", lambda value: value["optical_fiducials"]["candidates"][0]["cells"].pop()),
    ("missing-core-pixel", lambda value: value["optical_fiducials"]["candidates"][0]["cells"][0]["pixels"].pop()),
    ("changed-sum", lambda value: value["optical_fiducials"]["candidates"][0]["cells"][0]["sums_rgb"].__setitem__(0, 777)),
    ("invented-decoded-marker", lambda value: value["optical_fiducials"]["candidates"][0].update(decoded_marker=1)),
    ("missing-rejection", lambda value: value["optical_fiducials"]["candidates"][0].update(rejection="made-up")),
    ("changed-selected-centroid", lambda value: value.update(centroid=[0, 0])),
    ("changed-component-count", lambda value: value.update(pixels=0)),
):
    corrupted = copy.deepcopy(base)
    mutate(corrupted)
    negative(name, corrupted)
for key, wrong in (("channel_contrast_min", 63), ("channel_agreement", "majority"),
                   ("achromatic_core_required", True), ("schema", "moving-optical-code10.v1")):
    omitted = copy.deepcopy(base)
    omitted["optical_fiducials"]["policy"].pop(key)
    negative("new-policy-missing-" + key, omitted)
    changed = copy.deepcopy(base)
    changed["optical_fiducials"]["policy"][key] = wrong
    negative("new-policy-changed-" + key, changed)
for key, wrong in (("channel_contrast_min", 64.0), ("achromatic_core_required", 0)):
    changed = copy.deepcopy(base)
    changed["optical_fiducials"]["policy"][key] = wrong
    negative("new-policy-native-type-" + key, changed)
for name in ("empty-hidden-control", "seven-primary-pixels"):
    reader.validate_moving_components(make_row(managed[name], 1, hidden=True))
    outcomes.append({"case": name + "-original-hidden-pass", "status": "passed"})
negative("hidden-disconnected14-raw-background", make_row(managed["two-seven-pixel-fragments"], 1, hidden=True))
old07 = managed["actual07-uncoded-native-image"]["observation"]["components"][0]
old_record = json.loads(native_paths[0].with_suffix(".json").read_text())
old_error = reader._native_distance2(list(map(f32, old07["centroid"])), list(map(f32, old_record["target_projection"])))
assert old_error > 5 and f32(old_error) == f32(old_record["projection_error_px"])
outcomes.append({"case": "original07-partial-five-pixel-rejection-preserved", "status": "passed", "error_px": old_error})
assert reader._native_distance2(base["centroid"], [0, 0]) > 5
outcomes.append({"case": "valid-identity-stale-projection-still-rejects", "status": "passed"})
templates = {name: make_row(managed["coded-marker-" + str(index + 1)], index) for index, name in enumerate(("Left", "Right", "Rear"))}
templates["hidden"] = make_row(managed["empty-hidden-control"], 1, hidden=True)
write(OUT / "positive-templates.json", templates)
assert all(row(Path(entry["path"])) == entry for entry in bindings)
write(OUT / "result.json", {"status": "passed", "count": len(outcomes), "actual_managed_cases": len(cases),
                           "native_executed": False, "rendered_fiducial_claim": False, "outcomes": outcomes})
print(json.dumps({"status": "passed", "controls": len(outcomes), "actual_managed_cases": len(cases)}))
