This is a private diagnostic overlay for the repeated Windows software-renderer
failure at revision `637c29aa5c1003188229aa95e956943879096f54`. It has not run the
native UI. It changes no C#, scene, asset, input, physics, or test assertion.

The payload changes only the copied Python client/launcher and debug server, and
adds a Python helper. `prepare.py --project PATH` rejects the canonical worktree,
requires a copied Godot project beneath a `reports` directory, validates all
three original source hashes before writing, and verifies every payload hash.
The actual test file remains byte-identical. The original protocol framing,
authentication, capability checks, response-size limits, and connection cleanup
remain in place.

The first `run.session` query after an actual Hero panel readback is the single
target. Its normal request wait is still30 seconds. A timeout is recorded as a
failure immediately. The private observer then retains that same future until
120 seconds total from the start of the normal response wait. A response during
that diagnostic interval is logged, and the original timeout is still raised.
It cannot turn a late response into a test pass. Unrelated requests keep their
normal behavior; the test's outer240-second deadline remains unchanged.

Client events include monotonic send, drain completion, wire-response decode,
awaiter completion, normal timeout, and late observation. Event payloads use
explicit fields; no authentication token or arbitrary RPC parameters are logged.
The launcher timestamps receipt of the bounded engine checkpoint lines.
Engine checkpoints cover the physics callback registered after Main's callback,
early bridge process enter/exit, selected RPC dispatch enter/return, and render
pre/post-draw. Main's metadata is labeled as metadata because it can be stale
before Main's next process step. The engine writes at most128 checkpoints over
13 post-draw observations. There is no performance acceptance claim from this
instrumented run. The two processes' monotonic epochs are different; compare
within-process intervals and correlate IDs/stdout receipt without claiming an
exact shared clock.

Preparation checks in `controls-01/evidence.json` passed eight real loopback
transport cases, four copy/admission controls, and official Godot4.7.1 headless
GDScript syntax checking. The loopback controls scale only their imported in-memory
policy to40/160ms so early, late, never, unrelated, second-query, disabled and
cancellation paths are independently exercised in under a second. Payload
constants remain30/120 seconds. No rendered game was launched.

After the lead grants a diagnostic GPU/remote lane, use a fresh copied source34
project and a fresh evidence directory. Do not apply this to the canonical tree.
For example, from the lead worktree:

```powershell
python reports/p1-018/runtime/windows-ui-retry34-01/diagnostic-02/prepare.py --project C:/Dev/Cannonball-Vibe-sedan/reports/p1-018/runtime/ui-probe/project
```

Then from that copied project, with the official engine and pinned uv on PATH:

```bash
export GODOT_BIN='/absolute/path/to/official/Godot'
export DOTNET_ROLL_FORWARD=Major
export DOTNET_GCgen0size=800000
export PLAYGODOT_ARTIFACT_DIR='/absolute/fresh/evidence/directory'
export P1_UI_DIAGNOSTIC_EVENTS="$PLAYGODOT_ARTIFACT_DIR/selection-diagnostic.jsonl"
mkdir -p "$PLAYGODOT_ARTIFACT_DIR"
./scripts/verify-playgodot.sh --test-filter=endurance_sedan_inspection_and_selection_controls
```

The lead's command recorder must retain the actual argv/environment, exact source
and overlay hashes, complete stdout/stderr and exit status, all engine/client
events, and the existing test artifacts. The shared wrapper keeps the previously
verified editor-only .NET host policy; no editor import is added by this overlay.

Interpret a normal-deadline failure followed by a late post-draw/response as
diagnostic evidence only. If the measured blocked interval is first-draw
preparation, the smallest subsequent proposal is a distinct, bounded selection
readiness check analogous to initial renderer preparation, with normal requests
and state thresholds unchanged. If a dispatch enters without returning, or no
later frame completes within120 seconds, investigate that observed phase before
proposing any timeout change. Do not infer shader compilation solely from the
ANGLE device name or elapsed time.
