"""Private diagnostic only: a late response never reverses a normal timeout."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time

NORMAL_REQUEST_SECONDS = 30.0
TOTAL_OBSERVATION_SECONDS = 120.0


def emit(event: str, **fields: object) -> None:
    destination = os.environ.get("P1_UI_DIAGNOSTIC_EVENTS")
    if not destination:
        return
    # Callers pass a small explicit allowlist. Never record tokens or arbitrary
    # RPC arguments, screenshots, saves, or the full process environment.
    row = {"event": event, "monotonic_ns": time.monotonic_ns(),
           "utc": datetime.now(timezone.utc).isoformat(), **fields}
    with Path(destination).open("a", encoding="utf8", newline="\n") as output:
        output.write(json.dumps(row, sort_keys=True) + "\n")


def _state(client: object) -> dict:
    if not hasattr(client, "_p1_selection_diagnostic"):
        client._p1_selection_diagnostic = {"hero_read_back": False, "target_id": None}
    return client._p1_selection_diagnostic


def request_started(client: object, method: str, params: dict | None, request_id: int) -> dict:
    state = _state(client)
    target = (bool(os.environ.get("P1_UI_DIAGNOSTIC_EVENTS"))
              and state["hero_read_back"] and state["target_id"] is None
              and method == "ui.describe" and (params or {}).get("automation_id") == "run.session")
    if target:
        if client._timeout != NORMAL_REQUEST_SECONDS:
            raise ValueError("The selection diagnostic requires the unchanged 30 second request deadline")
        state["target_id"] = request_id
    context = {"request_id": request_id, "method": method, "target": target,
               "automation_id": (params or {}).get("automation_id"),
               "sent_monotonic_ns": time.monotonic_ns()}
    emit("rpc_send", **context)
    return context


def request_drained(context: dict, timeout_seconds: float) -> None:
    context["wait_started_monotonic_ns"] = time.monotonic_ns()
    emit("rpc_drain_complete", request_id=context["request_id"], target=context["target"],
         request_timeout_seconds=timeout_seconds,
         normal_deadline_monotonic_ns=context["wait_started_monotonic_ns"] + int(timeout_seconds * 1e9))


def result_received(client: object, context: dict, result: object) -> None:
    selected = result.get("test_state", {}).get("selected_asset") if isinstance(result, dict) else None
    if (context["method"] == "ui.describe"
            and context["automation_id"] == "vehicle.inspection.panel" and selected == "hero-gt"):
        _state(client)["hero_read_back"] = True
    emit("rpc_received", request_id=context["request_id"], target=context["target"],
         elapsed_from_send_ms=(time.monotonic_ns() - context["sent_monotonic_ns"]) / 1e6,
         selected_asset=selected)


def response_decoded(client: object, request_id: int) -> None:
    emit("rpc_wire_response_decoded", request_id=request_id,
         target=_state(client)["target_id"] == request_id)


async def observe_late(client: object, future: asyncio.Future, context: dict) -> None:
    if not context["target"]:
        return
    emit("ordinary_deadline_failed", request_id=context["request_id"],
         timeout_seconds=client._timeout, acceptance="failed",
         elapsed_from_send_ms=(time.monotonic_ns() - context["sent_monotonic_ns"]) / 1e6)
    deadline = context["wait_started_monotonic_ns"] + int(TOTAL_OBSERVATION_SECONDS * 1e9)
    remaining = max(0.0, (deadline - time.monotonic_ns()) / 1e9)
    emit("late_observation_started", request_id=context["request_id"],
         total_window_seconds=TOTAL_OBSERVATION_SECONDS, remaining_seconds=remaining,
         acceptance="still_failed")
    try:
        result = await asyncio.wait_for(asyncio.shield(future), remaining)
    except TimeoutError:
        emit("late_observation_deadline", request_id=context["request_id"], acceptance="still_failed")
    except asyncio.CancelledError:
        emit("late_observation_cancelled", request_id=context["request_id"], acceptance="still_failed")
        raise
    except Exception as error:
        emit("late_observation_error", request_id=context["request_id"],
             error_type=type(error).__name__, acceptance="still_failed")
    else:
        selected = result.get("test_state", {}).get("selected_asset") if isinstance(result, dict) else None
        emit("late_response_observed", request_id=context["request_id"],
             elapsed_from_send_ms=(time.monotonic_ns() - context["sent_monotonic_ns"]) / 1e6,
             selected_asset=selected, acceptance="still_failed")


def process_line(line: str, pid: int | None) -> None:
    if line.startswith(("P1_UI_DIAGNOSTIC_ENGINE ", "PLAYGODOT_", "CANNONBALL_VEHICLE_SELECTED ")):
        emit("engine_stdout_received", pid=pid, line=line)
