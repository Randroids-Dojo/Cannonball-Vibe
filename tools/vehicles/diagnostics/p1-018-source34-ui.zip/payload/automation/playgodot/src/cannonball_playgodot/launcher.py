from __future__ import annotations

import asyncio
import contextlib
import json
import os
import platform
import secrets
import shutil
import signal
import tempfile
from collections import deque
from pathlib import Path

from .client import PlayGodotClient, ProtocolError
from . import selection_diagnostic as _p1_diag

READY_PREFIX = "PLAYGODOT_READY "


class PlayGodotProcess:
    def __init__(
        self,
        repo_root: Path,
        route_package: Path,
        *,
        capabilities: tuple[str, ...] = ("read",),
        godot_bin: Path | None = None,
        startup_timeout: float = 20.0,
        request_timeout: float = 10.0,
        transcript: Path | None = None,
        log_path: Path | None = None,
        production_vehicle: bool = False,
        vehicle: str | None = None,
        isolate_user_data: bool = False,
    ) -> None:
        self.repo_root = repo_root.resolve()
        self.route_package = route_package.resolve()
        self.capabilities = capabilities
        self.production_vehicle = production_vehicle
        if vehicle not in (None, "hero-gt", "endurance-sedan", "graybox"):
            raise ValueError("Unknown explicit PlayGodot vehicle")
        self.vehicle = vehicle
        self.isolate_user_data = isolate_user_data
        self.godot_bin = godot_bin or self._godot_from_environment()
        self.startup_timeout = startup_timeout
        self.request_timeout = request_timeout
        self.transcript = transcript
        self.log_path = log_path
        self.process: asyncio.subprocess.Process | None = None
        self.client: PlayGodotClient | None = None
        self.output: deque[str] = deque(maxlen=1_000)
        self._drain_task: asyncio.Task[None] | None = None
        self._runtime_directory: Path | None = None
        self.startup_elapsed_seconds: float | None = None

    @staticmethod
    def _godot_from_environment() -> Path:
        value = os.environ.get("GODOT_BIN", "godot")
        resolved = shutil.which(value)
        if resolved:
            return Path(resolved)
        return Path(value)

    async def start(self) -> PlayGodotClient:
        if self.process is not None:
            raise RuntimeError("PlayGodot process is already running")
        if not self.godot_bin.is_file():
            raise FileNotFoundError(self.godot_bin)
        if not self.route_package.is_file():
            raise FileNotFoundError(self.route_package)
        token = secrets.token_urlsafe(32)
        if self.log_path is not None:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            self.log_path.write_text("")
        environment = os.environ.copy()
        environment["PLAYGODOT_TOKEN"] = token
        environment["PLAYGODOT_CAPABILITIES"] = ",".join(self.capabilities)
        if self.transcript is not None:
            self.transcript.parent.mkdir(parents=True, exist_ok=True)
            environment["PLAYGODOT_TRANSCRIPT"] = str(self.transcript.resolve())
        self._runtime_directory = Path(
            tempfile.mkdtemp(prefix="cannonball-playgodot-")
        ).resolve()
        if self.isolate_user_data:
            # The selection test writes presentation settings. Scope its whole
            # child-process user profile, never the developer's real save/config.
            environment.update(
                HOME=str(self._runtime_directory),
                XDG_DATA_HOME=str(self._runtime_directory / "xdg-data"),
                APPDATA=str(self._runtime_directory / "appdata"),
                LOCALAPPDATA=str(self._runtime_directory / "localappdata"),
            )
        command = [
            str(self.godot_bin),
            "--audio-driver",
            "Dummy",
            "--rendering-method",
            "gl_compatibility",
            "--path",
            str(self.repo_root),
            "addons/playgodot/bootstrap.tscn",
            "--",
            "--playgodot",
            # The semantic suite runs the graybox environment: its assertions
            # are about input, camera, menu and restart behaviour, and the
            # software-rendered runners cannot draw the production art fast
            # enough to hold the suite's wall-clock bounds (Q-042).
            "--graybox-environment-assets",
            f"--route-package={self.route_package}",
            f"--telemetry-path={self._runtime_directory / 'telemetry.jsonl'}",
        ]
        if self.vehicle is not None:
            command.append(f"--vehicle={self.vehicle}")
        elif self.production_vehicle:
            # Legacy camera/visual tests exercise Hero's declared contract,
            # independent of a player's persisted sedan or graybox selection.
            command.append("--vehicle=hero-gt")
        else:
            # The same reasoning covers the car: the third-generation Hero GT
            # brought twenty-eight textured materials whose first draw stalls
            # the main thread for tens of seconds on the software renderers,
            # which is longer than the suite's request and settle windows.
            # Only the camera test needs the production rig's contract.
            command.append("--graybox-vehicle")
            command.append("--vehicle=graybox")
        if platform.system() == "Linux" and os.environ.get("PLAYGODOT_XVFB") == "1":
            command = ["xvfb-run", "-a", *command]
        try:
            startup_started = asyncio.get_running_loop().time()
            self.process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                env=environment,
                start_new_session=os.name == "posix",
            )
            try:
                ready = await asyncio.wait_for(self._read_ready(), self.startup_timeout)
            except TimeoutError as error:
                tail = "\n".join(list(self.output)[-20:])
                raise TimeoutError(
                    f"Godot did not advertise PLAYGODOT_READY within "
                    f"{self.startup_timeout:g}s; process output:\n{tail}"
                ) from error
            self.startup_elapsed_seconds = asyncio.get_running_loop().time() - startup_started
            if ready.get("address") != "127.0.0.1" or ready.get("protocol") != "1.0":
                raise ProtocolError("PlayGodot advertised an unsafe or incompatible endpoint")
            if ready.get("engine") != "4.7.1-stable (official)":
                raise ProtocolError("PlayGodot did not start on official Godot 4.7.1")
            self._drain_task = asyncio.create_task(self._drain_output())
            self.client = await PlayGodotClient.connect(
                ready["address"],
                int(ready["port"]),
                token=token,
                capabilities=self.capabilities,
                timeout=self.request_timeout,
            )
            return self.client
        except BaseException:
            await self.stop()
            raise

    async def _read_ready(self) -> dict[str, object]:
        assert self.process is not None and self.process.stdout is not None
        while True:
            line_bytes = await self.process.stdout.readline()
            if not line_bytes:
                exit_code = await self.process.wait()
                tail = "\n".join(list(self.output)[-20:])
                raise RuntimeError(f"Godot exited before PlayGodot was ready ({exit_code})\n{tail}")
            line = line_bytes.decode(errors="replace").rstrip()
            self._record_output(line)
            if line.startswith(READY_PREFIX):
                try:
                    ready = json.loads(line.removeprefix(READY_PREFIX))
                except json.JSONDecodeError as error:
                    raise ProtocolError("PlayGodot printed a malformed ready record") from error
                if not isinstance(ready, dict):
                    raise ProtocolError("PlayGodot printed an invalid ready record")
                return ready

    async def _drain_output(self) -> None:
        assert self.process is not None and self.process.stdout is not None
        while line_bytes := await self.process.stdout.readline():
            self._record_output(line_bytes.decode(errors="replace").rstrip())

    def _record_output(self, line: str) -> None:
        _p1_diag.process_line(line, self.process.pid if self.process else None)
        self.output.append(line)
        if self.log_path is not None:
            with self.log_path.open("a", encoding="utf-8", newline="\n") as log:
                log.write(line + "\n")

    async def stop(self) -> None:
        cancellation: asyncio.CancelledError | None = None
        try:
            if self.client is not None:
                await self.client.close()
        except asyncio.CancelledError as error:
            cancellation = error
        except BaseException:
            pass
        finally:
            self.client = None
        cleanup = asyncio.create_task(self._stop_process())
        try:
            await asyncio.shield(cleanup)
        except asyncio.CancelledError as error:
            cancellation = error
            await cleanup
        if self._runtime_directory is not None:
            shutil.rmtree(self._runtime_directory, ignore_errors=True)
            self._runtime_directory = None
        if cancellation is not None:
            raise cancellation

    async def _stop_process(self) -> None:
        if self.process is None:
            return
        if self.process.returncode is None:
            self._signal_process(force=False)
            try:
                await asyncio.wait_for(self.process.wait(), 5.0)
            except TimeoutError:
                self._signal_process(force=True)
                await self.process.wait()
        if self._drain_task is not None:
            await self._drain_task
            self._drain_task = None
        self.process = None

    def _signal_process(self, *, force: bool) -> None:
        assert self.process is not None
        with contextlib.suppress(ProcessLookupError):
            if os.name == "posix":
                os.killpg(self.process.pid, signal.SIGKILL if force else signal.SIGTERM)
            elif force:
                self.process.kill()
            else:
                self.process.terminate()

    async def __aenter__(self) -> PlayGodotClient:
        return await self.start()

    async def __aexit__(self, *_exc: object) -> None:
        await self.stop()
