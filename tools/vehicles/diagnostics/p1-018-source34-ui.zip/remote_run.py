"""Proposed remote diagnostic runner; never call its late result an acceptance pass."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

REVISION = "637c29aa5c1003188229aa95e956943879096f54"


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    project, output = args.project.resolve(), args.output.resolve()
    bundle = Path(__file__).resolve().parent
    if "reports" not in project.parts or not (project / ".git").exists():
        raise ValueError("Use an isolated checkout beneath reports, never the canonical checkout")
    output.mkdir(parents=True, exist_ok=False)
    record = {"task_id": "P1-018", "utc": datetime.now(timezone.utc).isoformat(),
              "status": "diagnostic_failed_before_execution", "acceptance_claim": False,
              "commands": [], "human_approval_reference": None}
    env = os.environ.copy()
    engine = shutil.which("godot")
    if not engine:
        raise ValueError("Official Godot executable is unavailable")
    env.update(GODOT_BIN=engine, DOTNET_ROLL_FORWARD="Major", DOTNET_GCgen0size="800000",
               PLAYGODOT_ARTIFACT_DIR=str(output / "artifacts"))
    # Keep the original backend selection: the runner itself must report ANGLE
    # Microsoft Basic Render Driver. A requested environment value is not proof.
    env.pop("ANGLE_DEFAULT_PLATFORM", None)
    env.pop("P1_UI_DIAGNOSTIC_EVENTS", None)
    bash = Path(r"C:\Program Files\Git\bin\bash.exe")
    if not bash.is_file():
        raise ValueError("Pinned Windows job requires Git Bash")

    def write_record():
        (output / "evidence.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf8", newline="\n")

    def run(label: str, argv: list[str], timeout: int = 450):
        entry = {"label": label, "argv": argv, "cwd": str(project),
                 "start_utc": datetime.now(timezone.utc).isoformat(), "exit_status": None,
                 "environment": {key: env.get(key) for key in (
                     "GODOT_BIN", "DOTNET_ROLL_FORWARD", "DOTNET_GCgen0size", "PLAYGODOT_ARTIFACT_DIR",
                     "P1_UI_DIAGNOSTIC_EVENTS", "ANGLE_DEFAULT_PLATFORM")}}
        record["commands"].append(entry)
        path = output / (label + ".log")
        with path.open("xb") as log:
            process = subprocess.Popen(argv, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            entry["pid"] = process.pid
            try:
                entry["exit_status"] = process.wait(timeout)
            except subprocess.TimeoutExpired:
                entry["outer_watchdog_expired"] = True
                cleanup = subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                                         stdout=log, stderr=log, check=False)
                entry["owned_process_tree_cleanup_exit"] = cleanup.returncode
                entry["exit_status"] = process.wait(30)
        entry.update(end_utc=datetime.now(timezone.utc).isoformat(), log=path.name,
                     log_sha256=sha(path), bytes=path.stat().st_size)
        write_record()
        return entry

    code = 2
    try:
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=project).decode().strip()
        assert head == REVISION, (head, REVISION)
        assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=project).strip()
        assert not (project / ".godot").exists()
        record["git_revision"] = head
        record["fresh_godot_cache_absent"] = True
        record["engine"] = {"path": engine, "sha256": sha(Path(engine))}
        for label, command in (
            ("version-engine", [engine, "--version"]),
            ("version-sdk", ["dotnet", "--info"]),
            ("version-python", [sys.executable, "--version"]),
            ("version-uv", ["uv", "--version"]),
        ):
            version = run(label, command, 30)
            if version["exit_status"] != 0:
                return int(version["exit_status"])
        paths = subprocess.check_output(["git", "ls-files", "-z"], cwd=project).decode().split("\0")
        before = {path: {"sha256": sha(project / path), "bytes": (project / path).stat().st_size}
                  for path in paths if path}
        record["source_inputs"] = before
        record["review_media_lfs_policy"] = "Only data/assets/vehicles/endurance-sedan-review/** excluded during checkout; pointer bytes remain bound."
        prepare_script = project / ".tools/prepare-ui-diagnostic.sh"
        prepare_script.parent.mkdir(exist_ok=True)
        frontdoor = (project / "scripts/verify-playgodot.sh").read_bytes().replace(b"\r\n", b"\n")
        expected_frontdoor = json.loads((bundle / "remote-lock.json").read_text(encoding="utf8"))["frontdoor_sha256"]
        assert hashlib.sha256(frontdoor).hexdigest() == expected_frontdoor
        marker = b"# Durations show which launch paid for a slow first draw when a bound trips.\n"
        assert frontdoor.count(marker) == 1
        # Exact existing build/import/boundary/lint/graybox warmup prefix, before
        # the native test. Its original BASH_SOURCE parent still resolves here.
        prepare_script.write_bytes(frontdoor.split(marker)[0])
        record["preparation_prefix"] = {"sha256": sha(prepare_script), "original_frontdoor_sha256": expected_frontdoor}
        preparation = run("prepare-original-frontdoor", [str(bash), "--noprofile", "--norc", str(prepare_script)])
        if preparation["exit_status"] != 0 or preparation.get("outer_watchdog_expired"):
            return int(preparation["exit_status"] or 2)
        applied = run("apply-reports-only-overlay", [sys.executable, str(bundle / "prepare.py"), "--project", str(project)], 30)
        if applied["exit_status"] != 0:
            return int(applied["exit_status"])
        env["P1_UI_DIAGNOSTIC_EVENTS"] = str(output / "selection-diagnostic.jsonl")
        run_case = run("native-selection-diagnostic", ["uv", "run", "--project", "automation/playgodot", "--frozen", "pytest",
            "automation/playgodot/tests/test_endurance_sedan.py", "--durations=10"], 300)
        code = int(run_case["exit_status"])
        event_path = output / "selection-diagnostic.jsonl"
        events = [json.loads(line) for line in event_path.read_text(encoding="utf8").splitlines()] if event_path.exists() else []
        game_log = output / "artifacts/sedan-inspection-godot.log"
        lines = game_log.read_text(encoding="utf8").splitlines() if game_log.exists() else []
        renderer = next((line for line in lines if "Compatibility - Using Device" in line), "absent")
        record["observations"] = {
            "actual_renderer": renderer,
            "required_software_backend_confirmed": "ANGLE" in renderer and "Microsoft Basic Render Driver" in renderer,
            "target_requests": [row for row in events if row["event"] == "rpc_send" and row.get("target")],
            "ordinary_deadline_failed": any(row["event"] == "ordinary_deadline_failed" for row in events),
            "late_responses": [row for row in events if row["event"] == "late_response_observed"],
            "observation_deadline_reached": any(row["event"] == "late_observation_deadline" for row in events),
            "observation_cancelled": any(row["event"] == "late_observation_cancelled" for row in events),
        }
        after = {path: {"sha256": sha(project / path), "bytes": (project / path).stat().st_size} for path in before}
        changed = [path for path in before if before[path] != after[path]]
        overlay = json.loads((bundle / "overlay.json").read_text(encoding="utf8"))
        expected_changes = [row["path"] for row in overlay["changed_files"] if row["before_sha256"] is not None]
        assert sorted(changed) == sorted(expected_changes), changed
        assert all(sha(project / row["path"]) == row["after_sha256"] for row in overlay["changed_files"])
        record["changed_tracked_files"] = changed
        record["actual_test_sha256_unchanged"] = after["automation/playgodot/tests/test_endurance_sedan.py"]["sha256"]
        record["status"] = "diagnostic_only_ordinary_timeout_preserved" if record["observations"]["ordinary_deadline_failed"] else "diagnostic_only_timeout_not_reproduced"
        if record["observations"]["ordinary_deadline_failed"] and code == 0:
            raise AssertionError("A late result incorrectly passed the original test")
        if not record["observations"]["required_software_backend_confirmed"] or not record["observations"]["target_requests"]:
            code = 2
            record["status"] = "diagnostic_incomplete_or_wrong_renderer"
    finally:
        record["end_utc"] = datetime.now(timezone.utc).isoformat()
        record["outputs"] = [{"path": path.relative_to(output).as_posix(), "sha256": sha(path), "bytes": path.stat().st_size}
                             for path in sorted(output.rglob("*")) if path.is_file() and path.name != "evidence.json"]
        write_record()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
