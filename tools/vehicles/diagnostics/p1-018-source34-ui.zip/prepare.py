"""Produce a hash-bound overlay; apply only to an explicitly copied reports project."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
TESTED = HERE.parent / "binding-02/tested-inputs"
CLIENT = "automation/playgodot/src/cannonball_playgodot/client.py"
LAUNCHER = "automation/playgodot/src/cannonball_playgodot/launcher.py"
SERVER = "addons/playgodot/server.gd"
HELPER = "automation/playgodot/src/cannonball_playgodot/selection_diagnostic.py"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"Expected exactly one mutation anchor: {old!r}")
    return text.replace(old, new)


def make_overlay() -> None:
    payload = HERE / "payload"
    payload.mkdir(exist_ok=False)
    inputs = {path: (TESTED / path).read_bytes() for path in (CLIENT, LAUNCHER, SERVER)}
    client = inputs[CLIENT].decode("utf8")
    client = replace_once(client, "from typing import Any\n", "from typing import Any\n\nfrom . import selection_diagnostic as _p1_diag\n")
    client = replace_once(client, "            self._pending[request_id] = future\n", "            self._pending[request_id] = future\n            diagnostic = _p1_diag.request_started(self, method, params, request_id)\n")
    client = replace_once(client, "                await asyncio.wait_for(self._writer.drain(), self._timeout)\n", "                await asyncio.wait_for(self._writer.drain(), self._timeout)\n                _p1_diag.request_drained(diagnostic, self._timeout)\n")
    client = replace_once(client,
        "            return await asyncio.wait_for(asyncio.shield(future), self._timeout)\n",
        "            result = await asyncio.wait_for(asyncio.shield(future), self._timeout)\n            _p1_diag.result_received(self, diagnostic, result)\n            return result\n")
    client = replace_once(client, "                request_id = response[\"id\"]\n", "                request_id = response[\"id\"]\n                _p1_diag.response_decoded(self, request_id)\n")
    client = replace_once(client,
        "        except TimeoutError as error:\n            self._pending.pop(request_id, None)\n            future.cancel()\n            self._writer.close()\n            raise TimeoutError(f\"PlayGodot request timed out: {method}\") from error\n",
        "        except TimeoutError as error:\n            try:\n                await _p1_diag.observe_late(self, future, diagnostic)\n            finally:\n                self._pending.pop(request_id, None)\n                future.cancel()\n                self._writer.close()\n            raise TimeoutError(f\"PlayGodot request timed out: {method}\") from error\n")
    launcher = inputs[LAUNCHER].decode("utf8")
    launcher = replace_once(launcher, "from .client import PlayGodotClient, ProtocolError\n", "from .client import PlayGodotClient, ProtocolError\nfrom . import selection_diagnostic as _p1_diag\n")
    launcher = replace_once(launcher, "    def _record_output(self, line: str) -> None:\n", "    def _record_output(self, line: str) -> None:\n        _p1_diag.process_line(line, self.process.pid if self.process else None)\n")
    server = inputs[SERVER].decode("utf8")
    server = replace_once(server, "\t_listener = TCPServer.new()\n", "\t_p1_diag_connect()\n\t_listener = TCPServer.new()\n")
    server = replace_once(server, "func _process(_delta: float) -> void:\n", "func _process(_delta: float) -> void:\n\t_p1_diag_checkpoint(\"server_process_enter\")\n")
    server = replace_once(server, "\t_flush_outbound()\n", "\t_flush_outbound()\n\t_p1_diag_checkpoint(\"server_process_exit\")\n")
    server = replace_once(server, "\tvar response := _dispatch(method, params, request_id)\n", "\t_p1_diag_dispatch(\"dispatch_enter\", method, params, request_id)\n\tvar response := _dispatch(method, params, request_id)\n\t_p1_diag_dispatch(\"dispatch_return\", method, params, request_id)\n")
    server = replace_once(server, "func _exit_tree() -> void:\n", "func _exit_tree() -> void:\n\t_p1_diag_disconnect()\n")
    server += (HERE / "engine_checkpoints.gd.txt").read_text(encoding="utf8")
    outputs = {CLIENT: client.encode(), LAUNCHER: launcher.encode(), SERVER: server.encode(),
               HELPER: (HERE / "selection_diagnostic.py").read_bytes()}
    rows = []
    patch = []
    for name, content in outputs.items():
        target = payload / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        original = inputs.get(name, b"")
        rows.append({"path": name, "before_sha256": sha(original) if name in inputs else None,
                     "after_sha256": sha(content), "bytes": len(content)})
        patch.extend(difflib.unified_diff(original.decode().splitlines(keepends=True), content.decode().splitlines(keepends=True),
                     fromfile="a/" + name if name in inputs else "/dev/null", tofile="b/" + name))
    (HERE / "diagnostic.patch").write_text("".join(patch), encoding="utf8", newline="\n")
    lock = {"task_id": "P1-018", "utc": datetime.now(timezone.utc).isoformat(),
            "status": "prepared_not_executed", "tested_revision": "637c29aa5c1003188229aa95e956943879096f54",
            "normal_request_deadline_seconds": 30, "diagnostic_total_window_seconds": 120,
            "late_response_can_pass_test": False, "test_and_csharp_modified": False,
            "maximum_engine_checkpoints": 128, "maximum_post_draws_observed": 13,
            "changed_files": rows, "patch_sha256": sha((HERE / "diagnostic.patch").read_bytes()),
            "human_approval_reference": None}
    (HERE / "overlay.json").write_text(json.dumps(lock, indent=2) + "\n", encoding="utf8", newline="\n")


def apply_overlay(project: Path) -> None:
    project = project.resolve()
    if project == ROOT.resolve() or "reports" not in project.parts or not (project / "project.godot").is_file():
        raise ValueError("Target must be an explicit copied Godot project beneath a reports directory")
    lock = json.loads((HERE / "overlay.json").read_text())
    for row in lock["changed_files"]:
        target = project / row["path"]
        expected = row["before_sha256"]
        if expected is None:
            if target.exists():
                raise ValueError(f"New helper already exists: {target}")
        elif not target.is_file() or sha(target.read_bytes().replace(b"\r\n", b"\n")) != expected:
            raise ValueError(f"Private input differs from the tested revision: {target}")
        if sha((HERE / "payload" / row["path"]).read_bytes()) != row["after_sha256"]:
            raise ValueError("Diagnostic payload changed")
    for row in lock["changed_files"]:
        target = project / row["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(HERE / "payload" / row["path"], target)
    print(json.dumps({"status": "applied_reports_only", "project": str(project), "changed_files": len(lock["changed_files"])}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, help="Apply the prepared overlay to a copied reports-only project")
    args = parser.parse_args()
    if args.project:
        apply_overlay(args.project)
    else:
        make_overlay()
